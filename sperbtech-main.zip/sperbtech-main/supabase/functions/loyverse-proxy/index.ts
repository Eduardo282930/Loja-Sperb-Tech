// Supabase Edge Function: Loyverse Proxy
// Purpose: Bypass browser CORS by calling the Loyverse API server-side
// Usage: Invoke via Supabase Functions from the frontend

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const BASE_URL = "https://api.loyverse.com/v1.0";

function buildCorsHeaders(origin: string | null) {
  return {
    "Access-Control-Allow-Origin": origin ?? "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Max-Age": "86400",
    "Content-Type": "application/json; charset=utf-8",
  } as Record<string, string>;
}

serve(async (req: Request) => {
  const origin = req.headers.get("origin");
  const corsHeaders = buildCorsHeaders(origin);

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { resource, method, token, payload, params, useStoredToken } = await req.json();
    console.log('Request received:', { resource, method, useStoredToken, hasToken: !!token });

    let loyverseToken = token;
    
    if (useStoredToken) {
      // Try LOYVERSE_API_TOKEN first, then LOYVERSE_API_KEY as fallback
      loyverseToken = Deno.env.get('LOYVERSE_API_TOKEN') || Deno.env.get('LOYVERSE_API_KEY');
      console.log('Looking for stored token...');
      console.log('LOYVERSE_API_TOKEN exists:', !!Deno.env.get('LOYVERSE_API_TOKEN'));
      console.log('LOYVERSE_API_KEY exists:', !!Deno.env.get('LOYVERSE_API_KEY'));
      console.log('Token found:', !!loyverseToken);
      
      if (!loyverseToken) {
        console.error('No Loyverse token found in environment variables');
        console.error('Available env vars:', Object.keys(Deno.env.toObject()).filter(k => k.includes('LOYVERSE')));
        return new Response(JSON.stringify({ 
          error: "Missing Loyverse token", 
          details: "No LOYVERSE_API_TOKEN or LOYVERSE_API_KEY found in environment" 
        }), { status: 400, headers: corsHeaders });
      }
    }

    if (!loyverseToken || typeof loyverseToken !== "string") {
      console.error('Invalid token provided:', typeof loyverseToken);
      return new Response(JSON.stringify({ 
        error: "Invalid Loyverse token",
        details: "Token must be a non-empty string"
      }), { status: 400, headers: corsHeaders });
    }

    if (!resource) {
      return new Response(JSON.stringify({ 
        error: "Missing resource",
        details: "Resource parameter is required"
      }), { status: 400, headers: corsHeaders });
    }

    const searchParams = new URLSearchParams();
    if (params && typeof params === "object") {
      Object.entries(params).forEach(([k, v]) => searchParams.append(k, String(v)));
    }

    const url = `${BASE_URL}/${resource}${searchParams.size ? `?${searchParams.toString()}` : ""}`;
    console.log('📡 Calling Loyverse API:', { 
      url: url.replace(loyverseToken, '[HIDDEN]'), 
      method: method || "GET",
      hasParams: searchParams.size > 0,
      paramCount: searchParams.size 
    });

    const headers: HeadersInit = {
      "Authorization": `Bearer ${loyverseToken}`,
      "Content-Type": "application/json",
    };

    const upstream = await fetch(url, {
      method: method || (resource === "receipts" ? "POST" : "GET"),
      headers,
      body: resource === "receipts" ? JSON.stringify(payload ?? {}) : undefined,
    });

    console.log('📥 Loyverse API response:', { 
      status: upstream.status, 
      statusText: upstream.statusText,
      contentType: upstream.headers.get('content-type'),
      hasBody: !!upstream.body
    });

    const text = await upstream.text();
    let body: unknown;
    try { 
      body = text ? JSON.parse(text) : null; 
    } catch { 
      body = text; 
    }

    // Log errors for debugging (without exposing sensitive data)
    if (!upstream.ok) {
      console.error('Loyverse API error:', {
        status: upstream.status,
        statusText: upstream.statusText,
        hasResponse: !!text,
        responseLength: text?.length || 0
      });
      
      // Return detailed error information
      return new Response(JSON.stringify({
        error: "Loyverse API error",
        details: {
          status: upstream.status,
          statusText: upstream.statusText,
          message: body || "No response body"
        }
      }), {
        status: upstream.status,
        headers: corsHeaders,
      });
    }

    return new Response(JSON.stringify(body), {
      status: upstream.status,
      headers: corsHeaders,
    });
  } catch (err) {
    console.error('Edge function error:', err);
    const message = err instanceof Error ? err.message : "Unknown error";
    const stack = err instanceof Error ? err.stack : undefined;
    
    return new Response(JSON.stringify({ 
      error: "Edge function error",
      details: {
        message,
        type: err?.constructor?.name || "Unknown",
        stack: stack?.split('\n').slice(0, 3).join('\n') // First 3 lines only for security
      }
    }), { 
      status: 500, 
      headers: corsHeaders 
    });
  }
});