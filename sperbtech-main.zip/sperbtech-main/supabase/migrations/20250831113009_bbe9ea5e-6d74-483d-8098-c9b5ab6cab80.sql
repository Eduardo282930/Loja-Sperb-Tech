-- Alterar tabela products para usar IDs do Loyverse (text) em vez de UUID
-- Primeiro, criar uma tabela temporária com a nova estrutura
CREATE TABLE products_new (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC NOT NULL,
  image_url TEXT,
  stock INTEGER DEFAULT 0,
  sku TEXT,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Migrar dados existentes (se houver) convertendo UUID para text
INSERT INTO products_new (id, name, description, price, image_url, stock, sku, display_order, created_at, updated_at)
SELECT id::text, name, description, price, image_url, stock, sku, display_order, created_at, updated_at
FROM products;

-- Remover tabela antiga e renomear a nova
DROP TABLE products;
ALTER TABLE products_new RENAME TO products;

-- Recriar trigger para updated_at
CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Recriar políticas RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view products" 
ON products 
FOR SELECT 
USING (true);

CREATE POLICY "Only authenticated users can create products" 
ON products 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Only authenticated users can update products" 
ON products 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Only authenticated users can delete products" 
ON products 
FOR DELETE 
USING (auth.uid() IS NOT NULL);