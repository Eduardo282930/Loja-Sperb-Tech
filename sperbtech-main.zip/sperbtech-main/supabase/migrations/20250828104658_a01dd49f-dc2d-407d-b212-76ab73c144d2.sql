-- Create products table for seller to manage inventory
CREATE TABLE public.products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC NOT NULL,
  image_url TEXT,
  stock INTEGER DEFAULT 0,
  sku TEXT,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Create policies for products
CREATE POLICY "Anyone can view products" 
ON public.products 
FOR SELECT 
USING (true);

CREATE POLICY "Only authenticated users can create products" 
ON public.products 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Only authenticated users can update products" 
ON public.products 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Only authenticated users can delete products" 
ON public.products 
FOR DELETE 
USING (auth.uid() IS NOT NULL);

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON public.products
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert some default products to match the existing mock data
INSERT INTO public.products (name, description, price, image_url, stock, sku, display_order) VALUES
('Smartphone Galaxy Pro', 'Smartphone com tela de 6.7" e câmera tripla de 108MP', 1299.99, '/api/placeholder/300/300', 15, 'PHONE-001', 1),
('Notebook UltraBook', 'Notebook com processador Intel i7, 16GB RAM e 512GB SSD', 2499.99, '/api/placeholder/300/300', 8, 'NB-001', 2),
('Fone Bluetooth Premium', 'Fone com cancelamento de ruído e bateria de 30h', 299.99, '/api/placeholder/300/300', 25, 'FONE-001', 3),
('Smartwatch Sport', 'Relógio inteligente à prova d''água com GPS', 599.99, '/api/placeholder/300/300', 12, 'WATCH-001', 4),
('Tablet Pro 11"', 'Tablet com tela de 11" e suporte para caneta digital', 899.99, '/api/placeholder/300/300', 6, 'TAB-001', 5),
('Câmera Digital 4K', 'Câmera profissional com gravação em 4K e estabilização', 1899.99, '/api/placeholder/300/300', 4, 'CAM-001', 6),
('Console de Videogame', 'Console de última geração com suporte 4K e 120fps', 2299.99, '/api/placeholder/300/300', 3, 'CONSOLE-001', 7),
('Monitor Gamer 27"', 'Monitor 144Hz com tecnologia G-Sync para gaming', 799.99, '/api/placeholder/300/300', 10, 'MON-001', 8);