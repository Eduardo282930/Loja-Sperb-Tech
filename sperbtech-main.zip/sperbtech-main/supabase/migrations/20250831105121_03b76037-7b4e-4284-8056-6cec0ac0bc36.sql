-- Create customers table
CREATE TABLE public.customers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  email text,
  phone text,
  address text,
  city text,
  cep text,
  loyverse_customer_id text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Create shipping_config table
CREATE TABLE public.shipping_config (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  free_shipping_minimum numeric NOT NULL DEFAULT 200.00,
  base_distance_km integer NOT NULL DEFAULT 5,
  base_price numeric NOT NULL DEFAULT 10.00,
  price_per_extra_km numeric NOT NULL DEFAULT 5.00,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Add customer_id to orders table
ALTER TABLE public.orders 
ADD COLUMN customer_id uuid,
ADD COLUMN shipping_amount numeric DEFAULT 0.00;

-- Enable RLS on new tables
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipping_config ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for customers
CREATE POLICY "Anyone can view customers" 
ON public.customers 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create customers" 
ON public.customers 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Only authenticated users can update customers" 
ON public.customers 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

-- Create RLS policies for shipping_config
CREATE POLICY "Anyone can view shipping config" 
ON public.shipping_config 
FOR SELECT 
USING (true);

CREATE POLICY "Only authenticated users can update shipping config" 
ON public.shipping_config 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Only authenticated users can create shipping config" 
ON public.shipping_config 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_customers_updated_at
  BEFORE UPDATE ON public.customers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_shipping_config_updated_at
  BEFORE UPDATE ON public.shipping_config
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default shipping configuration
INSERT INTO public.shipping_config (free_shipping_minimum, base_distance_km, base_price, price_per_extra_km)
VALUES (200.00, 5, 10.00, 5.00);

-- Add foreign key constraint for customer_id in orders
ALTER TABLE public.orders 
ADD CONSTRAINT fk_orders_customer 
FOREIGN KEY (customer_id) REFERENCES public.customers(id);