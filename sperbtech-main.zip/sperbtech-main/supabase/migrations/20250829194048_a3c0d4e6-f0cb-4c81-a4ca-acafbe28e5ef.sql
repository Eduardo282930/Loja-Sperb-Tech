-- Add loyverse_token to seller_config table
ALTER TABLE public.seller_config 
ADD COLUMN loyverse_token text DEFAULT 'SEU_TOKEN_AQUI'::text;

-- Update orders table to have proper status with enum
CREATE TYPE order_status_enum AS ENUM ('pending', 'confirmed', 'delivered');

-- Add status column with proper enum type if not exists
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'orders' AND column_name = 'status' AND data_type = 'USER-DEFINED') THEN
        ALTER TABLE public.orders 
        ALTER COLUMN status TYPE order_status_enum USING status::order_status_enum;
    END IF;
END $$;