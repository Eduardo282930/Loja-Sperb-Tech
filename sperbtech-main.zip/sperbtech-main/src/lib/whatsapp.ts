import { CartItem } from '@/types/product';

export function generateWhatsAppMessage(cartItems: CartItem[], total: number): string {
  const items = cartItems.map(item => {
    const product = item.product;
    const subtotal = product.price * item.quantity;
    
    return `• *${product.name}*
  📦 Código: ${product.sku || product.id.substring(0, 8)}
  💵 Preço: ${formatCurrency(product.price)}
  🔢 Quantidade: ${item.quantity}x
  💰 Subtotal: ${formatCurrency(subtotal)}
  ${product.image_url ? `🖼️ Foto: ${product.image_url}` : ''}`;
  }).join('\n\n');

  return `🛒 *NOVO PEDIDO - Sperb Tech*

📦 *Produtos do Pedido:*
${items}

━━━━━━━━━━━━━━━━━
💰 *VALOR TOTAL: ${formatCurrency(total)}*
━━━━━━━━━━━━━━━━━

✅ Gostaria de finalizar este pedido!
📱 Aguardo confirmação e detalhes para entrega.`;
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(amount);
}