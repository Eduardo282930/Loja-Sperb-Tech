import { Product, Order, Category } from '@/types/product';
import { 
  Smartphone, 
  Laptop, 
  Headphones, 
  Watch, 
  Camera, 
  Gamepad2,
  Package,
  ShoppingBag,
  Zap,
  Cpu,
  Monitor,
  Tablet,
  Router,
  Music,
  Video
} from 'lucide-react';
import smartphoneImage from '@/assets/smartphone-galaxy-pro.jpg';
import fonesImage from '@/assets/fone-bluetooth-premium.jpg';
import smartwatchImage from '@/assets/smartwatch-sport.jpg';

const BASE_URL = 'https://api.loyverse.com/v1.0';

// Map category names to appropriate icons
function getCategoryIcon(categoryName: string): string {
  const name = categoryName.toLowerCase();
  
  if (name.includes('smartphone') || name.includes('celular') || name.includes('telefone')) return 'Smartphone';
  if (name.includes('notebook') || name.includes('laptop') || name.includes('computador')) return 'Laptop';
  if (name.includes('fone') || name.includes('audio') || name.includes('som') || name.includes('música')) return 'Headphones';
  if (name.includes('watch') || name.includes('relógio') || name.includes('smartwatch')) return 'Watch';
  if (name.includes('camera') || name.includes('câmera') || name.includes('foto')) return 'Camera';
  if (name.includes('game') || name.includes('jogo') || name.includes('console')) return 'Gamepad2';
  if (name.includes('monitor') || name.includes('tela') || name.includes('display')) return 'Monitor';
  if (name.includes('tablet') || name.includes('ipad')) return 'Tablet';
  if (name.includes('router') || name.includes('internet') || name.includes('wifi')) return 'Router';
  if (name.includes('processador') || name.includes('cpu') || name.includes('chip')) return 'Cpu';
  if (name.includes('eletrônicos') || name.includes('tech') || name.includes('tecnologia')) return 'Zap';
  if (name.includes('video') || name.includes('filme') || name.includes('streaming')) return 'Video';
  if (name.includes('música') || name.includes('music') || name.includes('mp3')) return 'Music';
  
  return 'Package'; // Default icon
}

export const loyverseApi = {
  // Get categories from Loyverse API using secure token
  async getCategories(): Promise<Category[]> {
    try {
      const { supabase } = await import('@/integrations/supabase/client');
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'categories',
          method: 'GET',
          useStoredToken: true,
        }
      });

      if (error) {
        console.error('Error fetching categories:', error);
        return [];
      }
      
      const categories = (data as any)?.categories || [];
      return categories.map((category: any) => ({
        id: category.id,
        name: category.name,
        icon: getCategoryIcon(category.name)
      }));
    } catch (error) {
      console.error('Error fetching categories:', error);
      return [];
    }
  },

  // Fetch products from Loyverse API with real-time inventory sync
  async getProducts(): Promise<Product[]> {
    try {
      console.log('🔄 Iniciando busca de produtos e estoque no Loyverse...');
      
      const { supabase } = await import('@/integrations/supabase/client');
      
      // 1. Buscar produtos via /items
      console.log('📄 Buscando produtos via /items...');
      const items = await this.getItems();
      console.log(`✅ Encontrados ${items.length} produtos`);
      
      if (items.length === 0) {
        console.log('📋 Nenhum produto encontrado');
        return [];
      }
      
      // 2. Buscar estoque via /inventory
      console.log('📦 Buscando estoque via /inventory...');
      const inventory = await this.getInventory();
      console.log(`✅ Encontrados ${inventory.length} registros de estoque`);
      
        // 3. Combinar dados usando a função merge otimizada
        console.log('🔄 Executando mergeItemsWithInventory...');
        const products = this.mergeItemsWithInventory(items, inventory);

      console.log(`🎉 Processamento concluído: ${products.length} produtos com estoque atualizado`);
      
      // Log de resumo por estoque
      const comEstoque = products.filter(p => p.stock > 0).length;
      const semEstoque = products.filter(p => p.stock === 0).length;
      const estoqueIlimitado = products.filter(p => p.stock === 999).length;
      
      console.log(`📊 RESUMO DE ESTOQUE:`, {
        comEstoque,
        semEstoque,
        estoqueIlimitado,
        total: products.length
      });

      return products;
      
    } catch (error) {
      console.error('💥 Erro crítico ao buscar produtos:', error);
      throw error;
    }
  },

  // Get items from Loyverse API
  async getItems(): Promise<any[]> {
    try {
      const { supabase } = await import('@/integrations/supabase/client');
      let allItems: any[] = [];
      let cursor = '';
      let page = 1;
      const limit = 250;
      
      do {
        console.log(`📄 Buscando página ${page} de itens...`);
        
        const params: any = { limit };
        if (cursor) {
          params.cursor = cursor;
        }
        
        let responseData: any = null;
        for (let attempt = 0; attempt < 4; attempt++) {
          const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
            body: {
              resource: 'items',
              method: 'GET',
              useStoredToken: true,
              params
            }
          });

          if (!error) {
            responseData = data as any;
            break;
          }

          console.error('❌ Erro na requisição para Loyverse (items):', error);
          const status = (error as any)?.details?.status;
          const message = (error as any)?.message || '';

          if (status === 401) {
            throw new Error('Token Loyverse inválido. Verifique suas configurações.');
          }
          if (message.includes('Missing Loyverse token')) {
            throw new Error('Token Loyverse não configurado nos secrets do Supabase.');
          }
          if (status === 429 || message.includes('429') || message.toLowerCase().includes('rate')) {
            const delay = Math.pow(2, attempt) * 500;
            console.warn(`⚠️ Rate limited em /items (tentativa ${attempt + 1}). Aguardando ${delay}ms`);
            await new Promise((res) => setTimeout(res, delay));
            continue;
          }
          throw new Error(`Erro ao conectar com Loyverse: ${message || 'desconhecido'}`);
        }

        if (!responseData) {
          throw new Error('Falha ao obter /items após tentativas com backoff');
        }

        const items = responseData?.items || [];
        
        if (items.length === 0) {
          console.log('📋 Nenhum item encontrado nesta página, parando...');
          break;
        }
        
        // Função util para converter valores de preço em número
        const toNumber = (v: any) => {
          if (typeof v === 'number') return v;
          const n = parseFloat(String(v ?? '0'));
          return isNaN(n) ? 0 : n;
        };
        
        // Processar itens da página atual
        const pageItems = items
          .filter((item: any) => {
            // Verificar se o item está ativo
            const isActive = item.active !== false;
            if (!isActive) {
              console.log(`⏭️ Item inativo ignorado: ${item.item_name}`);
            }
            return isActive;
          })
          .map((item: any) => {
            // 💰 BUSCAR PREÇO COM ANÁLISE DETALHADA E LOGS
            let price = 0;
            let priceSource = 'unknown';
            
            // 💰 LÓGICA CORRIGIDA: PRIORIZAR PREÇO DA LOJA (stores.price) 
            if (item.sold_by_weight) {
              price = toNumber(item.default_price ?? item.price);
              priceSource = 'sold_by_weight';
            } else if (Array.isArray(item.variants) && item.variants.length > 0) {
              const v = item.variants[0] || {};
              
              // 🎯 PRIORIDADE 1: Preço da loja (mais atualizado)
              if (v.stores && v.stores.length > 0) {
                const storePrice = toNumber(v.stores[0].price);
                if (storePrice > 0) {
                  price = storePrice;
                  priceSource = 'store_price';
                }
              }
              
              // Se não tem preço na loja, usar default_price da variante
              if (price <= 0) {
                price = toNumber(v.default_price ?? v.price);
                priceSource = 'variant_default';
              }
            } else {
              price = toNumber(item.price ?? item.default_price);
              priceSource = 'direct_item';
            }
            
            // 🔴 CRÍTICO: Rejeitar produtos sem preço válido com log detalhado
            if (!price || price <= 0) {
              console.error(`🔴💰 ITEM SEM PREÇO VÁLIDO REJEITADO: "${item.item_name}"`, {
                precoFinal: price,
                fontePreco: priceSource,
                dadosOriginais: {
                  price: item.price,
                  default_price: item.default_price,
                  selling_price: item.selling_price,
                  retail_price: item.retail_price,
                  variants: item.variants?.map(v => ({
                    price: v.price,
                    default_price: v.default_price,
                    selling_price: v.selling_price,
                    retail_price: v.retail_price
                  }))
                },
                timestamp: new Date().toISOString()
              });
              return null;
            }
            
            console.log(`✅💰 PREÇO VÁLIDO CONFIRMADO: "${item.item_name}" - R$ ${price.toFixed(2)} (fonte: ${priceSource})`);
            
            // Verificar se controla estoque
            const trackQuantity = (item as any).track_quantity;
            const trackInventory = (item as any).track_inventory;
            const doesTrackStock = trackQuantity !== false && trackInventory !== false;
            
            return {
              id: item.id,
              name: item.item_name,
              description: item.description || '',
              price: price,
              image_url: item.image_url || '',
              category_id: item.category_id,
              stock: doesTrackStock ? 0 : 999, // Será sobrescrito pelo inventory
              sku: item.variants?.[0]?.sku || '',
              variants: item.variants || []
            };
          })
          .filter((item): item is any => item !== null);
        
        allItems = [...allItems, ...pageItems];
        
        // Verificar se há mais páginas
        let nextCursor: string = '';
        const nextPage = (responseData?.next_page || responseData?.nextPage || responseData?.cursor) as string | undefined;
        if (typeof nextPage === 'string') {
          if (nextPage.startsWith('http')) {
            try {
              const urlObj = new URL(nextPage);
              nextCursor = urlObj.searchParams.get('cursor') || '';
            } catch {
              nextCursor = '';
            }
          } else {
            nextCursor = nextPage;
          }
        }
        cursor = nextCursor;
        page++;
        
      } while (cursor && page <= 50);
      
      console.log(`🎉 Total de itens processados: ${allItems.length}`);
      return allItems;
      
    } catch (error) {
      console.error('💥 Erro ao buscar itens:', error);
      throw error;
    }
  },

  // Sync Loyverse products to local database for offline access
  async syncProductsToDatabase(loyverseProducts: Product[]): Promise<void> {
    try {
      console.log(`🔄 Sincronizando ${loyverseProducts.length} produtos com o banco local...`);
      
      const { supabase } = await import('@/integrations/supabase/client');
      
      let successCount = 0;
      let errorCount = 0;
      
      // Update or insert products from Loyverse
      for (const product of loyverseProducts) {
        console.log(`💾 Salvando produto: ${product.name} (ID: ${product.id})`);
        
        const { error } = await supabase
          .from('products')
          .upsert({
            id: product.id, // Usando ID do Loyverse diretamente
            name: product.name,
            description: product.description,
            price: product.price,
            image_url: product.image_url,
            stock: product.stock,
            sku: product.sku,
            display_order: 0,
            updated_at: new Date().toISOString()
          }, { 
            onConflict: 'id',
            ignoreDuplicates: false 
          });
        
        if (error) {
          console.error(`❌ Erro ao sincronizar produto ${product.name}:`, error);
          errorCount++;
        } else {
          console.log(`✅ Produto ${product.name} sincronizado com sucesso`);
          successCount++;
        }
      }
      
      console.log(`🎯 Sincronização concluída: ${successCount} sucessos, ${errorCount} erros`);
    } catch (error) {
      console.error('💥 Erro crítico na sincronização com banco local:', error);
    }
  },

  // Get real-time inventory from Loyverse using secure token (with pagination)
  async getInventory(): Promise<any[]> {
    try {
      console.log('📦 Buscando estoque em tempo real do Loyverse (com paginação)...');

      const { supabase } = await import('@/integrations/supabase/client');

      let allInventory: any[] = [];
      let cursor = '';
      let page = 1;
      const limit = 250; // máximo permitido

      do {
        const params: any = { limit };
        if (cursor) params.cursor = cursor;

        console.log(`📄 Inventory - página ${page}${cursor ? ` (cursor: ${cursor.substring(0, 8)}...)` : ''}`);

        let response: any = null;
        for (let attempt = 0; attempt < 4; attempt++) {
          const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
            body: {
              resource: 'inventory',
              method: 'GET',
              useStoredToken: true,
              params
            }
          });

          if (!error) {
            response = data as any;
            break;
          }

          console.error('❌ Erro ao buscar /inventory do Loyverse:', error);
          const status = (error as any)?.details?.status;
          const message = (error as any)?.message || '';

          if (status === 401) {
            throw new Error('Token Loyverse inválido. Verifique suas configurações.');
          }
          if (message.includes('Missing Loyverse token')) {
            throw new Error('Token Loyverse não configurado nos secrets do Supabase.');
          }
          if (status === 429 || message.includes('429') || message.toLowerCase().includes('rate')) {
            const delay = Math.pow(2, attempt) * 500;
            console.warn(`⚠️ Rate limited em /inventory (tentativa ${attempt + 1}). Aguardando ${delay}ms`);
            await new Promise((res) => setTimeout(res, delay));
            continue;
          }
          throw new Error(`Erro ao conectar com Loyverse: ${message || 'desconhecido'}`);
        }

        if (!response) {
          throw new Error('Falha ao obter /inventory após tentativas com backoff');
        }

        console.log('📦 Resposta raw do /inventory:', { 
          type: typeof response, 
          keys: Object.keys(response || {}),
          isArray: Array.isArray(response)
        });

        // ✅ CORREÇÃO: Detectar automaticamente a estrutura correta dos dados
        let inventoryArray: any[] = [];
        
        if (Array.isArray(response?.inventory)) {
          inventoryArray = response.inventory;
          console.log('📦 Usando response.inventory');
        } else if (Array.isArray(response?.inventory_levels)) {
          inventoryArray = response.inventory_levels;
          console.log('📦 Usando response.inventory_levels');
        } else if (Array.isArray(response)) {
          inventoryArray = response;
          console.log('📦 Usando response direto (array)');
        } else {
          console.error('📦 Estrutura desconhecida do /inventory:', response);
          inventoryArray = [];
        }

        console.log(`✅ Inventory página ${page}: ${inventoryArray.length} registros`);
        
        // Log das primeiras entradas para debug
        if (inventoryArray.length > 0 && page === 1) {
          console.log('📦 Primeira entrada completa:', inventoryArray[0]);
          console.log('📦 Campos disponíveis:', Object.keys(inventoryArray[0] || {}));
        }
        
        allInventory = [...allInventory, ...inventoryArray];

        // Próxima página
        let nextCursor: string = '';
        const nextPage = (response?.next_page || response?.nextPage || response?.cursor) as string | undefined;
        if (typeof nextPage === 'string') {
          if (nextPage.startsWith('http')) {
            try {
              const urlObj = new URL(nextPage);
              nextCursor = urlObj.searchParams.get('cursor') || '';
            } catch {
              nextCursor = '';
            }
          } else {
            nextCursor = nextPage;
          }
        }

        cursor = nextCursor;
        page++;

      } while (cursor && page <= 50);

      console.log(`📊 Inventory total coletado: ${allInventory.length} registros (em ${page - 1} páginas)`);

      // Log de amostra com diferentes campos possíveis
      if (allInventory.length > 0) {
        const sample = allInventory.slice(0, 3);
        sample.forEach((item: any, i: number) => {
          console.log(`📦 Amostra inventory ${i + 1}:`, {
            item_id: item.item_id,
            variant_id: item.variant_id,
            store_id: item.store_id,
            quantity: item.quantity,
            quantity_on_hand: item.quantity_on_hand,
            available_quantity: item.available_quantity,
            stock: item.stock,
            allFields: Object.keys(item)
          });
        });
      }

      return allInventory;
    } catch (error) {
      console.error('💥 Erro crítico ao buscar inventory:', error);
      throw error;
    }
  },

  // Função merge otimizada conforme especificação do usuário
  mergeItemsWithInventory(items: any[], inventory: any[]): any[] {
    console.log('🔄 Iniciando merge items + inventory com lógica otimizada');
    console.log(`📋 Items recebidos: ${items.length}`);
    console.log(`📦 Inventory records: ${inventory.length}`);
    
    // ✅ CORREÇÃO: Normalizar campos possíveis do inventory
    const getQty = (rec: any) => {
      // Testar todos os campos possíveis de quantidade
      const possibleFields = ['quantity', 'quantity_on_hand', 'available_quantity', 'stock', 'in_stock'];
      
      for (const field of possibleFields) {
        if (typeof rec[field] === 'number' && rec[field] >= 0) {
          return rec[field];
        }
      }
      
      // Se nenhum campo numérico foi encontrado, tentar conversão
      for (const field of possibleFields) {
        if (rec[field] !== undefined && rec[field] !== null) {
          const num = Number(rec[field]);
          if (!isNaN(num) && num >= 0) {
            return num;
          }
        }
      }
      
      return 0;
    };

    // indexar inventory por item_id para busca rápida
    const invByItem = new Map(); // key = item_id, value = array recs
    inventory.forEach(rec => {
      const key = String(rec.item_id);
      if (!invByItem.has(key)) invByItem.set(key, []);
      invByItem.get(key).push(rec);
    });

    console.log(`🗂️ Inventory indexado por ${invByItem.size} item_ids únicos`);

    return items.map(item => {
      let stock = 0;

      // buscar entradas de inventory para este item
      const invEntries = invByItem.get(String(item.id)) || [];
      console.log(`📦 Merge - Item "${item.name}" (${item.id}): ${invEntries.length} inventory entries`);

      if (invEntries.length === 0) {
        console.log(`📦 Merge - Item "${item.name}": sem dados de inventory, mantendo estoque 0`);
        return { ...item, stock: 0 };
      }

      // ✅ LÓGICA CORRIGIDA: Se tem variantes, usar variant_id, senão somar tudo
      if (Array.isArray(item.variants) && item.variants.length > 0) {
        console.log(`📦 Merge - Item com variantes "${item.name}": processando ${item.variants.length} variantes`);
        
        const totalFromVariants = item.variants.reduce((total: number, variant: any) => {
          // ✅ CORREÇÃO CRÍTICA: Usar variant.variant_id ao invés de variant.id
          const variantId = variant.variant_id || variant.id;
          const variantRecs = invEntries.filter((r: any) => String(r.variant_id) === String(variantId));
          const sumVar = variantRecs.reduce((s: number, r: any) => s + Math.max(0, getQty(r)), 0);
          
          console.log(`📦 Merge - Variante ID ${variantId}: ${variantRecs.length} entries → estoque ${sumVar}`);
          
          // Debug: mostrar detalhes da variante se não encontrou registros
          if (variantRecs.length === 0) {
            console.log(`📦 Debug - Variante sem estoque:`, {
              variantData: variant,
              availableVariantIds: invEntries.map(r => r.variant_id),
              searchedId: variantId
            });
          }
          
          return total + sumVar;
        }, 0);
        
        stock = totalFromVariants;
        console.log(`📦 Merge - Produto com variantes "${item.name}": estoque total ${stock}`);
      } else {
        // Produto simples: somar todos os registros sem variant_id ou com variant_id null
        const simpleEntries = invEntries.filter((r: any) => !r.variant_id || r.variant_id === null);
        stock = simpleEntries.reduce((s: number, r: any) => s + Math.max(0, getQty(r)), 0);
        console.log(`📦 Merge - Produto simples "${item.name}": ${simpleEntries.length} entries → estoque ${stock}`);
        
        // Se não encontrou entradas "simples", somar todas (fallback)
        if (simpleEntries.length === 0 && invEntries.length > 0) {
          stock = invEntries.reduce((s: number, r: any) => s + Math.max(0, getQty(r)), 0);
          console.log(`📦 Merge - Produto simples "${item.name}" (fallback): ${invEntries.length} entries → estoque ${stock}`);
        }
      }

      const finalStock = Math.max(0, Math.floor(stock));
      
      if (finalStock > 0) {
        console.log(`✅ Merge - "${item.name}": estoque final ${finalStock}`);
      } else {
        console.log(`⚪ Merge - "${item.name}": estoque final ${finalStock}`);
      }

      return { ...item, stock: finalStock };
    });
  },

  // Test connection using secure token
  async testConnection(): Promise<{ valid: boolean; message: string }> {
    try {
      const { supabase } = await import('@/integrations/supabase/client');

      // 1) Teste básico: /items
      const { data: itemsData, error: itemsError } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'items',
          method: 'GET',
          useStoredToken: true,
          params: { limit: 1 }
        }
      });

      if (itemsError) {
        const err: any = itemsError;
        if (err?.details?.status === 401) {
          return { valid: false, message: 'Token inválido. Verifique suas credenciais.' };
        }
        if (err?.message?.includes('Missing Loyverse token')) {
          return { valid: false, message: 'Token Loyverse não configurado nos secrets do Supabase.' };
        }
        return { valid: false, message: `Erro de conexão (/items): ${err?.message || 'desconhecido'}` };
      }

      // 2) Teste crítico: /inventory (confirma escopo inventory:read e campo quantity)
      const { data: invData, error: invError } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'inventory',
          method: 'GET',
          useStoredToken: true,
          params: { limit: 1 }
        }
      });

      if (invError) {
        const err: any = invError;
        if (err?.details?.status === 401) {
          return { valid: false, message: 'Permissão insuficiente. Garanta o escopo inventory:read no token.' };
        }
        return { valid: false, message: `Erro ao acessar /inventory: ${err?.message || 'desconhecido'}` };
      }

      // Check if inventory data has the expected structure
      const arr = Array.isArray(invData?.inventory_levels) 
        ? invData.inventory_levels 
        : (Array.isArray(invData) ? invData : []);
      
      if (!Array.isArray(arr)) {
        return { valid: false, message: 'Formato inesperado retornado de /inventory.' };
      }

      return { valid: true, message: 'Conexão OK com Loyverse API.' };
    } catch (error: any) {
      return { valid: false, message: `Erro ao testar conexão: ${error.message}` };
    }
  },

  // Submit order to Loyverse using secure token
  async createReceipt(order: Order): Promise<boolean> {
    try {
      const receiptData = {
        source: 'POS',
        receipt_number: `ST-${Date.now()}`,
        total_money: order.total_amount,
        line_items: order.items.map(item => ({
          item_id: item.item_id,
          quantity: item.quantity,
          price: item.price,
          total_money: item.total_price
        })),
        customer: {
          name: order.customer_name,
          email: order.customer_email,
          phone_number: order.customer_phone
        }
      };

      const { supabase } = await import('@/integrations/supabase/client');
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'receipts',
          method: 'POST',
          useStoredToken: true,
          payload: receiptData,
        }
      });

      if (error) {
        console.error('Error creating receipt via proxy:', error);
        return false;
      }

      console.log('Receipt created successfully:', data);
      return !!data;
    } catch (error) {
      console.error('Error creating receipt:', error);
      return false;
    }
  },

  // Get all receipts from Loyverse with pagination support using secure token
  async getReceipts(startDate?: string, endDate?: string): Promise<any[]> {
    try {
      console.log('🧾 Iniciando busca de recibos no Loyverse...');
      
      const { supabase } = await import('@/integrations/supabase/client');
      let allReceipts: any[] = [];
      let cursor = '';
      let page = 1;
      const limit = 250; // Máximo permitido pelo Loyverse
      
      do {
        console.log(`📄 Buscando página ${page} de recibos...`);
        
        const params: any = { limit };
        if (cursor) {
          params.cursor = cursor;
        }
        if (startDate) {
          params.updated_at_min = startDate;
        }
        if (endDate) {
          params.updated_at_max = endDate;
        }
        
        const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
          body: {
            resource: 'receipts',
            method: 'GET',
            useStoredToken: true,
            params
          }
        });

        if (error) {
          console.error('❌ Erro na requisição de recibos:', error);
          
          if ((error as any)?.details?.status === 401) {
            throw new Error('Token Loyverse inválido. Verifique suas configurações.');
          }
          if ((error as any)?.message?.includes('Missing Loyverse token')) {
            throw new Error('Token Loyverse não configurado nos secrets do Supabase.');
          }
          throw new Error(`Erro ao conectar com Loyverse: ${(error as any)?.message || 'desconhecido'}`);
        }
        
        const responseData = data as any;
        const receipts = responseData?.receipts || [];
        
        console.log(`✅ Encontrados ${receipts.length} recibos na página ${page}`);
        
        if (receipts.length === 0) {
          console.log('📋 Nenhum recibo encontrado nesta página, parando...');
          break;
        }
        
        // Processar recibos da página atual
        const pageReceipts = receipts.map((receipt: any) => ({
          id: receipt.id,
          receipt_number: receipt.receipt_number,
          created_at: receipt.created_at,
          total_money: receipt.total_money,
          status: receipt.status || 'completed',
          line_items: receipt.line_items || [],
          customer: receipt.customer || null,
          payments: receipt.payments || [],
          source: receipt.source,
          taxes: receipt.taxes || []
        }));
        
        allReceipts = [...allReceipts, ...pageReceipts];
        
        // Verificar se há mais páginas (cursor ou next_page)
        let nextCursor: string = '';
        const nextPage = (responseData?.next_page || responseData?.nextPage || responseData?.cursor) as string | undefined;
        if (typeof nextPage === 'string') {
          if (nextPage.startsWith('http')) {
            try {
              const urlObj = new URL(nextPage);
              nextCursor = urlObj.searchParams.get('cursor') || '';
            } catch {
              nextCursor = '';
            }
          } else {
            nextCursor = nextPage;
          }
        }
        cursor = nextCursor;
        page++;
        
        console.log(`📊 Total de recibos coletados até agora: ${allReceipts.length}`);
        
      } while (cursor && page <= 50); // Limite de segurança de 50 páginas
      
      console.log(`🎉 Busca de recibos concluída! Total encontrado: ${allReceipts.length}`);
      
      return allReceipts;
    } catch (error) {
      console.error('💥 Erro crítico ao buscar recibos:', error);
      throw error;
    }
  },


  // Get product details with variants
  async getProductDetails(productId: string): Promise<any> {
    try {
      const { supabase } = await import('@/integrations/supabase/client');
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: `items/${productId}`,
          method: 'GET',
          useStoredToken: true,
        }
      });

      if (error) throw error;
      
      return data;
    } catch (error) {
      console.error('Error fetching product details:', error);
      throw error;
    }
  },

  // Get current stock levels for a product
  async getProductStock(productId: string): Promise<number> {
    try {
      const productDetails = await this.getProductDetails(productId);
      
      let totalStock = 0;
      if (productDetails.track_quantity === false) {
        return 999; // Produto sem controle de estoque
      } else if (productDetails.variants?.length > 0) {
        // Somar estoque de todos os variants
        totalStock = productDetails.variants.reduce((total: number, variant: any) => {
          return total + (variant.stock_quantity || 0);
        }, 0);
      } else {
        totalStock = productDetails.stock_quantity || 0;
      }
      
      return totalStock;
    } catch (error) {
      console.error('Error fetching product stock:', error);
      return 0;
    }
  }
};