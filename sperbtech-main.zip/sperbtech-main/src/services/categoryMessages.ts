// Serviço para gerenciar mensagens chamativas por categoria
interface CategoryMessage {
  categoryId: string;
  categoryName: string;
  message: string;
  emoji: string;
}

export const categoryMessages: CategoryMessage[] = [
  {
    categoryId: 'carnes',
    categoryName: 'Carnes',
    message: 'Oferta especial em cortes selecionados',
    emoji: '🔥'
  },
  {
    categoryId: 'frango',
    categoryName: 'Frango',
    message: 'Melhor preço garantido',
    emoji: '🥇'
  },
  {
    categoryId: 'peixes',
    categoryName: 'Peixes',
    message: 'Frescos e selecionados',
    emoji: '🐟'
  },
  {
    categoryId: 'bebidas',
    categoryName: 'Bebidas',
    message: 'Promoção imperdível',
    emoji: '🥤'
  },
  {
    categoryId: 'laticinios',
    categoryName: 'Laticínios',
    message: 'Produtos frescos direto do produtor',
    emoji: '🥛'
  },
  {
    categoryId: 'paes',
    categoryName: 'Pães',
    message: 'Fresquinhos todos os dias',
    emoji: '🍞'
  },
  {
    categoryId: 'frutas',
    categoryName: 'Frutas',
    message: 'Selecionadas e frescas',
    emoji: '🍎'
  },
  {
    categoryId: 'verduras',
    categoryName: 'Verduras',
    message: 'Colhidas hoje pela manhã',
    emoji: '🥬'
  },
  {
    categoryId: 'congelados',
    categoryName: 'Congelados',
    message: 'Qualidade premium congelada',
    emoji: '❄️'
  },
  {
    categoryId: 'limpeza',
    categoryName: 'Limpeza',
    message: 'Promoção relâmpago',
    emoji: '🧽'
  }
];

class CategoryMessagesService {
  // Obter mensagem para uma categoria específica
  getMessageForCategory(categoryId: string): CategoryMessage | null {
    return categoryMessages.find(msg => 
      msg.categoryId.toLowerCase() === categoryId.toLowerCase() ||
      msg.categoryName.toLowerCase().includes(categoryId.toLowerCase())
    ) || null;
  }

  // Obter mensagem aleatória
  getRandomMessage(): CategoryMessage {
    const randomIndex = Math.floor(Math.random() * categoryMessages.length);
    return categoryMessages[randomIndex];
  }

  // Obter todas as mensagens
  getAllMessages(): CategoryMessage[] {
    return categoryMessages;
  }

  // Atualizar mensagem de uma categoria
  updateMessage(categoryId: string, newMessage: string): void {
    const messageIndex = categoryMessages.findIndex(msg => 
      msg.categoryId.toLowerCase() === categoryId.toLowerCase()
    );
    
    if (messageIndex !== -1) {
      categoryMessages[messageIndex].message = newMessage;
    }
  }
}

export const categoryMessagesService = new CategoryMessagesService();