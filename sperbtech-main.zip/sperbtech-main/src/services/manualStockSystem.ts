import { supabase } from '@/integrations/supabase/client';
import { manualStockSync } from './manualStockSync';

interface StockUpdate {
  productId: string;
  newStock: number;
  productName: string;
  timestamp: Date;
}

class ManualStockSystem {
  // Atualizar estoque manualmente (apenas pelo admin)
  async updateStock(productId: string, newStock: number, productName: string): Promise<boolean> {
    try {
      // Atualizar no banco de dados
      const { error } = await supabase
        .from('products')
        .update({ 
          stock: newStock,
          updated_at: new Date().toISOString() 
        })
        .eq('id', productId);

      if (error) {
        console.error('Erro ao atualizar estoque:', error);
        return false;
      }

      // Notificar o sistema de sync em tempo real para os clientes
      await manualStockSync.updateProductStock(productId, newStock, productName);

      console.log(`✅ Estoque atualizado: ${productName} → ${newStock} unidades`);
      return true;
    } catch (error) {
      console.error('Erro ao atualizar estoque:', error);
      return false;
    }
  }

  // Reduzir estoque após venda (automático)
  async reduceStockAfterSale(productId: string, quantity: number, productName: string): Promise<boolean> {
    try {
      // Buscar estoque atual
      const { data: product, error: fetchError } = await supabase
        .from('products')
        .select('stock')
        .eq('id', productId)
        .single();

      if (fetchError || !product) {
        console.error('Erro ao buscar produto para redução de estoque:', fetchError);
        return false;
      }

      // Calcular novo estoque (não pode ficar negativo)
      const newStock = Math.max(0, product.stock - quantity);

      // Atualizar estoque
      const { error } = await supabase
        .from('products')
        .update({ 
          stock: newStock,
          updated_at: new Date().toISOString() 
        })
        .eq('id', productId);

      if (error) {
        console.error('Erro ao reduzir estoque:', error);
        return false;
      }

      console.log(`📦 Estoque reduzido por venda: ${productName} ${product.stock} → ${newStock} (-${quantity})`);
      return true;
    } catch (error) {
      console.error('Erro ao reduzir estoque:', error);
      return false;
    }
  }

  // Sincronizar apenas preços (não estoque) do Loyverse
  async syncPricesFromLoyverse(loyverseProducts: any[]): Promise<void> {
    try {
      console.log('🔄 Sincronizando apenas PREÇOS do Loyverse (estoque permanece manual)...');

      for (const product of loyverseProducts) {
        if (product.price && product.price > 0) {
          await supabase
            .from('products')
            .update({ 
              price: product.price,
              name: product.name, // Atualizar nome também
              description: product.description,
              image_url: product.image_url,
              // NÃO atualizar estoque - apenas preços!
            })
            .eq('id', product.id);

          console.log(`💰 Preço atualizado: ${product.name} → R$ ${product.price.toFixed(2)}`);
        }
      }

      console.log('✅ Sincronização de preços concluída (estoque mantido manual)');
    } catch (error) {
      console.error('Erro na sincronização de preços:', error);
      throw error;
    }
  }

  // Obter produtos do banco local (estoque manual)
  async getProducts(): Promise<any[]> {
    try {
      const { data: products, error } = await supabase
        .from('products')
        .select('*')
        .order('name');

      if (error) {
        console.error('Erro ao buscar produtos:', error);
        return [];
      }

      console.log(`📊 Produtos carregados do banco local: ${products.length}`);
      return products || [];
    } catch (error) {
      console.error('Erro ao buscar produtos:', error);
      return [];
    }
  }

  // Processar venda e reduzir estoque automaticamente
  async processSale(saleItems: { productId: string; quantity: number; productName: string }[]): Promise<boolean> {
    try {
      console.log('🛒 Processando venda e reduzindo estoque...');

      let allSuccess = true;
      for (const item of saleItems) {
        const success = await this.reduceStockAfterSale(
          item.productId,
          item.quantity,
          item.productName
        );
        if (!success) {
          allSuccess = false;
        }
      }

      if (allSuccess) {
        console.log('✅ Todos os estoques reduzidos com sucesso');
      } else {
        console.warn('⚠️ Alguns estoques não foram reduzidos corretamente');
      }

      return allSuccess;
    } catch (error) {
      console.error('Erro ao processar venda:', error);
      return false;
    }
  }
}

export const manualStockSystem = new ManualStockSystem();