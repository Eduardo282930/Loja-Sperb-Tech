// Serviço para gerenciar alterações manuais de estoque
interface ManualStockChange {
  productId: string;
  newStock: number;
  timestamp: number;
  productName: string;
}

class ManualStockChangesService {
  private storageKey = 'manual_stock_changes';

  // Salvar uma alteração manual de estoque
  saveManualChange(productId: string, newStock: number, productName: string): void {
    const changes = this.getManualChanges();
    const change: ManualStockChange = {
      productId,
      newStock,
      timestamp: Date.now(),
      productName
    };

    // Remove alteração anterior do mesmo produto se existir
    const filteredChanges = changes.filter(c => c.productId !== productId);
    filteredChanges.push(change);

    localStorage.setItem(this.storageKey, JSON.stringify(filteredChanges));
    console.log(`💾 Alteração manual salva: ${productName} -> ${newStock} unidades`);
  }

  // Obter todas as alterações manuais
  private getManualChanges(): ManualStockChange[] {
    try {
      const stored = localStorage.getItem(this.storageKey);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Erro ao ler alterações manuais:', error);
      return [];
    }
  }

  // Verificar se um produto foi alterado manualmente
  hasManualChange(productId: string): boolean {
    const changes = this.getManualChanges();
    return changes.some(c => c.productId === productId);
  }

  // Obter o estoque manual de um produto se foi alterado
  getManualStock(productId: string): number | null {
    const changes = this.getManualChanges();
    const change = changes.find(c => c.productId === productId);
    return change?.newStock ?? null;
  }

  // Limpar alterações antigas (mais de 1 dia)
  cleanOldChanges(): void {
    const changes = this.getManualChanges();
    const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
    
    const recentChanges = changes.filter(c => c.timestamp > oneDayAgo);
    
    if (recentChanges.length !== changes.length) {
      localStorage.setItem(this.storageKey, JSON.stringify(recentChanges));
      console.log(`🧹 Limpeza: ${changes.length - recentChanges.length} alterações antigas removidas`);
    }
  }

  // Obter todas as alterações manuais
  getAllManualChanges(): ManualStockChange[] {
    return this.getManualChanges();
  }

  // Remover uma alteração manual específica
  removeManualChange(productId: string): void {
    const changes = this.getManualChanges();
    const filteredChanges = changes.filter(c => c.productId !== productId);
    localStorage.setItem(this.storageKey, JSON.stringify(filteredChanges));
  }
}

export const manualStockChanges = new ManualStockChangesService();