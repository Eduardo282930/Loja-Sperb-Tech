// Serviço para monitorar recibos do Loyverse e reduzir estoque automaticamente
import { loyverseApi } from './loyverse';
import { stockSyncService } from './stockSync';
import { supabase } from '@/integrations/supabase/client';

interface ReceiptItem {
  item_id: string;
  product_id: string;
  quantity: number;
  variant_id?: string;
}

class LoyverseReceiptMonitor {
  private isMonitoring = false;
  private lastCheck?: Date;
  private intervalId?: NodeJS.Timeout;

  // Iniciar monitoramento de recibos
  async startMonitoring() {
    if (this.isMonitoring) return;
    
    try {
      // Testar conexão antes de iniciar
      const connectionTest = await loyverseApi.testConnection();
      if (!connectionTest.valid) {
        console.log('⚠️ Loyverse não conectado - monitoramento de vendas desabilitado');
        return;
      }

      console.log('🚀 INICIANDO MONITORAMENTO DE VENDAS LOYVERSE...');
      this.isMonitoring = true;
      this.lastCheck = new Date();

      // Verificar vendas a cada 10 segundos
      this.intervalId = setInterval(() => {
        this.checkForNewReceipts();
      }, 10000);

      console.log('✅ Monitoramento de vendas ativo - verificando a cada 10 segundos');
    } catch (error) {
      console.error('❌ Erro ao iniciar monitoramento:', error);
    }
  }

  // Parar monitoramento
  stopMonitoring() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = undefined;
    }
    this.isMonitoring = false;
    console.log('⏹️ Monitoramento de vendas pausado');
  }

  // Verificar novos recibos desde a última verificação
  private async checkForNewReceipts() {
    if (!this.lastCheck || !this.isMonitoring) return;

    try {
      console.log('🔍 Verificando novas vendas no Loyverse...');
      
      // Buscar recibos desde a última verificação
      const startDate = this.lastCheck.toISOString();
      const receipts = await loyverseApi.getReceipts(startDate);
      
      const newReceipts = receipts.filter(receipt => 
        new Date(receipt.created_at) > this.lastCheck! && 
        receipt.status === 'completed'
      );

      if (newReceipts.length > 0) {
        console.log(`🎉 ${newReceipts.length} nova(s) venda(s) detectada(s)!`);
        
        for (const receipt of newReceipts) {
          await this.processReceiptSale(receipt);
        }
      }

      this.lastCheck = new Date();
    } catch (error) {
      console.error('❌ Erro ao verificar recibos:', error);
    }
  }

  // Processar uma venda e reduzir estoque
  private async processReceiptSale(receipt: any) {
    try {
      console.log(`📝 Processando venda: ${receipt.receipt_number}`);
      
      if (!receipt.line_items || receipt.line_items.length === 0) {
        console.warn('⚠️ Recibo sem itens, ignorando...');
        return;
      }

      // Extrair itens vendidos
      const saleItems = receipt.line_items.map((item: any) => ({
        product_id: item.item_id || item.product_id,
        sku: item.sku,
        quantity: item.quantity || 1
      }));

      // Reduzir estoque local
      const success = await stockSyncService.reduceStock(saleItems);
      
      if (success) {
        // Log da venda processada
        console.log(`✅ Estoque reduzido para venda: ${receipt.receipt_number}`);
      } else {
        console.error(`❌ Falha ao reduzir estoque para venda: ${receipt.receipt_number}`);
      }
    } catch (error) {
      console.error('❌ Erro ao processar venda:', error);
    }
  }

  // Verificar se está monitorando
  isActive(): boolean {
    return this.isMonitoring;
  }

  // Forçar verificação manual
  async forceCheck() {
    if (this.isMonitoring) {
      await this.checkForNewReceipts();
    }
  }
}

export const loyverseReceiptMonitor = new LoyverseReceiptMonitor();