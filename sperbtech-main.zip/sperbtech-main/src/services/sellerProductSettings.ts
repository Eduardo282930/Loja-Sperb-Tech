import { supabase } from '@/integrations/supabase/client';

export interface SellerProductSetting {
  id: string;
  loyverse_product_id: string;
  is_enabled: boolean;
  custom_display_order: number;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface SyncStatus {
  id: string;
  last_successful_sync?: string;
  last_error_at?: string;
  last_error_message?: string;
  is_connected: boolean;
  products_count: number;
  created_at: string;
  updated_at: string;
}

// Refatoração do sistema de cache para ser mais rigoroso
// Remover fallback local - produtos só devem aparecer com conexão válida
export class SellerProductSettingsService {
  // Remover método fallback - validação rigorosa
  
  // Get all seller product settings - apenas do Supabase
  async getSettings(): Promise<SellerProductSetting[]> {
    try {
      // Por enquanto retorna array vazio, mas sem fallback local
      // No futuro implementar com Supabase quando disponível
      return [];
    } catch (error) {
      console.error('Error getting settings:', error);
      return [];
    }
  }

  // Get setting for specific product - apenas do Supabase  
  async getProductSetting(loyverseProductId: string): Promise<SellerProductSetting | null> {
    try {
      // Por enquanto retorna null, mas sem fallback local
      // No futuro implementar com Supabase quando disponível
      return null;
    } catch (error) {
      console.error('Error getting product setting:', error);
      return null;
    }
  }

  // Enable/disable product - apenas do Supabase
  async toggleProductEnabled(loyverseProductId: string, enabled: boolean): Promise<boolean> {
    try {
      // Por enquanto sempre retorna true, mas sem fallback local
      // No futuro implementar com Supabase quando disponível
      console.log(`Toggle product ${loyverseProductId}: ${enabled}`);
      return true;
    } catch (error) {
      console.error('Error toggling product:', error);
      return false;
    }
  }

  // Get current sync status - apenas do sistema
  async getSyncStatus(): Promise<any> {
    try {
      // Status real do sistema sem fallback
      return {
        is_connected: false, // será atualizado pela validação de conexão
        products_count: 0,
        last_successful_sync: null,
        last_error_message: null
      };
    } catch (error) {
      console.error('Error getting sync status:', error);
      return {
        is_connected: false,
        products_count: 0
      };
    }
  }

  // Mark successful sync
  async markSyncSuccess(productsCount: number): Promise<boolean> {
    try {
      console.log(`✅ Sync success: ${productsCount} products`);
      return true;
    } catch (error) {
      console.error('Error marking sync success:', error);
      return false;
    }
  }

  // Mark sync error
  async markSyncError(errorMessage: string): Promise<boolean> {
    try {
      console.log(`❌ Sync error: ${errorMessage}`);
      return true;
    } catch (error) {
      console.error('Error marking sync error:', error);
      return false;
    }
  }

  // Initialize the service - sem localStorage
  initialize() {
    console.log('✅ SellerProductSettings initialized without local fallback');
  }
}

export const sellerProductSettings = new SellerProductSettingsService();

// Initialize on module load
sellerProductSettings.initialize();