// Service para monitoramento de vendas (não sincronização de estoque)
import { loyverseApi } from './loyverse';
import { sellerProductSettings } from './sellerProductSettings';
import { loyverseReceiptMonitor } from './loyverseReceiptMonitor';

class RealTimeSyncService {
  private subscribers: Array<() => void> = [];
  private lastSyncSuccess: boolean = false;

  // Desabilitado: apenas estoque manual agora
  async initializeSync() {
    console.log('📦 ESTOQUE MANUAL ATIVO - Sincronização automática com Loyverse desabilitada');
    console.log('ℹ️ O estoque será controlado apenas manualmente no painel do vendedor');
    console.log('ℹ️ Apenas vendas e cancelamentos feitos no app irão ajustar o estoque');
    
    this.lastSyncSuccess = true;
  }

  // Parar monitoramento
  stopSync() {
    // Parar monitoramento de vendas
    loyverseReceiptMonitor.stopMonitoring();
    this.lastSyncSuccess = false;
  }

  // Verificar se o monitoramento está ativo
  isLastSyncSuccessful(): boolean {
    return this.lastSyncSuccess;
  }


  // Sistema de subscribers para notificar componentes sobre atualizações
  subscribe(callback: () => void) {
    this.subscribers.push(callback);
    return () => {
      this.subscribers = this.subscribers.filter(sub => sub !== callback);
    };
  }

  private notifySubscribers() {
    this.subscribers.forEach(callback => callback());
  }

  // Buscar todos os recibos do Loyverse usando token seguro
  async getReceipts(): Promise<any[]> {
    try {
      return await loyverseApi.getReceipts();
    } catch (error) {
      console.error('Erro ao buscar recibos:', error);
      return [];
    }
  }
}

export const realTimeSyncService = new RealTimeSyncService();