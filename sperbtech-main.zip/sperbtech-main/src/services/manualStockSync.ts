// Serviço para atualização de estoque em tempo real para o vendedor
import { manualStockChanges } from './manualStockChanges';

class ManualStockSyncService {
  private subscribers: Array<(productId: string, newStock: number) => void> = [];

  // Subscrever às mudanças de estoque
  subscribe(callback: (productId: string, newStock: number) => void) {
    this.subscribers.push(callback);
    return () => {
      this.subscribers = this.subscribers.filter(sub => sub !== callback);
    };
  }

  // Notificar subscribers sobre mudança de estoque
  private notifyStockChange(productId: string, newStock: number) {
    this.subscribers.forEach(callback => callback(productId, newStock));
  }

  // Atualizar estoque de um produto e notificar em tempo real
  async updateProductStock(productId: string, newStock: number, productName: string = 'Produto'): Promise<boolean> {
    try {
      // Salvar no sistema de estoque manual existente
      manualStockChanges.saveManualChange(productId, newStock, productName);

      // Notificar todos os subscribers sobre a mudança
      this.notifyStockChange(productId, newStock);
      
      console.log(`✅ Estoque atualizado em tempo real: Produto ${productId} → ${newStock} unidades`);
      return true;
    } catch (error) {
      console.error('Erro ao atualizar estoque:', error);
      return false;
    }
  }

  // Buscar estoque manual atual de um produto
  getProductStock(productId: string): number | null {
    return manualStockChanges.getManualStock(productId);
  }
}

export const manualStockSync = new ManualStockSyncService();