import { supabase } from '@/integrations/supabase/client';
import { loyverseApi } from './loyverse';

interface SaleItem {
  product_id: string;
  sku?: string;
  quantity: number;
}

class StockSyncService {
  // Reduzir estoque local baseado numa venda
  async reduceStock(items: SaleItem[]): Promise<boolean> {
    try {
      console.log('🔽 Reduzindo estoque local para itens:', items);

      for (const item of items) {
        // Buscar produto atual
        const { data: product, error: fetchError } = await supabase
          .from('products')
          .select('id, name, stock, sku')
          .eq('id', item.product_id)
          .single();

        if (fetchError) {
          console.error(`Erro ao buscar produto ${item.product_id}:`, fetchError);
          continue;
        }

        if (!product) {
          console.warn(`Produto ${item.product_id} não encontrado`);
          continue;
        }

        // Calcular novo estoque
        const newStock = Math.max(0, product.stock - item.quantity);
        
        // Atualizar estoque
        const { error: updateError } = await supabase
          .from('products')
          .update({ stock: newStock })
          .eq('id', item.product_id);

        if (updateError) {
          console.error(`Erro ao atualizar estoque do produto ${item.product_id}:`, updateError);
          continue;
        }

        console.log(`✅ Produto ${product.name}: ${product.stock} → ${newStock} (vendeu ${item.quantity})`);
      }

      return true;
    } catch (error) {
      console.error('❌ Erro ao reduzir estoque:', error);
      return false;
    }
  }

  // Criar recibo no Loyverse e reduzir estoque local
  async processOrderSale(orderData: any): Promise<{ success: boolean; receiptId?: string }> {
    try {
      console.log('🔄 Processando venda no Loyverse e reduzindo estoque...');
      
      // Tentar criar recibo no Loyverse
      let loyverseSuccess = false;
      let receiptId = '';

      try {
        const receiptCreated = await loyverseApi.createReceipt(orderData);
        if (receiptCreated) {
          loyverseSuccess = true;
          receiptId = `LV-${Date.now()}`;
          console.log('✅ Recibo criado no Loyverse:', receiptId);
        }
      } catch (loyverseError) {
        console.warn('⚠️ Falha ao criar recibo no Loyverse:', loyverseError);
        // Continuamos mesmo se o Loyverse falhar
      }

      // Sempre reduzir estoque local (independente do Loyverse)
      const items = orderData.items.map((item: any) => ({
        product_id: item.item_id,
        sku: item.sku,
        quantity: item.quantity
      }));

      const stockReduced = await this.reduceStock(items);
      
      if (stockReduced) {
        console.log('✅ Estoque local reduzido com sucesso');
      } else {
        console.warn('⚠️ Falha ao reduzir estoque local');
      }

      return {
        success: loyverseSuccess || stockReduced, // Sucesso se pelo menos um funcionar
        receiptId: receiptId || undefined
      };
    } catch (error) {
      console.error('❌ Erro ao processar venda:', error);
      return { success: false };
    }
  }
}

export const stockSyncService = new StockSyncService();