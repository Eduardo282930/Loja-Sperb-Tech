export interface Product {
  id: string;
  name: string;
  description?: string;
  price: number;
  image_url?: string;
  category_id?: string;
  stock?: number;
  sku?: string;
  // Removido rating e reviews_count por solicitação
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  icon?: string;
}

export interface OrderItem {
  item_id: string;
  quantity: number;
  price: number;
  total_price: number;
}

export interface Order {
  customer_name: string;
  customer_email?: string;
  customer_phone?: string;
  delivery_address: string;
  payment_method: 'cash' | 'pix' | 'card';
  items: OrderItem[];
  total_amount: number;
}