import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ShoppingCart, 
  Plus, 
  Minus, 
  Trash2, 
  ArrowLeft,
  MessageCircle
} from 'lucide-react';
import { generateWhatsAppMessage } from '@/lib/whatsapp';

const Cart = () => {
  const { state, updateQuantity, removeItem, clearCart } = useCart();
  const navigate = useNavigate();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  const finalTotal = state.total;

  const handleFinalizePurchase = () => {
    const message = generateWhatsAppMessage(state.items, state.total);
    const whatsappNumber = localStorage.getItem('whatsapp_number') || '51996109657';
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/${whatsappNumber}?text=${encodedMessage}`, '_blank');
  };

  if (state.items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <div className="bg-orange-soft rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <ShoppingCart className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Seu carrinho está vazio
            </h2>
            <p className="text-muted-foreground mb-8">
              Adicione alguns produtos incríveis ao seu carrinho
            </p>
            <Button asChild size="lg">
              <Link to="/catalog">
                Continuar Comprando
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-foreground">Carrinho</h1>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/catalog">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Continuar Comprando
            </Link>
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-3">
            {state.items.map((item) => (
              <Card 
                key={item.product.id}
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => navigate(`/product/${item.product.id}`)}
              >
                <CardContent className="p-3">
                  <div className="flex items-start gap-2">
                    <img
                      src={item.product.image_url || '/api/placeholder/80/80'}
                      alt={item.product.name}
                      className="w-14 h-14 object-cover rounded-md flex-shrink-0"
                    />
                    
                    <div className="flex-1 min-w-0 space-y-1">
                      <h3 className="font-semibold text-xs text-foreground leading-tight line-clamp-2">
                        {item.product.name}
                      </h3>
                      <p className="text-sm font-bold text-primary">
                        {formatPrice(item.product.price)}
                      </p>
                      
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-6 w-6"
                            onClick={(e) => {
                              e.stopPropagation();
                              updateQuantity(item.product.id, item.quantity - 1);
                            }}
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="h-2.5 w-2.5" />
                          </Button>
                          
                          <span className="w-6 text-center font-medium text-xs">
                            {item.quantity}
                          </span>
                          
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-6 w-6"
                            onClick={(e) => {
                              e.stopPropagation();
                              updateQuantity(item.product.id, item.quantity + 1);
                            }}
                          >
                            <Plus className="h-2.5 w-2.5" />
                          </Button>
                        </div>

                        <div className="flex items-center gap-1">
                          <p className="font-bold text-foreground text-xs whitespace-nowrap">
                            {formatPrice(item.product.price * item.quantity)}
                          </p>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={(e) => {
                              e.stopPropagation();
                              removeItem(item.product.id);
                            }}
                          >
                            <Trash2 className="h-2.5 w-2.5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div>
            <Card className="sticky top-24 bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Resumo do Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-center">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-1">Total</p>
                    <p className="text-2xl font-bold text-primary">{formatPrice(finalTotal)}</p>
                  </div>
                </div>
                
                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={handleFinalizePurchase}
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Finalizar pelo WhatsApp
                </Button>
                
                <div className="text-xs text-center text-muted-foreground bg-muted p-2 rounded">
                  Você será redirecionado para o WhatsApp
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;