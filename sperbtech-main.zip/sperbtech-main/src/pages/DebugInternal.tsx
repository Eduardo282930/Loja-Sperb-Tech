import { CatalogStockDebug } from '@/components/debug/CatalogStockDebug';
import { ProductDebug } from '@/components/debug/ProductDebug';
import { EstoqueDebugPanel } from '@/components/debug/EstoqueDebugPanel';
import { RealTimeStockValidator } from '@/components/debug/RealTimeStockValidator';
import LoyverseTest from '@/components/debug/LoyverseTest';
import { SyncTestSummary } from '@/components/debug/SyncTestSummary';
import { StockTestTool } from '@/components/debug/StockTestTool';
import { StockDebug } from '@/components/debug/StockDebug';
import InventoryProbe from '@/components/debug/InventoryProbe';
import { PriceRealtimeDebugger } from '@/components/debug/PriceRealtimeDebugger';
import StockRealtimeMonitor from '@/components/debug/StockRealtimeMonitor';
import { QuickInventoryTest } from '@/components/debug/QuickInventoryTest';
import { StockValidationTest } from '@/components/debug/StockValidationTest';
import { CatalogStockRefresh } from '@/components/debug/CatalogStockRefresh';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle } from 'lucide-react';

const DebugInternal = () => {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="container mx-auto space-y-6">
        {/* Warning Banner */}
        <Card className="border-orange-500 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <AlertTriangle className="h-5 w-5" />
              Ferramenta de Debug Interno
            </CardTitle>
            <CardDescription className="text-orange-700">
              Esta página é apenas para uso interno do desenvolvedor. 
              Não deve aparecer no app para usuários finais.
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Navigation */}
        <div className="flex flex-wrap gap-2 mb-6">
          <Badge variant="outline">Preços Tempo Real</Badge>
          <Badge variant="outline">Estoque Loyverse</Badge>
          <Badge variant="outline">Sincronização</Badge>
          <Badge variant="outline">Validação</Badge>
          <Badge variant="outline">Testes</Badge>
        </div>

        {/* Debug Components */}
        <div className="space-y-8">
          <QuickInventoryTest />
          <StockValidationTest />
          <CatalogStockRefresh />
          <InventoryProbe />
          <StockRealtimeMonitor />
          <PriceRealtimeDebugger />
          <StockTestTool />
          <CatalogStockDebug />
          <ProductDebug />
          <StockDebug />
          <LoyverseTest />
          <RealTimeStockValidator />
          <EstoqueDebugPanel />
          <SyncTestSummary />
        </div>
      </div>
    </div>
  );
};

export default DebugInternal;