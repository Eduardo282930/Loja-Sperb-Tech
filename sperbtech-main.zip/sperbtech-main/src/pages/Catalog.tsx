import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Product } from '@/types/product';
import { useProducts } from '@/contexts/ProductContext';
import { useCategories } from '@/contexts/CategoryContext';

import ProductCard from '@/components/product/OptimizedProductCard';
import CategoryIcon from '@/components/CategoryIcon';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Filter, 
  SortAsc, 
  Grid3X3,
  List
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ConnectionGuard, OfflineMessage } from '@/components/ui/connection-guard';


import { RealTimeStatus } from '@/components/ui/real-time-status';

const Catalog = () => {
  const { products, loading, error, lastSyncTimestamp, isConnected, connectionStatus } = useProducts();
  const { categories } = useCategories();

  // Se não está conectado e não tem produtos, mostrar página offline
  if (connectionStatus === 'disconnected' && products.length === 0) {
    return <OfflineMessage />;
  }

  return (
    <ConnectionGuard fallback={<OfflineMessage />}>
      <CatalogContent 
        products={products}
        categories={categories}
        loading={loading}
        lastSyncTimestamp={lastSyncTimestamp}
        isConnected={isConnected}
      />
    </ConnectionGuard>
  );
};

function CatalogContent({ 
  products, 
  categories, 
  loading,
  lastSyncTimestamp,
  isConnected
}: { 
  products: Product[], 
  categories: any[], 
  loading: boolean,
  lastSyncTimestamp: Date | null,
  isConnected: boolean
}) {
  const { isSyncing } = useProducts();
  const [searchParams] = useSearchParams();
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [sortBy, setSortBy] = useState('name');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const searchQuery = searchParams.get('search') || '';
  const categoryFilter = searchParams.get('category') || '';

  useEffect(() => {
    let filtered = [...products];

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply category filter - excluir "Vendas por encomenda"
    if (categoryFilter) {
      filtered = filtered.filter(product => 
        product.category_id === categoryFilter
      );
    }
    
    // Filtrar categoria "Vendas por encomenda" sempre
    const excludeCategory = categories.find(cat => cat.name === 'Vendas por encomenda');
    if (excludeCategory) {
      filtered = filtered.filter(product => product.category_id !== excludeCategory.id);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'name':
        default:
          return a.name.localeCompare(b.name);
      }
    });

    setFilteredProducts(filtered);
  }, [products, searchQuery, categoryFilter, sortBy, categories]);

  // Get current category name for display
  const getCurrentCategoryName = () => {
    if (!categoryFilter) return '';
    const category = categories.find(cat => cat.id === categoryFilter);
    return category ? category.name : '';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(12)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-0">
                  <Skeleton className="w-full h-48 rounded-t-lg" />
                  <div className="p-4">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-2" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              {categoryFilter && (
                <div className="bg-primary/10 p-2 rounded-lg">
                  <CategoryIcon categoryName={getCurrentCategoryName()} className="h-6 w-6 text-primary" />
                </div>
              )}
              <h1 className="text-3xl font-bold text-foreground">
                {searchQuery 
                  ? `Resultados para "${searchQuery}"` 
                  : categoryFilter 
                    ? getCurrentCategoryName()
                    : 'Catálogo'}
              </h1>
            </div>
            <p className="text-muted-foreground">
              {filteredProducts.length} produtos encontrados
            </p>
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SortAsc className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Nome A-Z</SelectItem>
                <SelectItem value="price-low">Menor Preço</SelectItem>
                <SelectItem value="price-high">Maior Preço</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex border rounded-lg">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>


        {/* Products Grid */}
        {filteredProducts.length === 0 && !loading ? (
          <div className="text-center py-16">
            <div className="bg-orange-soft rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Filter className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              Nenhum produto encontrado
            </h3>
            <p className="text-muted-foreground">
              Tente ajustar os filtros ou buscar por outros termos.
            </p>
          </div>
        ) : (
          <div className={`grid gap-4 transition-all duration-300 ${
            viewMode === 'grid' 
              ? 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4' 
              : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
          }`}>
            {filteredProducts.map((product, index) => (
              <div 
                key={product.id} 
                className="animate-fade-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Catalog;