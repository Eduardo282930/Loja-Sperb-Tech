import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { loyverseApi } from '@/services/loyverse';
import { useProducts } from '@/contexts/ProductContext';

const StockCompareInternal = () => {
  const [searchParams] = useSearchParams();
  const { products, refreshProducts } = useProducts();
  const [output, setOutput] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const ids = useMemo(() => (searchParams.get('ids') || '').split(',').map(s => s.trim()).filter(Boolean), [searchParams]);
  const isDev = searchParams.get('dev') === '1';

  useEffect(() => {
    document.title = 'Stock Compare | Dev Internal';
  }, []);

  const run = async () => {
    setLoading(true);
    try {
      await refreshProducts();
      const inventory = await loyverseApi.getInventory();

      const result = ids.map((id) => {
        const appProd = products.find(p => p.id === id);
        const invRecords = inventory.filter(r => r.item_id === id || r.variant_id === id);

        // Se o produto tiver variantes, detalhar por variante
        let variantDetails: any[] = [];
        if (appProd && Array.isArray((appProd as any).variants) && (appProd as any).variants.length > 0) {
          variantDetails = (appProd as any).variants.map((v: any) => {
            const recs = inventory.filter(r => r.variant_id === v.id);
            const qty = recs.reduce((sum: number, r: any) => sum + (Number(r.in_stock) || 0), 0);
            return { variant_id: v.id, name: v.name, appVariantStock: qty, records: recs };
          });
        }

        return {
          item_id: id,
          productName: appProd?.name || null,
          appStock: appProd?.stock ?? null,
          variantDetails,
          loyverseInventoryRecords: invRecords,
        };
      });

      setOutput(result);
    } catch (e) {
      setOutput({ error: String((e as any)?.message || e) });
    } finally {
      setLoading(false);
    }
  };

  if (!isDev) {
    return (
      <div className="p-4">
        <h1 className="text-lg font-semibold">Acesso restrito</h1>
        <p>Adicione ?dev=1&ids=ID1,ID2,ID3 à URL para usar.</p>
      </div>
    );
  }

  return (
    <main className="p-4">
      <h1 className="text-xl font-bold mb-2">/internal/debug/stock-compare</h1>
      <p className="text-sm mb-4">IDs: {ids.join(', ') || '(nenhum)'} </p>
      <button
        disabled={loading}
        onClick={run}
        className="px-3 py-2 rounded bg-primary text-primary-foreground disabled:opacity-50"
      >
        {loading ? 'Gerando…' : 'Gerar JSON'}
      </button>

      {output && (
        <pre className="mt-4 text-xs bg-muted p-3 rounded overflow-auto max-h-[70vh]">
          {JSON.stringify(output, null, 2)}
        </pre>
      )}
    </main>
  );
};

export default StockCompareInternal;
