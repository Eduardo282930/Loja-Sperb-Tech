import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useProducts } from '@/contexts/ProductContext';
import { useCategories } from '@/contexts/CategoryContext';
import ProductCard from '@/components/product/OptimizedProductCard';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronRight, AlertTriangle, Zap } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import DynamicIcon from '@/components/ui/dynamic-icon';
import { ConnectionStatus } from '@/components/ui/connection-status';
import { ConnectionGuard, OfflineMessage } from '@/components/ui/connection-guard';
import { categoryMessagesService } from '@/services/categoryMessages';


const Home = () => {
  const { products, loading: productsLoading, isConnected, connectionStatus } = useProducts();
  const { categories, loading: categoriesLoading } = useCategories();
  const [currentBanner, setCurrentBanner] = useState(0);

  const banners = [
    {
      title: 'Ofertas Imperdíveis 2025!',
      subtitle: 'Os melhores produtos com os melhores preços',
      bg: 'bg-gradient-to-r from-primary to-primary-hover'
    },
    {
      title: 'Lançamentos 2025',
      subtitle: 'Produtos novos toda semana',
      bg: 'bg-gradient-to-r from-orange-medium to-primary'
    },
    {
      title: 'Qualidade Garantida',
      subtitle: 'Produtos selecionados especialmente para você',
      bg: 'bg-gradient-to-r from-success to-primary'
    }
  ];

  // Mostrar produtos apenas se conectado e filtrar "Vendas por encomenda"
  const featuredProducts = isConnected 
    ? products.filter(product => {
        const excludeCategory = categories.find(cat => cat.name === 'Vendas por encomenda');
        return !excludeCategory || product.category_id !== excludeCategory.id;
      }).slice(0, 6) 
    : [];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [banners.length]);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Banner - sem fundo, mais estreito */}
      <section className="text-primary py-4 px-4 text-center">
        <h1 className="text-xl md:text-2xl font-bold mb-1">
          Bem-vindo à Sperb Tech
        </h1>
        <p className="text-sm text-muted-foreground">
          Produtos de qualidade com os melhores preços
        </p>
      </section>

      <div className="container mx-auto px-4 py-8">
        {/* Connection Status - removido para não aparecer para clientes */}

        {/* Categories */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-foreground">Categorias</h2>
          </div>
          {categoriesLoading ? (
            <div className="flex gap-4 overflow-x-auto pb-4">
              {[...Array(4)].map((_, i) => (
                <Card key={i} className="flex-shrink-0 w-32">
                  <CardContent className="p-3 text-center">
                    <Skeleton className="w-10 h-10 rounded-full mx-auto mb-2" />
                    <Skeleton className="h-3 w-16 mx-auto" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex gap-4 overflow-x-auto pb-4">
              {categories
                .filter(category => category.name !== 'Vendas por encomenda')
                .map((category) => {
                  const categoryMessage = categoryMessagesService.getMessageForCategory(category.name);
                  return (
                    <Link
                      key={category.id}
                      to={`/catalog?category=${category.id}`}
                      className="group flex-shrink-0"
                    >
                      <Card className="hover:shadow-md transition-all duration-300 hover:border-primary w-32">
                        <CardContent className="p-3 text-center">
                          <div className="bg-orange-soft rounded-full w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                            <DynamicIcon iconName={category.icon || 'Package'} className="h-6 w-6 text-primary" />
                          </div>
                          <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors">
                            {category.name}
                          </p>
                          {categoryMessage && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {categoryMessage.emoji} {categoryMessage.message}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
            </div>
          )}
        </section>

        {/* Featured Products */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Produtos em Destaque</h2>
            {isConnected && (
              <Button variant="outline" asChild>
                <Link to="/catalog">
                  Ver Todos
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            )}
          </div>
          
          {productsLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[...Array(6)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-0">
                    <Skeleton className="w-full h-48 rounded-t-lg" />
                    <div className="p-4">
                      <Skeleton className="h-4 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2 mb-2" />
                      <Skeleton className="h-8 w-full" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !isConnected ? (
            <div className="text-center py-16">
              <div className="bg-orange-soft rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <AlertTriangle className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Sistema Desconectado
              </h3>
              <p className="text-muted-foreground">
                Produtos disponíveis mediante conexão válida com sistema de gestão
              </p>
            </div>
          ) : featuredProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="bg-orange-soft rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Carregando Produtos
              </h3>
              <p className="text-muted-foreground">
                Atualizando catálogo de produtos...
              </p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};

export default Home;