import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Product } from '@/types/product';
import { loyverseApi } from '@/services/loyverse';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import { 
  ShoppingCart, 
  Truck, 
  Shield, 
  RotateCcw,
  ChevronLeft,
  Plus,
  Minus
} from 'lucide-react';

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const { addItem } = useCart();

  useEffect(() => {
    const loadProduct = async () => {
      if (!id) return;
      
      try {
        const products = await loyverseApi.getProducts();
        const foundProduct = products.find(p => p.id === id);
        setProduct(foundProduct || null);
      } catch (error) {
        console.error('Error loading product:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (!product) return;
    
    // 🔴 VALIDAÇÃO RIGOROSA antes de adicionar ao carrinho
    const hasValidStock = product.stock !== undefined && 
                          product.stock !== null && 
                          typeof product.stock === 'number' && 
                          product.stock >= 0;
                          
    const isOutOfStock = hasValidStock && product.stock === 0;
    
    if (isOutOfStock || !hasValidStock) {
      toast({
        title: "Produto indisponível",
        description: "Este produto não pode ser adicionado ao carrinho.",
        variant: "destructive",
      });
      return;
    }
    
    for (let i = 0; i < quantity; i++) {
      addItem(product);
    }
    
    toast({
      title: "Produto adicionado!",
      description: `${quantity}x ${product.name} adicionado ao carrinho.`,
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="grid md:grid-cols-2 gap-8">
            <Skeleton className="w-full h-96 rounded-lg" />
            <div className="space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-6 w-1/2" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">
            Produto não encontrado ou indisponível
          </h1>
          <p className="text-muted-foreground mb-4">
            Este produto não atende aos critérios de preço e estoque válidos.
          </p>
          <Button asChild>
            <Link to="/catalog">Voltar ao Catálogo</Link>
          </Button>
        </div>
      </div>
    );
  }

  // 🔴 VALIDAÇÃO RIGOROSA DO PRODUTO
  const hasValidPrice = product.price && 
                        typeof product.price === 'number' && 
                        product.price > 0;
                        
  const hasValidStock = product.stock !== undefined && 
                        product.stock !== null && 
                        typeof product.stock === 'number' && 
                        product.stock >= 0;

  // 🔴 SE PRODUTO INVÁLIDO, NÃO MOSTRAR
  if (!hasValidPrice || !hasValidStock) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">
            Produto indisponível
          </h1>
          <p className="text-muted-foreground mb-4">
            Este produto não possui preço ou estoque válidos.
          </p>
          <Button asChild>
            <Link to="/catalog">Voltar ao Catálogo</Link>
          </Button>
        </div>
      </div>
    );
  }

  const isOutOfStock = product.stock === 0;
  const isLowStock = product.stock > 0 && product.stock < 5;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-muted-foreground mb-8">
          <Link to="/" className="hover:text-primary">Home</Link>
          <span>/</span>
          <Link to="/catalog" className="hover:text-primary">Catálogo</Link>
          <span>/</span>
          <span className="text-foreground">{product.name}</span>
        </nav>

        <Button variant="ghost" asChild className="mb-6">
          <Link to="/catalog">
            <ChevronLeft className="h-4 w-4 mr-2" />
            Voltar
          </Link>
        </Button>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div>
            <Card>
              <CardContent className="p-0">
                <img
                  src={product.image_url || '/api/placeholder/600/600'}
                  alt={product.name}
                  className="w-full h-96 md:h-[500px] object-cover rounded-lg"
                />
              </CardContent>
            </Card>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-4">
                {product.name}
              </h1>
              
              {/* Avaliações removidas por solicitação */}

              <div className="text-3xl font-bold text-primary mb-4">
                {formatPrice(product.price)}
              </div>

              {/* 🔴 ESTOQUE EM TEMPO REAL */}
              <div className="flex items-center space-x-2 mb-4">
                <Badge 
                  variant={isOutOfStock ? "destructive" : isLowStock ? "outline" : "secondary"}
                  className={
                    isOutOfStock 
                      ? "bg-red-500 text-white border-red-500" 
                      : isLowStock 
                        ? "bg-yellow-100 text-yellow-800 border-yellow-500"
                        : "bg-green-100 text-green-800 border-green-500"
                  }
                >
                  {isOutOfStock 
                    ? `❌ ESGOTADO` 
                    : isLowStock 
                      ? `⚠️ APENAS ${product.stock} RESTANTES` 
                      : `✅ ${product.stock} EM ESTOQUE`
                  }
                </Badge>
              </div>
            </div>

            {/* Description */}
            {product.description && (
              <div>
                <h3 className="font-semibold text-foreground mb-2">Descrição</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="flex items-center space-x-4">
              <span className="font-medium text-foreground">Quantidade:</span>
              <div className="flex items-center border rounded-lg">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="px-4 py-2 font-medium">{quantity}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setQuantity(quantity + 1)}
                  disabled={quantity >= product.stock}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Add to Cart */}
            <Button
              size="lg"
              onClick={handleAddToCart}
              className={`w-full ${
                isOutOfStock 
                  ? 'bg-muted text-muted-foreground cursor-not-allowed' 
                  : 'bg-primary hover:bg-primary-hover'
              }`}
              disabled={isOutOfStock}
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              {isOutOfStock ? '❌ PRODUTO ESGOTADO' : 'Adicionar ao Carrinho'}
            </Button>

            {/* Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t">
              <div className="flex items-center space-x-3">
                <div className="bg-orange-soft p-2 rounded-lg">
                  <Truck className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Frete Grátis</p>
                  <p className="text-xs text-muted-foreground">Acima de R$ 200</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="bg-orange-soft p-2 rounded-lg">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Garantia</p>
                  <p className="text-xs text-muted-foreground">12 meses</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="bg-orange-soft p-2 rounded-lg">
                  <RotateCcw className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Troca</p>
                  <p className="text-xs text-muted-foreground">7 dias</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;