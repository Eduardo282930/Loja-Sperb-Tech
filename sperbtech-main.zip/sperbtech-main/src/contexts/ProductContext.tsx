import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useMemo } from 'react';
import { Product } from '@/types/product';
import { sellerProductSettings, type SellerProductSetting } from '@/services/sellerProductSettings';
import { manualStockSync } from '@/services/manualStockSync';
import { useProductSync } from '@/hooks/useProductSync';

interface ProductContextType {
  products: Product[];
  loading: boolean;
  error: string | null;
  refreshProducts: () => Promise<void>;
  lastSyncTimestamp: Date | null;
  isConnected: boolean;
  toggleProductEnabled: (productId: string, enabled: boolean) => Promise<boolean>;
  sellerSettings: SellerProductSetting[];
  isSyncing: boolean;
  connectionStatus: 'connected' | 'disconnected' | 'checking';
  updateProductStock: (productId: string, newStock: number) => void;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

interface ProductProviderProps {
  children: ReactNode;
}

export const ProductProvider: React.FC<ProductProviderProps> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastSyncTimestamp, setLastSyncTimestamp] = useState<Date | null>(null);
  const [isConnected, setIsConnected] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'checking'>('checking');
  const [sellerSettings, setSellerSettings] = useState<SellerProductSetting[]>([]);
  const [initialized, setInitialized] = useState(false);
  
  const { syncProducts: syncProductsHook, cleanup } = useProductSync();

  // Função de sincronização otimizada
  const performSync = useCallback(async (isInitial = false) => {
    if (isSyncing) return;
    
    try {
      setIsSyncing(true);
      if (isInitial) {
        setConnectionStatus('checking');
      }
      
      const result = await syncProductsHook();
      
      if (result.products.length > 0) {
        setProducts(result.products);
        setLastSyncTimestamp(new Date());
      }
      
      setError(result.error);
      setIsConnected(result.isConnected);
      setConnectionStatus(result.isConnected ? 'connected' : 'disconnected');
      
      // Carregar configurações do vendedor
      const settings = await sellerProductSettings.getSettings();
      setSellerSettings(settings);
      
    } catch (error: any) {
      console.error('Erro na sincronização:', error);
      setError('Erro ao sincronizar produtos');
      setIsConnected(false);
      setConnectionStatus('disconnected');
    } finally {
      setIsSyncing(false);
      if (isInitial) {
        setLoading(false);
      }
    }
  }, [isSyncing, syncProductsHook]);

  // Função pública para refresh
  const refreshProducts = useCallback(async () => {
    await performSync(false);
  }, [performSync]);

  // Atualização instantânea de estoque (otimizada com useCallback)
  const updateProductStock = useCallback((productId: string, newStock: number) => {
    setProducts(prevProducts => 
      prevProducts.map(product => 
        product.id === productId 
          ? { ...product, stock: newStock }
          : product
      )
    );
  }, []);

  // Toggle de produto habilitado
  const toggleProductEnabled = useCallback(async (productId: string, enabled: boolean): Promise<boolean> => {
    try {
      const success = await sellerProductSettings.toggleProductEnabled(productId, enabled);
      if (success) {
        await performSync(false);
      }
      return success;
    } catch (error) {
      return false;
    }
  }, [performSync]);

  // Inicialização única
  useEffect(() => {
    if (initialized) return;
    
    setInitialized(true);
    setLoading(true);
    
    // Sincronização inicial em background
    performSync(true).catch(err => {
      console.error('❌ Erro na inicialização:', err);
      setLoading(false);
    });

    // Subscrever mudanças de estoque manual
    const unsubscribe = manualStockSync.subscribe((productId, newStock) => {
      updateProductStock(productId, newStock);
    });

    return () => {
      unsubscribe();
      cleanup();
    };
  }, [initialized, performSync, updateProductStock, cleanup]);

  // Sincronização periódica (apenas quando conectado)
  useEffect(() => {
    if (!initialized || !isConnected || loading) return;
    
    const interval = setInterval(() => {
      if (!isSyncing) {
        performSync(false);
      }
    }, 30000); // 30 segundos
    
    return () => clearInterval(interval);
  }, [initialized, isConnected, loading, isSyncing, performSync]);

  // Memoizar o valor do contexto para evitar re-renders desnecessários
  const contextValue = useMemo(() => ({
    products,
    loading,
    error,
    refreshProducts,
    lastSyncTimestamp,
    isConnected,
    toggleProductEnabled,
    sellerSettings,
    isSyncing,
    connectionStatus,
    updateProductStock
  }), [
    products,
    loading,
    error,
    refreshProducts,
    lastSyncTimestamp,
    isConnected,
    toggleProductEnabled,
    sellerSettings,
    isSyncing,
    connectionStatus,
    updateProductStock
  ]);
  
  return (
    <ProductContext.Provider value={contextValue}>
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = () => {
  const context = useContext(ProductContext);
  
  if (context === undefined) {
    console.error('❌ useProducts deve ser usado dentro de ProductProvider');
    // Retornar valores padrão seguros
    return {
      products: [],
      loading: true,
      error: null,
      refreshProducts: async () => {},
      lastSyncTimestamp: null,
      isConnected: false,
      toggleProductEnabled: async () => false,
      sellerSettings: [],
      isSyncing: false,
      connectionStatus: 'checking' as const,
      updateProductStock: () => {}
    };
  }
  
  return context;
};
