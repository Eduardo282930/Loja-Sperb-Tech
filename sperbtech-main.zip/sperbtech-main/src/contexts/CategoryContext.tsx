import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Category } from '@/types/product';
import { loyverseApi } from '@/services/loyverse';

interface CategoryContextType {
  categories: Category[];
  loading: boolean;
  error: string | null;
  refreshCategories: () => Promise<void>;
}

const CategoryContext = createContext<CategoryContextType | undefined>(undefined);

interface CategoryProviderProps {
  children: ReactNode;
}

export const CategoryProvider: React.FC<CategoryProviderProps> = ({ children }) => {
  console.log('CategoryProvider initializing...');
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshCategories = async () => {
    try {
      console.log('CategoryProvider: refreshing categories...');
      setError(null);
      const data = await loyverseApi.getCategories();
      console.log('CategoryProvider: categories loaded:', data.length);
      setCategories(data);
    } catch (error: any) {
      console.error('Error loading categories:', error);
      setError(error.message || 'Erro ao carregar categorias');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshCategories();
  }, []);

  console.log('CategoryProvider rendering with:', { categories: categories.length, loading, error });

  return (
    <CategoryContext.Provider 
      value={{ 
        categories, 
        loading, 
        error, 
        refreshCategories 
      }}
    >
      {children}
    </CategoryContext.Provider>
  );
};

export const useCategories = () => {
  const context = useContext(CategoryContext);
  if (context === undefined) {
    console.error('CategoryContext is undefined. Provider may not be properly wrapped.');
    // Return safe fallback instead of throwing during initial render
    return {
      categories: [],
      loading: true,
      error: null,
      refreshCategories: async () => {}
    };
  }
  return context;
};