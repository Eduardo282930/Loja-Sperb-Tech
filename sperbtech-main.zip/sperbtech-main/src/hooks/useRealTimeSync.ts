import { useEffect, useState } from 'react';
import { realTimeSyncService } from '@/services/realTimeSync';
import { supabase } from '@/integrations/supabase/client';
import { sellerProductSettings } from '@/services/sellerProductSettings';
import { loyverseReceiptMonitor } from '@/services/loyverseReceiptMonitor';

export const useRealTimeSync = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);

  useEffect(() => {
    // Sincronização desabilitada - apenas estoque manual
    console.log('📦 Hook de sincronização desabilitado - usando apenas estoque manual');
    setIsConnected(true);
    setSyncError(null);
    setLastSync(new Date());

    return () => {
      // Cleanup básico
    };
  }, []);

  const forceSync = async () => {
    // Sincronização desabilitada - apenas estoque manual
    console.log('📦 Sync forçado desabilitado - usando apenas estoque manual');
    setLastSync(new Date());
  };

  return {
    isConnected,
    lastSync,
    forceSync,
    syncError
  };
};