import { useCallback, useRef } from 'react';
import { loyverseApi } from '@/services/loyverse';
import { sellerProductSettings } from '@/services/sellerProductSettings';
import { manualStockChanges } from '@/services/manualStockChanges';
import { Product } from '@/types/product';

export interface SyncResult {
  products: Product[];
  error: string | null;
  isConnected: boolean;
}

export const useProductSync = () => {
  const syncInProgressRef = useRef(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const syncProducts = useCallback(async (): Promise<SyncResult> => {
    // Prevenir múltiplas sincronizações simultâneas
    if (syncInProgressRef.current) {
      console.log('🔄 Sync já em progresso, aguardando...');
      return { products: [], error: null, isConnected: true };
    }

    // Cancelar requisição anterior se existir
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    syncInProgressRef.current = true;
    abortControllerRef.current = new AbortController();

    try {
      // Buscar produtos do Loyverse
      const loyverseProducts = await loyverseApi.getProducts();
      
      // Carregar configurações do vendedor
      const settings = await sellerProductSettings.getSettings();
      
      // Filtrar produtos válidos
      const settingsMap = new Map(settings.map(s => [s.loyverse_product_id, s]));
      const validProducts = loyverseProducts.filter(product => {
        const setting = settingsMap.get(product.id);
        const isEnabled = setting ? setting.is_enabled : true;
        const hasValidPrice = product.price && product.price > 0;
        const hasValidName = product.name && product.name.trim().length > 0;
        const hasValidStock = typeof product.stock === 'number' && product.stock >= 0;
        
        return isEnabled && hasValidPrice && hasValidName && hasValidStock;
      });
      
      // Aplicar estoque manual se existir
      const cleanProducts = validProducts.map(product => {
        const manualStock = manualStockChanges.getManualStock(product.id);
        const finalStock = manualStock !== null ? manualStock : product.stock;
        
        return {
          ...product,
          price: Number(product.price),
          stock: Number(finalStock)
        };
      });
      
      // Marcar sincronização como sucesso
      await sellerProductSettings.markSyncSuccess(cleanProducts.length);
      
      return {
        products: cleanProducts,
        error: null,
        isConnected: true
      };
      
    } catch (error: any) {
      const errorMsg = error.message || 'Sistema desconectado';
      await sellerProductSettings.markSyncError(errorMsg);
      
      return {
        products: [],
        error: errorMsg,
        isConnected: false
      };
    } finally {
      syncInProgressRef.current = false;
      abortControllerRef.current = null;
    }
  }, []);

  const cleanup = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    syncInProgressRef.current = false;
  }, []);

  return { syncProducts, cleanup };
};
