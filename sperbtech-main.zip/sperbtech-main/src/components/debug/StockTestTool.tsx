import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { loyverseApi } from '@/services/loyverse';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useProducts } from '@/contexts/ProductContext';
import { RefreshCw, Bug, AlertTriangle, CheckCircle, Package, Database } from 'lucide-react';

interface TestResult {
  success: boolean;
  message: string;
  data?: any;
  timestamp: Date;
}

interface StockComparison {
  productId: string;
  productName: string;
  appStock: number;
  loyverseStock: number;
  match: boolean;
}

export function StockTestTool() {
  const { products, refreshProducts } = useProducts();
  const [testing, setTesting] = useState(false);
  const [lastTest, setLastTest] = useState<TestResult | null>(null);
  const [stockComparisons, setStockComparisons] = useState<StockComparison[]>([]);
  const [rawLoyverseData, setRawLoyverseData] = useState<any[]>([]);

  const handleTestStock = async () => {
    setTesting(true);
    
    try {
      console.log('🧪 INICIANDO TESTE DE ESTOQUE COMPLETO...');
      
      // 1. Testar conexão
      const connectionTest = await loyverseApi.testConnection();
      if (!connectionTest.valid) {
        setLastTest({
          success: false,
          message: `Conexão falhou: ${connectionTest.message}`,
          timestamp: new Date()
        });
        return;
      }

      // 2. Buscar dados brutos do Loyverse
      console.log('📡 Buscando dados diretos do Loyverse...');
      const loyverseProducts = await loyverseApi.getProducts();
      setRawLoyverseData(loyverseProducts.slice(0, 10)); // Guardar amostra para debug

      // 3. Buscar inventory direto
      console.log('📦 Buscando inventory direto...');
      const inventory = await loyverseApi.getInventory();

      // 4. Forçar refresh do app
      console.log('🔄 Forçando refresh do app...');
      await refreshProducts();

      // 5. Comparar estoques
      const comparisons: StockComparison[] = [];
      
      loyverseProducts.forEach(loyProd => {
        const appProd = products.find(p => p.id === loyProd.id);
        
        if (appProd) {
          const match = appProd.stock === loyProd.stock;
          comparisons.push({
            productId: loyProd.id,
            productName: loyProd.name,
            appStock: appProd.stock || 0,
            loyverseStock: loyProd.stock || 0,
            match
          });
        }
      });

      setStockComparisons(comparisons);

      const totalTests = comparisons.length;
      const correctTests = comparisons.filter(c => c.match).length;
      const accuracy = totalTests > 0 ? (correctTests / totalTests) * 100 : 0;

      setLastTest({
        success: true,
        message: `Teste concluído: ${correctTests}/${totalTests} produtos corretos (${accuracy.toFixed(1)}% precisão)`,
        data: {
          totalProducts: loyverseProducts.length,
          totalComparisons: totalTests,
          accuracy: accuracy.toFixed(1),
          inventoryRecords: inventory.length
        },
        timestamp: new Date()
      });

      console.log('✅ TESTE COMPLETO CONCLUÍDO');

    } catch (error) {
      console.error('❌ Erro no teste:', error);
      setLastTest({
        success: false,
        message: `Erro: ${error instanceof Error ? error.message : 'Erro desconhecido'}`,
        timestamp: new Date()
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-orange-500 bg-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-800">
            <Bug className="h-5 w-5" />
            Ferramenta de Teste de Estoque - DESENVOLVEDOR
          </CardTitle>
          <CardDescription className="text-orange-700">
            Ferramenta para validar se os valores de estoque estão chegando corretos da API Loyverse.
            Use isso para debugar problemas de sincronização.
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Controls */}
      <div className="flex gap-3">
        <Button 
          onClick={handleTestStock} 
          disabled={testing}
          className="flex items-center gap-2"
        >
          {testing ? (
            <RefreshCw className="h-4 w-4 animate-spin" />
          ) : (
            <Package className="h-4 w-4" />
          )}
          {testing ? 'Testando...' : 'Testar Estoque Completo'}
        </Button>
      </div>

      {/* Last Test Result */}
      {lastTest && (
        <Alert className={lastTest.success ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}>
          <div className="flex items-center gap-2">
            {lastTest.success ? (
              <CheckCircle className="h-4 w-4 text-green-500" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-red-500" />
            )}
            <AlertDescription className={lastTest.success ? "text-green-800" : "text-red-800"}>
              <div className="font-medium mb-1">
                {lastTest.success ? 'Teste Concluído' : 'Teste Falhou'}
              </div>
              <div className="text-sm">{lastTest.message}</div>
              <div className="text-xs mt-1">
                {lastTest.timestamp.toLocaleString()}
              </div>
              {lastTest.data && (
                <div className="mt-2 text-xs bg-white/50 p-2 rounded">
                  <pre>{JSON.stringify(lastTest.data, null, 2)}</pre>
                </div>
              )}
            </AlertDescription>
          </div>
        </Alert>
      )}

      {/* Stock Comparisons */}
      {stockComparisons.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Comparação de Estoques (App vs Loyverse)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {stockComparisons.map((comp, index) => (
                <div 
                  key={comp.productId} 
                  className={`flex items-center justify-between p-3 rounded border ${
                    comp.match ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex-1">
                    <div className="font-medium text-sm">{comp.productName}</div>
                    <div className="text-xs text-muted-foreground">ID: {comp.productId}</div>
                  </div>
                  <div className="text-right space-y-1">
                    <div className="text-sm">
                      App: <Badge variant="outline">{comp.appStock}</Badge>
                    </div>
                    <div className="text-sm">
                      Loyverse: <Badge variant="outline">{comp.loyverseStock}</Badge>
                    </div>
                  </div>
                  <div className="ml-3">
                    {comp.match ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <AlertTriangle className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Raw Loyverse Data Sample */}
      {rawLoyverseData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Dados Brutos do Loyverse (Amostra)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {rawLoyverseData.map((item, index) => (
                <div key={index} className="p-2 bg-muted rounded text-xs">
                  <div className="font-medium">{item.name}</div>
                  <div>Preço: R$ {item.price}</div>
                  <div>Estoque: {item.stock}</div>
                  <div>ID: {item.id}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Como Usar Esta Ferramenta</CardTitle>
        </CardHeader>
        <CardContent className="text-xs space-y-2">
          <p><strong>1.</strong> Clique em "Testar Estoque Completo" para buscar dados diretos do Loyverse</p>
          <p><strong>2.</strong> A ferramenta irá comparar os estoques do app com os do Loyverse</p>
          <p><strong>3.</strong> Produtos com estoque divergente aparecerão em vermelho</p>
          <p><strong>4.</strong> Use os logs do console para debug mais detalhado</p>
          <p className="text-muted-foreground">
            Esta ferramenta é apenas para desenvolvimento. Não deve aparecer no app final.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}