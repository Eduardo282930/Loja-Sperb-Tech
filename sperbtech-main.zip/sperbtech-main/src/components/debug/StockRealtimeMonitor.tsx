import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, Activity, Pause, Play } from 'lucide-react';
import { loyverseApi } from '@/services/loyverse';

interface StockItem {
  item_id: string;
  variant_id?: string;
  store_id: string;
  quantity: number;
  product_name?: string;
}

const StockRealtimeMonitor: React.FC = () => {
  const [stockData, setStockData] = useState<StockItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [isAutoUpdating, setIsAutoUpdating] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [intervalId, setIntervalId] = useState<NodeJS.Timeout | null>(null);

  const fetchStock = async () => {
    try {
      setLoading(true);
      setError(null);
      console.log('🔄 StockRealtimeMonitor: Buscando estoque...');
      
      const inventory = await loyverseApi.getInventory();
      console.log(`📦 StockRealtimeMonitor: ${inventory.length} registros recebidos`);
      
      setStockData(inventory);
      setLastUpdate(new Date());
    } catch (err: any) {
      console.error('❌ StockRealtimeMonitor erro:', err);
      setError(err.message || 'Erro ao buscar estoque');
    } finally {
      setLoading(false);
    }
  };

  const startAutoUpdate = () => {
    if (intervalId) return; // Já está rodando
    
    console.log('🚀 Iniciando atualização automática de estoque a cada 10s');
    setIsAutoUpdating(true);
    
    // Buscar imediatamente
    fetchStock();
    
    // Configurar intervalo
    const id = setInterval(() => {
      console.log('⏰ Auto-update de estoque disparado');
      fetchStock();
    }, 10000); // 10 segundos
    
    setIntervalId(id);
  };

  const stopAutoUpdate = () => {
    if (intervalId) {
      console.log('⏹️ Parando atualização automática de estoque');
      clearInterval(intervalId);
      setIntervalId(null);
    }
    setIsAutoUpdating(false);
  };

  useEffect(() => {
    // Cleanup na desmontagem
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [intervalId]);

  const getQuantityBadge = (qty: number) => {
    if (qty === 0) return <Badge variant="destructive">0</Badge>;
    if (qty < 5) return <Badge variant="secondary">Baixo ({qty})</Badge>;
    return <Badge variant="default">{qty}</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Monitor de Estoque Tempo Real
          {isAutoUpdating && <Badge variant="default" className="animate-pulse">ATIVO</Badge>}
        </CardTitle>
        <CardDescription>
          Monitora o estoque Loyverse automaticamente a cada 10 segundos
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Controles */}
        <div className="flex items-center gap-2 flex-wrap">
          <Button 
            onClick={fetchStock} 
            disabled={loading} 
            variant="outline"
            className="flex items-center gap-2"
          >
            {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            Atualizar Agora
          </Button>
          
          {isAutoUpdating ? (
            <Button 
              onClick={stopAutoUpdate} 
              variant="secondary"
              className="flex items-center gap-2"
            >
              <Pause className="h-4 w-4" />
              Parar Auto-Update
            </Button>
          ) : (
            <Button 
              onClick={startAutoUpdate} 
              variant="default"
              className="flex items-center gap-2"
            >
              <Play className="h-4 w-4" />
              Iniciar Auto-Update (10s)
            </Button>
          )}
          
          {lastUpdate && (
            <Badge variant="outline">
              Última atualização: {lastUpdate.toLocaleTimeString()}
            </Badge>
          )}
        </div>

        {/* Status */}
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded text-red-800 text-sm">
            ❌ {error}
          </div>
        )}

        {/* Dados */}
        {stockData.length > 0 && (
          <div className="space-y-3">
            <div className="text-sm font-semibold">
              📊 Total de registros: {stockData.length}
            </div>
            
            {/* Lista dos primeiros 10 itens com estoque */}
            <div className="max-h-64 overflow-y-auto space-y-2">
              {stockData
                .filter(item => item.quantity > 0)
                .slice(0, 10)
                .map((item, i) => (
                <div key={`${item.item_id}-${item.variant_id}-${item.store_id}`} 
                     className="flex items-center justify-between p-2 bg-muted rounded text-xs">
                  <div className="flex-1">
                    <div className="font-mono">ID: {item.item_id}</div>
                    {item.variant_id && (
                      <div className="text-muted-foreground">Variante: {item.variant_id}</div>
                    )}
                    <div className="text-muted-foreground">Loja: {item.store_id}</div>
                  </div>
                  <div>
                    {getQuantityBadge(item.quantity)}
                  </div>
                </div>
              ))}
            </div>

            {/* Resumo rápido */}
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="p-2 bg-green-50 rounded text-center">
                <div className="font-semibold text-green-800">
                  {stockData.filter(item => item.quantity > 0).length}
                </div>
                <div className="text-green-600">Com Estoque</div>
              </div>
              <div className="p-2 bg-red-50 rounded text-center">
                <div className="font-semibold text-red-800">
                  {stockData.filter(item => item.quantity === 0).length}
                </div>
                <div className="text-red-600">Zerados</div>
              </div>
              <div className="p-2 bg-yellow-50 rounded text-center">
                <div className="font-semibold text-yellow-800">
                  {stockData.filter(item => item.quantity > 0 && item.quantity < 5).length}
                </div>
                <div className="text-yellow-600">Baixo Estoque</div>
              </div>
            </div>
          </div>
        )}
        
        {stockData.length === 0 && !loading && !error && (
          <div className="text-center text-muted-foreground py-8">
            Clique em "Atualizar Agora" ou "Iniciar Auto-Update" para começar
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StockRealtimeMonitor;