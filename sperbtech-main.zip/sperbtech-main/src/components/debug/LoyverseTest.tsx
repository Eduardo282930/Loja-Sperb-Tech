import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { loyverseApi } from '@/services/loyverse';
import { realTimeSyncService } from '@/services/realTimeSync';
import { RefreshCw, CheckCircle, XCircle, Package } from 'lucide-react';

interface TestResult {
  success: boolean;
  message: string;
  data?: any;
  error?: any;
}

const LoyverseTest = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [connectionResult, setConnectionResult] = useState<TestResult | null>(null);
  const [productsResult, setProductsResult] = useState<TestResult | null>(null);
  const [syncResult, setSyncResult] = useState<TestResult | null>(null);

  const testConnection = async () => {
    setIsLoading(true);
    setConnectionResult(null);
    
    try {
      const result = await loyverseApi.testConnection();
      setConnectionResult({
        success: result.valid,
        message: result.message,
        data: result
      });
    } catch (error: any) {
      setConnectionResult({
        success: false,
        message: error.message || 'Erro desconhecido',
        error
      });
    } finally {
      setIsLoading(false);
    }
  };

  const testProducts = async () => {
    setIsLoading(true);
    setProductsResult(null);
    
    try {
      const products = await loyverseApi.getProducts();
      setProductsResult({
        success: true,
        message: `${products.length} produtos encontrados`,
        data: products.slice(0, 3) // Mostrar apenas os primeiros 3 para não sobrecarregar
      });
    } catch (error: any) {
      setProductsResult({
        success: false,
        message: error.message || 'Erro ao buscar produtos',
        error
      });
    } finally {
      setIsLoading(false);
    }
  };

  const testSync = async () => {
    setIsLoading(true);
    setSyncResult(null);
    
    try {
      // Apenas testar conexão e inicializar monitoramento
      await realTimeSyncService.initializeSync();
      setSyncResult({
        success: true,
        message: 'Monitoramento de vendas iniciado com sucesso'
      });
    } catch (error: any) {
      setSyncResult({
        success: false,
        message: error.message || 'Erro na sincronização',
        error
      });
    } finally {
      setIsLoading(false);
    }
  };

  const ResultCard = ({ title, result, icon }: { title: string, result: TestResult | null, icon: React.ReactNode }) => (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          {icon}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {result ? (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              {result.success ? (
                <CheckCircle className="w-4 h-4 text-green-500" />
              ) : (
                <XCircle className="w-4 h-4 text-red-500" />
              )}
              <Badge variant={result.success ? "default" : "destructive"}>
                {result.success ? "Sucesso" : "Erro"}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">{result.message}</p>
            {result.data && (
              <div className="text-xs bg-muted p-2 rounded">
                <strong>Dados:</strong>
                <pre className="mt-1 overflow-x-auto">
                  {JSON.stringify(result.data, null, 2).slice(0, 300)}
                  {JSON.stringify(result.data).length > 300 ? "..." : ""}
                </pre>
              </div>
            )}
            {result.error && (
              <div className="text-xs bg-red-50 p-2 rounded border border-red-200">
                <strong>Erro:</strong>
                <pre className="mt-1 text-red-700">
                  {JSON.stringify(result.error, null, 2).slice(0, 200)}
                </pre>
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Clique no botão para testar</p>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Debug Loyverse Integration</h2>
        <Badge variant="outline">Ambiente de Teste</Badge>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Button 
            onClick={testConnection} 
            disabled={isLoading}
            className="w-full"
            variant="outline"
          >
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : null}
            Testar Conexão
          </Button>
          <ResultCard 
            title="Conexão" 
            result={connectionResult} 
            icon={<CheckCircle className="w-4 h-4" />}
          />
        </div>

        <div className="space-y-2">
          <Button 
            onClick={testProducts} 
            disabled={isLoading}
            className="w-full"
            variant="outline"
          >
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : null}
            Buscar Produtos
          </Button>
          <ResultCard 
            title="Produtos" 
            result={productsResult} 
            icon={<Package className="w-4 h-4" />}
          />
        </div>

        <div className="space-y-2">
          <Button 
            onClick={testSync} 
            disabled={isLoading}
            className="w-full"
            variant="outline"
          >
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : null}
            Sincronizar
          </Button>
          <ResultCard 
            title="Sincronização" 
            result={syncResult} 
            icon={<RefreshCw className="w-4 h-4" />}
          />
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Instruções de Debug</CardTitle>
        </CardHeader>
        <CardContent className="text-xs space-y-2">
          <p><strong>1. Testar Conexão:</strong> Verifica se o token está configurado e válido</p>
          <p><strong>2. Buscar Produtos:</strong> Tenta buscar produtos do Loyverse com paginação</p>
          <p><strong>3. Sincronizar:</strong> Executa a sincronização completa dos produtos</p>
          <p className="text-muted-foreground">
            Os logs detalhados estão disponíveis no console do navegador e nos logs do Supabase Edge Function.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoyverseTest;