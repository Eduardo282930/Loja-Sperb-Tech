import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertTriangle, RefreshCw } from 'lucide-react';

export function QuickInventoryTest() {
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<any>(null);

  const testInventoryAPI = async () => {
    setTesting(true);
    console.log('🧪 TESTE RÁPIDO: Investigando API /inventory...');

    try {
      // Fazer chamada para /inventory
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'inventory',
          method: 'GET',
          useStoredToken: true,
          params: { limit: 5 }
        }
      });

      if (error) {
        console.error('❌ Erro:', error);
        setResults({ error, success: false });
        return;
      }

      console.log('📦 RESPOSTA /inventory:', data);
      console.log('Tipo:', typeof data);
      console.log('Keys:', Object.keys(data || {}));

      // Detectar estrutura
      let inventoryArray: any[] = [];
      let source = 'unknown';

      if (Array.isArray(data?.inventory)) {
        inventoryArray = data.inventory;
        source = 'data.inventory';
      } else if (Array.isArray(data?.inventory_levels)) {
        inventoryArray = data.inventory_levels;
        source = 'data.inventory_levels';
      } else if (Array.isArray(data)) {
        inventoryArray = data;
        source = 'data (array)';
      }

      console.log(`📦 Fonte: ${source}, Total: ${inventoryArray.length}`);

      let quantityFields: any = {};
      let sampleRecord = null;

      if (inventoryArray.length > 0) {
        sampleRecord = inventoryArray[0];
        console.log('📦 PRIMEIRO REGISTRO:', sampleRecord);
        
        // Analisar campos de quantidade
        ['quantity', 'quantity_on_hand', 'available_quantity', 'stock', 'in_stock'].forEach(field => {
          if (sampleRecord[field] !== undefined) {
            quantityFields[field] = {
              value: sampleRecord[field],
              type: typeof sampleRecord[field]
            };
            console.log(`✅ Campo ${field}: ${sampleRecord[field]} (${typeof sampleRecord[field]})`);
          }
        });

        // Mostrar alguns registros
        console.log('📦 AMOSTRA DE REGISTROS:');
        inventoryArray.slice(0, 3).forEach((rec, i) => {
          console.log(`Registro ${i + 1}:`, {
            item_id: rec.item_id,
            variant_id: rec.variant_id,
            store_id: rec.store_id,
            quantity: rec.quantity,
            quantity_on_hand: rec.quantity_on_hand,
            available_quantity: rec.available_quantity,
            stock: rec.stock
          });
        });
      }

      setResults({
        success: true,
        source,
        total: inventoryArray.length,
        quantityFields,
        sampleRecord,
        sample: inventoryArray.slice(0, 3)
      });

    } catch (error) {
      console.error('❌ Erro:', error);
      setResults({ error, success: false });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          🧪 Teste Rápido da API /inventory
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button 
          onClick={testInventoryAPI} 
          disabled={testing}
          className="flex items-center gap-2"
        >
          {testing ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
          {testing ? 'Testando...' : 'Testar API /inventory'}
        </Button>

        {results && (
          results.success ? (
            <Alert className="border-green-500 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <AlertDescription>
                <div className="space-y-2">
                  <div><strong>Fonte:</strong> <Badge>{results.source}</Badge></div>
                  <div><strong>Total:</strong> {results.total} registros</div>
                  <div>
                    <strong>Campos de quantidade:</strong>
                    <div className="flex gap-1 mt-1">
                      {Object.entries(results.quantityFields).map(([field, info]: [string, any]) => (
                        <Badge key={field} variant="secondary">
                          {field}: {info.value}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  {results.sampleRecord && (
                    <details className="mt-2">
                      <summary className="cursor-pointer font-medium">Ver registro completo</summary>
                      <pre className="text-xs mt-1 p-2 bg-white border rounded overflow-x-auto">
                        {JSON.stringify(results.sampleRecord, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          ) : (
            <Alert className="border-red-500 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-500" />
              <AlertDescription>
                <strong>Erro:</strong> {JSON.stringify(results.error, null, 2)}
              </AlertDescription>
            </Alert>
          )
        )}
      </CardContent>
    </Card>
  );
}