import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useProducts } from '@/contexts/ProductContext';

export function CatalogStockDebug() {
  const { products, loading, error, isConnected, lastSyncTimestamp } = useProducts();

  if (loading) return null;

  return (
    <Card className="mb-6 border-blue-200 bg-blue-50">
      <CardHeader>
        <CardTitle className="text-blue-800 text-lg">
          🛠️ Debug de Estoque - Produtos Carregados
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{products.length}</div>
            <div className="text-sm text-blue-700">Produtos</div>
          </div>
          <div className="text-center">
            <Badge variant={isConnected ? "default" : "destructive"}>
              {isConnected ? "✅ Conectado" : "❌ Desconectado"}
            </Badge>
          </div>
          <div className="text-center">
            <div className="text-sm text-blue-700">Última Sync:</div>
            <div className="text-xs">
              {lastSyncTimestamp ? lastSyncTimestamp.toLocaleTimeString() : 'N/A'}
            </div>
          </div>
          <div className="text-center">
            <Badge variant={error ? "destructive" : "default"}>
              {error ? "❌ Erro" : "✅ OK"}
            </Badge>
          </div>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-300 text-red-700 px-4 py-2 rounded mb-4">
            Erro: {error}
          </div>
        )}

        {products.length > 0 && (
          <div className="bg-white rounded border p-4">
            <h4 className="font-medium mb-2">Primeiros 5 produtos (amostra):</h4>
            <div className="space-y-2">
              {products.slice(0, 5).map((product, index) => (
                <div key={product.id} className="flex justify-between items-center text-sm border-b pb-1">
                  <span className="font-medium">{index + 1}. {product.name}</span>
                  <div className="flex gap-2">
                    <Badge variant="outline">R$ {product.price?.toFixed(2)}</Badge>
                    <Badge variant={product.stock === 0 ? "destructive" : product.stock && product.stock < 5 ? "outline" : "default"}>
                      {product.stock} unidades
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {products.length === 0 && !loading && (
          <div className="bg-yellow-100 border border-yellow-300 text-yellow-700 px-4 py-2 rounded">
            Nenhum produto carregado. Verifique a conexão com Loyverse.
          </div>
        )}
      </CardContent>
    </Card>
  );
}