import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useProducts } from '@/contexts/ProductContext';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, RefreshCw, Package, Eye } from 'lucide-react';

export function CatalogStockRefresh() {
  const { products, refreshProducts } = useProducts();
  const [refreshing, setRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const handleRefresh = async () => {
    setRefreshing(true);
    console.log('🔄 FORÇANDO REFRESH DO CATÁLOGO...');
    
    try {
      await refreshProducts();
      setLastRefresh(new Date());
      console.log('✅ Catálogo atualizado com sucesso');
    } catch (error) {
      console.error('❌ Erro ao atualizar catálogo:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const stockSummary = {
    total: products.length,
    withStock: products.filter(p => p.stock > 0).length,
    noStock: products.filter(p => p.stock === 0).length,
    unlimited: products.filter(p => p.stock === 999).length
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Atualização do Catálogo em Tempo Real
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <Button 
            onClick={handleRefresh} 
            disabled={refreshing}
            className="flex items-center gap-2"
          >
            {refreshing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            {refreshing ? 'Atualizando...' : 'Forçar Atualização'}
          </Button>
          
          <Button 
            variant="outline"
            onClick={() => window.open('/catalog', '_blank')}
            className="flex items-center gap-2"
          >
            <Eye className="h-4 w-4" />
            Ver Catálogo
          </Button>
        </div>

        <Alert className="border-blue-500 bg-blue-50">
          <CheckCircle className="h-4 w-4 text-blue-500" />
          <AlertDescription>
            <div className="space-y-2">
              <div><strong>Status do Catálogo:</strong></div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <Badge variant="outline">Total: {stockSummary.total}</Badge>
                </div>
                <div>
                  <Badge variant="default">Com estoque: {stockSummary.withStock}</Badge>
                </div>
                <div>
                  <Badge variant="secondary">Sem estoque: {stockSummary.noStock}</Badge>
                </div>
                <div>
                  <Badge variant="outline">Ilimitado: {stockSummary.unlimited}</Badge>
                </div>
              </div>
              {lastRefresh && (
                <div className="text-xs text-muted-foreground mt-2">
                  Última atualização: {lastRefresh.toLocaleTimeString()}
                </div>
              )}
            </div>
          </AlertDescription>
        </Alert>

        <div className="space-y-2">
          <h4 className="font-semibold text-sm">Produtos com Estoque (Amostra)</h4>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {products
              .filter(p => p.stock > 0 && p.stock !== 999)
              .slice(0, 5)
              .map(product => (
                <div key={product.id} className="flex items-center justify-between text-xs p-2 bg-green-50 rounded">
                  <span className="truncate">{product.name}</span>
                  <Badge variant="default" className="ml-2">{product.stock}</Badge>
                </div>
              ))
            }
            {stockSummary.withStock === 0 && (
              <div className="text-center py-4 text-sm text-muted-foreground">
                ❌ Nenhum produto com estoque disponível
              </div>
            )}
          </div>
        </div>

        <div className="text-xs text-gray-500 space-y-1">
          <p><strong>Como usar:</strong></p>
          <p>1. Clique em "Forçar Atualização" para buscar dados frescos do Loyverse</p>
          <p>2. Use "Ver Catálogo" para abrir o catálogo em nova aba</p>
          <p>3. Verifique se os estoques aparecem corretamente no catálogo</p>
          <p>4. Compare os números aqui com o que aparece no catálogo</p>
        </div>
      </CardContent>
    </Card>
  );
}