import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RefreshCw, Package, AlertCircle, CheckCircle } from 'lucide-react';
import { loyverseApi } from '@/services/loyverse';
import { useProducts } from '@/contexts/ProductContext';
import { Badge } from '@/components/ui/badge';
import { StockIndicator } from '@/components/ui/stock-indicator';

export function StockDebug() {
  const { products, refreshProducts, isConnected, isSyncing } = useProducts();
  const [testing, setTesting] = useState(false);
  const [inventoryData, setInventoryData] = useState<any[]>([]);
  const [lastTest, setLastTest] = useState<string | null>(null);

  const handleTestInventory = async () => {
    setTesting(true);
    try {
      console.log('🧪 TESTE DE ESTOQUE: Iniciando teste manual...');
      
      // 1. Testar conexão
      const connectionTest = await loyverseApi.testConnection();
      console.log('🔗 Teste de conexão:', connectionTest);
      
      if (!connectionTest.valid) {
        setLastTest(`❌ Conexão falhou: ${connectionTest.message}`);
        return;
      }
      
      // 2. Buscar inventory diretamente
      console.log('📦 Buscando inventory do Loyverse...');
      const inventory = await loyverseApi.getInventory();
      setInventoryData(inventory);
      console.log(`📊 Inventory recebido: ${inventory.length} registros`);
      
      // 3. Buscar produtos
      console.log('🛍️ Buscando produtos do Loyverse...');
      const products = await loyverseApi.getProducts();
      console.log(`🏷️ Produtos recebidos: ${products.length} produtos`);
      
      setLastTest(`✅ Teste concluído: ${inventory.length} registros de estoque, ${products.length} produtos`);
      
    } catch (error) {
      console.error('❌ Erro no teste:', error);
      setLastTest(`❌ Erro: ${error instanceof Error ? error.message : 'Erro desconhecido'}`);
    } finally {
      setTesting(false);
    }
  };

  const handleForceSync = async () => {
    console.log('🔄 SINCRONIZAÇÃO FORÇADA: Iniciando...');
    await refreshProducts();
    console.log('✅ SINCRONIZAÇÃO FORÇADA: Concluída');
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Debug de Estoque - Loyverse
        </CardTitle>
        <CardDescription>
          Ferramenta para testar e debugar a sincronização de estoque com Loyverse
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Status da Conexão */}
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-2">
            {isConnected ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : (
              <AlertCircle className="h-5 w-5 text-red-500" />
            )}
            <span className="font-medium">
              Status: {isConnected ? 'Conectado' : 'Desconectado'}
            </span>
          </div>
          <Badge variant={isSyncing ? 'secondary' : 'outline'}>
            {isSyncing ? 'Sincronizando...' : 'Aguardando'}
          </Badge>
        </div>

        {/* Controles */}
        <div className="flex gap-3">
          <Button 
            onClick={handleTestInventory} 
            disabled={testing}
            variant="outline"
            className="flex items-center gap-2"
          >
            {testing ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Package className="h-4 w-4" />
            )}
            Testar Inventory
          </Button>
          
          <Button 
            onClick={handleForceSync} 
            disabled={isSyncing}
            variant="default"
            className="flex items-center gap-2"
          >
            {isSyncing ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            Forçar Sincronização
          </Button>
        </div>

        {/* Resultado do Último Teste */}
        {lastTest && (
          <div className="p-4 bg-muted rounded-lg">
            <h3 className="font-medium mb-2">Último Teste:</h3>
            <p className="text-sm text-muted-foreground">{lastTest}</p>
          </div>
        )}

        {/* Produtos Atuais */}
        <div>
          <h3 className="font-medium mb-3">Produtos Carregados ({products.length})</h3>
          <div className="grid gap-2 max-h-64 overflow-y-auto">
            {products.map((product, index) => (
              <div key={product.id} className="flex items-center justify-between p-3 bg-muted rounded border">
                <div>
                  <p className="font-medium text-sm">{product.name}</p>
                  <p className="text-xs text-muted-foreground">ID: {product.id}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">R$ {product.price?.toFixed(2)}</p>
                  <Badge variant={product.stock && product.stock > 0 ? 'default' : 'destructive'}>
                    Estoque: {product.stock}
                  </Badge>
                  <StockIndicator 
                    stock={product.stock || 0} 
                    showAnimation={true}
                    className="ml-2"
                  />
                </div>
              </div>
            ))}
            {products.length === 0 && (
              <p className="text-center py-8 text-muted-foreground">
                Nenhum produto carregado. Teste a conexão e sincronização.
              </p>
            )}
          </div>
        </div>

        {/* Dados do Inventory */}
        {inventoryData.length > 0 && (
          <div>
            <h3 className="font-medium mb-3">Dados do Inventory ({inventoryData.length})</h3>
            <div className="grid gap-2 max-h-64 overflow-y-auto">
              {inventoryData.slice(0, 10).map((item, index) => (
                <div key={index} className="p-3 bg-muted rounded border text-xs">
                  <pre>{JSON.stringify(item, null, 2)}</pre>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}