import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { loyverseApi } from '@/services/loyverse';
import { Separator } from '@/components/ui/separator';
import { RefreshCw, Package, AlertTriangle, CheckCircle, Bug } from 'lucide-react';

interface StockData {
  id: string;
  name: string;
  stockLevel: number | undefined;
  rawData: any;
  variants?: any[];
  trackQuantity: any;
}

interface LoyverseProduct {
  id: string;
  name: string;
  stock?: number;
  stock_level?: number;
  stockLevel?: number;
  quantity?: number;
  variants?: any[];
  trackQuantity?: any;
  price?: number;
  [key: string]: any;
}

export function StockRealtimeDebugger() {
  const [stockData, setStockData] = useState<StockData[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] ${message}`, ...prev.slice(0, 49)]);
  };

  const fetchStockData = async () => {
    setLoading(true);
    addLog('🔄 Iniciando busca de dados de estoque...');
    
    try {
      // Testar conexão primeiro
      const connectionTest = await loyverseApi.testConnection();
      addLog(`🔗 Teste de conexão: ${connectionTest.valid ? 'SUCESSO' : 'FALHA'} - ${connectionTest.message}`);
      
      if (!connectionTest.valid) {
        addLog('❌ Não foi possível conectar ao Loyverse');
        return;
      }

      // Buscar produtos DIRETAMENTE do endpoint (sem processamento)
      addLog('📡 Buscando produtos RAW do Loyverse...');
      
      // Fazer requisição direta para o endpoint para ver dados brutos
      const { supabase } = await import('@/integrations/supabase/client');
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'items',
          method: 'GET',
          useStoredToken: true,
          params: { limit: 50 } // Apenas os primeiros 50 para debug
        }
      });

      if (error) {
        addLog(`❌ Erro na requisição: ${error.message}`);
        return;
      }

      const rawProducts = (data as any)?.items || [];
      addLog(`📊 Recebidos ${rawProducts.length} produtos RAW do Loyverse`);

      // Processar dados de estoque
      const processedData: StockData[] = rawProducts.map((product: any) => {
        addLog(`🔍 Processando produto: ${product.name}`);
        
        let stockLevel: number | undefined = undefined;
        
        // Verificar se tem variants
        if (product.variants && Array.isArray(product.variants) && product.variants.length > 0) {
          // Somar estoque de todas as variantes
          const totalStock = product.variants.reduce((total: number, variant: any) => {
            const variantStock = variant.stock_quantity || variant.quantity || variant.stock_level || variant.stockLevel || 0;
            addLog(`  📦 Variante "${variant.variant_name || variant.name || variant.id}": stock=${variantStock}`);
            return total + (typeof variantStock === 'number' ? variantStock : 0);
          }, 0);
          stockLevel = totalStock;
          addLog(`  ✅ Estoque total das variantes: ${totalStock}`);
        } else {
          // Produto sem variantes - verificar estoque direto
          stockLevel = product.stock_quantity || product.quantity || product.stock_level || product.stockLevel || product.stock;
          addLog(`  📦 Estoque direto: ${stockLevel}`);
        }

        addLog(`  🎯 Estoque final para "${product.name}": ${stockLevel}`);

        return {
          id: product.id,
          name: product.item_name || product.name,
          stockLevel,
          rawData: product,
          variants: product.variants,
          trackQuantity: product.track_quantity
        };
      });

      setStockData(processedData);
      setLastUpdate(new Date());
      addLog(`✅ Processamento concluído: ${processedData.length} produtos processados`);
      
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
      addLog(`❌ Erro na busca: ${errorMsg}`);
      console.error('Erro na busca de estoque:', error);
    } finally {
      setLoading(false);
    }
  };

  // Auto refresh
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (autoRefresh) {
      interval = setInterval(() => {
        addLog('🔄 Refresh automático...');
        fetchStockData();
      }, 5000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh]);

  // Fetch inicial
  useEffect(() => {
    fetchStockData();
  }, []);

  const getStockIcon = (stock: number | undefined) => {
    if (stock === undefined || stock === null) return AlertTriangle;
    if (stock === 0) return AlertTriangle;
    if (stock <= 5) return Package;
    return CheckCircle;
  };

  const getStockColor = (stock: number | undefined) => {
    if (stock === undefined || stock === null) return 'destructive';
    if (stock === 0) return 'destructive';
    if (stock <= 5) return 'outline';
    return 'default';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bug className="h-5 w-5" />
            🛠️ Debug de Estoque em Tempo Real - Loyverse
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4">
            <Button onClick={fetchStockData} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Atualizar Estoque
            </Button>
            
            <Button 
              variant={autoRefresh ? "destructive" : "outline"}
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              {autoRefresh ? 'Parar' : 'Iniciar'} Auto-Refresh (5s)
            </Button>
            
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Última atualização: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lista de Produtos com Estoque */}
            <div>
              <h3 className="text-lg font-semibold mb-4">📦 Produtos e Estoque</h3>
              <ScrollArea className="h-96 border rounded-lg p-4">
                <div className="space-y-3">
                  {stockData.map((item) => {
                    const Icon = getStockIcon(item.stockLevel);
                    return (
                      <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{item.name}</h4>
                          <p className="text-xs text-muted-foreground">ID: {item.id}</p>
                          {item.variants && item.variants.length > 0 && (
                            <p className="text-xs text-blue-600">
                              {item.variants.length} variante(s)
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={getStockColor(item.stockLevel) as any}>
                            <Icon className="h-3 w-3 mr-1" />
                            {item.stockLevel !== undefined ? `${item.stockLevel}` : 'N/A'}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>

            {/* Logs em Tempo Real */}
            <div>
              <h3 className="text-lg font-semibold mb-4">📋 Logs de Debug</h3>
              <ScrollArea className="h-96 border rounded-lg p-4 bg-gray-50">
                <div className="space-y-1">
                  {logs.map((log, index) => (
                    <div key={index} className="text-xs font-mono">
                      {log}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>

          <Separator className="my-6" />

          {/* Estatísticas */}
          <div className="grid grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {stockData.length}
                </div>
                <div className="text-xs text-muted-foreground">Total Produtos</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  {stockData.filter(p => p.stockLevel !== undefined && p.stockLevel > 0).length}
                </div>
                <div className="text-xs text-muted-foreground">Com Estoque</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-600">
                  {stockData.filter(p => p.stockLevel === 0).length}
                </div>
                <div className="text-xs text-muted-foreground">Esgotados</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {stockData.filter(p => p.stockLevel === undefined || p.stockLevel === null).length}
                </div>
                <div className="text-xs text-muted-foreground">Sem Dados</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}