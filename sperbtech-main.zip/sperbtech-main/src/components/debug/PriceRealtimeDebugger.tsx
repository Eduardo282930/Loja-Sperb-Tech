import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { loyverseApi } from '@/services/loyverse';
import { Separator } from '@/components/ui/separator';
import { RefreshCw, DollarSign, AlertTriangle, CheckCircle, Bug, Timer, Target, TrendingUp } from 'lucide-react';
import { useProducts } from '@/contexts/ProductContext';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface PriceData {
  id: string;
  name: string;
  appPrice: number;
  loyversePrice: number;
  rawLoyverseData: any;
  priceMatch: boolean;
  timestamp: Date;
  priceSource: string;
}

interface PriceLog {
  timestamp: Date;
  productId: string;
  productName: string;
  event: string;
  oldPrice?: number;
  newPrice?: number;
  rawData?: any;
}

export function PriceRealtimeDebugger() {
  const { products: appProducts, refreshProducts } = useProducts();
  const [priceData, setPriceData] = useState<PriceData[]>([]);
  const [priceLogs, setPriceLogs] = useState<PriceLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [refreshInterval, setRefreshInterval] = useState(3000); // 3 segundos
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const [priceStats, setPriceStats] = useState({
    total: 0,
    matching: 0,
    different: 0,
    errors: 0
  });

  const addLog = (productId: string, productName: string, event: string, oldPrice?: number, newPrice?: number, rawData?: any) => {
    const log: PriceLog = {
      timestamp: new Date(),
      productId,
      productName,
      event,
      oldPrice,
      newPrice,
      rawData
    };
    setPriceLogs(prev => [log, ...prev.slice(0, 99)]); // Manter apenas 100 logs
  };

  const fetchPriceData = async () => {
    setLoading(true);
    addLog('SYSTEM', 'DEBUGGER', '🔄 Iniciando verificação de preços em tempo real...');
    
    try {
      // 1. Testar conexão primeiro
      const connectionTest = await loyverseApi.testConnection();
      addLog('SYSTEM', 'CONNECTION', `🔗 Teste de conexão: ${connectionTest.valid ? 'SUCESSO' : 'FALHA'} - ${connectionTest.message}`);
      
      if (!connectionTest.valid) {
        addLog('SYSTEM', 'ERROR', '❌ Conexão com Loyverse falhou');
        return;
      }

      // 2. Forçar refresh dos produtos do app primeiro
      addLog('SYSTEM', 'SYNC', '🔄 Forçando refresh do app...');
      await refreshProducts();

      // 3. Buscar produtos DIRETAMENTE do Loyverse (dados RAW)
      addLog('SYSTEM', 'LOYVERSE', '📡 Buscando preços DIRETOS do Loyverse...');
      
      // Fazer requisição direta para ver dados brutos de preços
      const { supabase } = await import('@/integrations/supabase/client');
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'items',
          method: 'GET',
          useStoredToken: true,
          params: { limit: 50 } // Primeiros 50 para debug
        }
      });

      if (error) {
        addLog('SYSTEM', 'ERROR', `❌ Erro na requisição: ${error.message}`);
        return;
      }

      const rawProducts = (data as any)?.items || [];
      addLog('SYSTEM', 'LOYVERSE', `📊 Recebidos ${rawProducts.length} produtos RAW do Loyverse`);

      // 4. Processar preços com análise detalhada
      const processedPriceData: PriceData[] = [];
      
      rawProducts.forEach((loyProduct: any) => {
        addLog(loyProduct.id, loyProduct.item_name || loyProduct.name, '🔍 Processando preços...');
        
        let finalPrice: number = 0;
        let priceSource = 'unknown';
        
        // Função para converter preços
        const toNumber = (v: any) => {
          if (typeof v === 'number') return v;
          const n = parseFloat(String(v ?? '0'));
          return isNaN(n) ? 0 : n;
        };

        // Analisar diferentes campos de preço disponíveis
        const priceFields = {
          price: toNumber(loyProduct.price),
          default_price: toNumber(loyProduct.default_price),
          selling_price: toNumber(loyProduct.selling_price),
          retail_price: toNumber(loyProduct.retail_price)
        };

        addLog(loyProduct.id, loyProduct.item_name, `📋 Campos de preço encontrados:`, undefined, undefined, priceFields);

        // Lógica de preço do Loyverse (igual à do serviço)
        if (loyProduct.sold_by_weight) {
          finalPrice = toNumber(loyProduct.default_price ?? loyProduct.price ?? loyProduct.selling_price);
          priceSource = 'sold_by_weight';
        } else if (Array.isArray(loyProduct.variants) && loyProduct.variants.length > 0) {
          const v = loyProduct.variants[0] || {};
          finalPrice = toNumber(v.price ?? v.default_price ?? v.variant_price ?? v.selling_price ?? v.retail_price);
          priceSource = 'first_variant';
          
          addLog(loyProduct.id, loyProduct.item_name, `📦 Usando preço da primeira variante: R$ ${finalPrice}`);
        } else {
          finalPrice = toNumber(loyProduct.price ?? loyProduct.default_price ?? loyProduct.selling_price ?? loyProduct.retail_price);
          priceSource = 'direct_item';
        }

        // Se ainda não encontrou preço válido, tentar outros variants
        if ((!finalPrice || finalPrice <= 0) && loyProduct.variants && loyProduct.variants.length > 0) {
          for (const variant of loyProduct.variants) {
            const variantPrice = toNumber(variant.price ?? variant.default_price ?? variant.selling_price ?? variant.retail_price);
            if (variantPrice && variantPrice > 0) {
              finalPrice = variantPrice;
              priceSource = 'variant_search';
              addLog(loyProduct.id, loyProduct.item_name, `💡 Preço encontrado em busca por variantes: R$ ${finalPrice}`);
              break;
            }
          }
        }

        // Encontrar produto correspondente no app
        const appProduct = appProducts.find(p => p.id === loyProduct.id);
        const appPrice = appProduct?.price || 0;
        
        const priceMatch = Math.abs(appPrice - finalPrice) < 0.01; // Tolerância de 1 centavo
        
        addLog(loyProduct.id, loyProduct.item_name, 
          `💰 Comparação de preços: App R$ ${appPrice.toFixed(2)} vs Loyverse R$ ${finalPrice.toFixed(2)} - ${priceMatch ? 'IGUAL ✅' : 'DIFERENTE ❌'}`
        );

        processedPriceData.push({
          id: loyProduct.id,
          name: loyProduct.item_name || loyProduct.name,
          appPrice,
          loyversePrice: finalPrice,
          rawLoyverseData: loyProduct,
          priceMatch,
          timestamp: new Date(),
          priceSource
        });
      });

      setPriceData(processedPriceData);
      setLastUpdate(new Date());

      // Calcular estatísticas
      const stats = {
        total: processedPriceData.length,
        matching: processedPriceData.filter(p => p.priceMatch).length,
        different: processedPriceData.filter(p => !p.priceMatch && p.loyversePrice > 0).length,
        errors: processedPriceData.filter(p => p.loyversePrice <= 0).length
      };
      setPriceStats(stats);

      addLog('SYSTEM', 'SUMMARY', `✅ Análise concluída: ${stats.matching}/${stats.total} preços corretos`);
      
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
      addLog('SYSTEM', 'ERROR', `❌ Erro na verificação: ${errorMsg}`);
      console.error('Erro na verificação de preços:', error);
    } finally {
      setLoading(false);
    }
  };

  // Auto refresh
  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(() => {
        addLog('SYSTEM', 'AUTO_REFRESH', `🔄 Refresh automático (${refreshInterval}ms)...`);
        fetchPriceData();
      }, refreshInterval);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [autoRefresh, refreshInterval]);

  // Fetch inicial
  useEffect(() => {
    fetchPriceData();
  }, []);

  const getPriceStatusIcon = (priceData: PriceData) => {
    if (priceData.loyversePrice <= 0) return AlertTriangle;
    if (priceData.priceMatch) return CheckCircle;
    return TrendingUp;
  };

  const getPriceStatusColor = (priceData: PriceData) => {
    if (priceData.loyversePrice <= 0) return 'destructive';
    if (priceData.priceMatch) return 'default';
    return 'outline';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            💰 Debug de Preços em Tempo Real - Loyverse vs App
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-4 flex-wrap">
            <Button onClick={fetchPriceData} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Verificar Preços
            </Button>
            
            <div className="flex items-center gap-2">
              <Button 
                variant={autoRefresh ? "destructive" : "outline"}
                onClick={() => setAutoRefresh(!autoRefresh)}
              >
                <Timer className="h-4 w-4 mr-2" />
                {autoRefresh ? 'Parar' : 'Auto-Refresh'}
              </Button>
              
              {autoRefresh && (
                <select 
                  value={refreshInterval} 
                  onChange={(e) => setRefreshInterval(Number(e.target.value))}
                  className="px-2 py-1 border rounded text-sm"
                >
                  <option value={1000}>1s</option>
                  <option value={3000}>3s</option>
                  <option value={5000}>5s</option>
                  <option value={10000}>10s</option>
                </select>
              )}
            </div>
            
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Última verificação: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {priceStats.total}
                </div>
                <div className="text-xs text-muted-foreground">Total Produtos</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  {priceStats.matching}
                </div>
                <div className="text-xs text-muted-foreground">Preços Corretos</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {priceStats.different}
                </div>
                <div className="text-xs text-muted-foreground">Preços Diferentes</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-600">
                  {priceStats.errors}
                </div>
                <div className="text-xs text-muted-foreground">Sem Preço</div>
              </CardContent>
            </Card>
          </div>

          {/* Precisão geral */}
          {priceStats.total > 0 && (
            <Alert className={priceStats.matching === priceStats.total ? "border-green-500 bg-green-50" : "border-orange-500 bg-orange-50"}>
              <Target className="h-4 w-4" />
              <AlertDescription>
                <div className="font-medium">
                  Precisão dos Preços: {((priceStats.matching / priceStats.total) * 100).toFixed(1)}%
                </div>
                <div className="text-sm">
                  {priceStats.matching === priceStats.total 
                    ? "🎉 Todos os preços estão sincronizados corretamente!"
                    : `⚠️ ${priceStats.different + priceStats.errors} produtos com preços incorretos detectados.`
                  }
                </div>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lista de Produtos com Preços */}
            <div>
              <h3 className="text-lg font-semibold mb-4">💰 Comparação de Preços</h3>
              <ScrollArea className="h-96 border rounded-lg p-4">
                <div className="space-y-3">
                  {priceData.map((item) => {
                    const Icon = getPriceStatusIcon(item);
                    const priceDiff = Math.abs(item.appPrice - item.loyversePrice);
                    
                    return (
                      <div key={item.id} className={`p-3 border rounded-lg ${
                        item.priceMatch ? 'bg-green-50 border-green-200' : 
                        item.loyversePrice <= 0 ? 'bg-red-50 border-red-200' : 
                        'bg-orange-50 border-orange-200'
                      }`}>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium text-sm">{item.name}</h4>
                            <p className="text-xs text-muted-foreground">ID: {item.id}</p>
                            <p className="text-xs text-muted-foreground">Fonte: {item.priceSource}</p>
                            <p className="text-xs text-muted-foreground">
                              Atualizado: {item.timestamp.toLocaleTimeString()}
                            </p>
                          </div>
                          <div className="text-right space-y-1 min-w-[120px]">
                            <div className="text-sm">
                              App: <Badge variant="outline">R$ {item.appPrice.toFixed(2)}</Badge>
                            </div>
                            <div className="text-sm">
                              Loyverse: <Badge variant="outline">R$ {item.loyversePrice.toFixed(2)}</Badge>
                            </div>
                            {!item.priceMatch && priceDiff > 0.01 && (
                              <div className="text-xs text-red-600">
                                Diferença: R$ {priceDiff.toFixed(2)}
                              </div>
                            )}
                          </div>
                          <div className="ml-3">
                            <Icon className={`h-5 w-5 ${
                              item.priceMatch ? 'text-green-500' : 
                              item.loyversePrice <= 0 ? 'text-red-500' : 
                              'text-orange-500'
                            }`} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>

            {/* Logs em Tempo Real */}
            <div>
              <h3 className="text-lg font-semibold mb-4">📋 Logs de Verificação</h3>
              <ScrollArea className="h-96 border rounded-lg p-4 bg-gray-50">
                <div className="space-y-1">
                  {priceLogs.map((log, index) => (
                    <div key={index} className="text-xs font-mono">
                      <span className="text-gray-500">
                        [{log.timestamp.toLocaleTimeString()}]
                      </span>
                      <span className="ml-2 font-medium">
                        {log.productName}:
                      </span>
                      <span className="ml-1">
                        {log.event}
                      </span>
                      {log.oldPrice !== undefined && log.newPrice !== undefined && (
                        <span className="ml-1 text-blue-600">
                          R$ {log.oldPrice.toFixed(2)} → R$ {log.newPrice.toFixed(2)}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instruções */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Bug className="h-4 w-4" />
            Como Usar Esta Ferramenta
          </CardTitle>
        </CardHeader>
        <CardContent className="text-xs space-y-2">
          <p><strong>1.</strong> Clique em "Verificar Preços" para comparar preços App vs Loyverse</p>
          <p><strong>2.</strong> Use "Auto-Refresh" para monitoramento contínuo (1-10 segundos)</p>
          <p><strong>3.</strong> Produtos com preços diferentes aparecerão destacados</p>
          <p><strong>4.</strong> Verifique os logs detalhados para análise de problemas</p>
          <p><strong>5.</strong> A precisão deve ser 100% - qualquer diferença indica problema de sincronização</p>
          <p className="text-muted-foreground">
            ⚠️ Esta ferramenta é apenas para desenvolvimento. Preços devem ser IDÊNTICOS entre Loyverse e App.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}