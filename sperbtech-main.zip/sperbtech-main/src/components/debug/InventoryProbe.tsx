import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Database } from 'lucide-react';

const InventoryProbe: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any[]>([]);
  const [message, setMessage] = useState<string>('');
  const [rawResponse, setRawResponse] = useState<any>(null);

  const logRawInventoryData = (data: any) => {
    console.log('🔍 InventoryProbe: DADOS BRUTOS COMPLETOS recebidos do Loyverse:');
    console.log('📋 Tipo de resposta:', typeof data);
    console.log('📋 Chaves principais:', Object.keys(data || {}));
    console.log('📋 Resposta completa:', data);
    
    // Tentar diferentes estruturas de resposta
    let inventoryArray = [];
    let dataSource = 'unknown';
    
    if (Array.isArray(data?.inventory)) {
      inventoryArray = data.inventory;
      dataSource = 'data.inventory';
    } else if (Array.isArray(data?.inventory_levels)) {
      inventoryArray = data.inventory_levels;
      dataSource = 'data.inventory_levels';
    } else if (Array.isArray(data)) {
      inventoryArray = data;
      dataSource = 'data (array direto)';
    }
    
    console.log(`🔍 InventoryProbe: Fonte detectada: ${dataSource}`);
    console.log(`🔍 InventoryProbe: Total de registros: ${inventoryArray.length}`);
    
    if (inventoryArray.length > 0) {
      console.log('🔍 InventoryProbe: PRIMEIROS 10 REGISTROS (JSON BRUTO):');
      inventoryArray.slice(0, 10).forEach((record, index) => {
        console.log(`=== REGISTRO ${index + 1} ===`);
        console.log('📄 JSON completo:', JSON.stringify(record, null, 2));
        console.log('🔑 Campos essenciais:', {
          item_id: record.item_id,
          variant_id: record.variant_id,
          store_id: record.store_id,
          quantity: record.quantity,
          quantity_on_hand: record.quantity_on_hand,
          available_quantity: record.available_quantity,
          stock: record.stock
        });
        console.log('📝 Todos os campos disponíveis:', Object.keys(record));
      });
      
      // Análise de campos de quantidade
      const firstRecord = inventoryArray[0];
      const quantityFields = ['quantity', 'quantity_on_hand', 'available_quantity', 'stock'];
      const availableFields = quantityFields.filter(field => 
        Object.prototype.hasOwnProperty.call(firstRecord, field)
      );
      
      console.log('🔍 InventoryProbe: CAMPOS DE QUANTIDADE DISPONÍVEIS:', availableFields);
      
      return { inventoryArray, dataSource, availableFields, firstRecord };
    }
    
    return { inventoryArray: [], dataSource, availableFields: [], firstRecord: null };
  };

  const runProbe = async () => {
    setLoading(true);
    setMessage('');
    setResult([]);
    setRawResponse(null);
    
    try {
      console.log('🔍 InventoryProbe: === INICIANDO TESTE DE /inventory ===');
      const { supabase } = await import('@/integrations/supabase/client');
      
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'inventory',
          method: 'GET',
          useStoredToken: true,
          params: { limit: 25 }
        }
      });

      if (error) {
        const errorMsg = `Erro: ${error.message || 'Falha ao chamar /inventory'}`;
        setMessage(errorMsg);
        console.error('❌ InventoryProbe erro:', error);
        return;
      }

      console.log('✅ InventoryProbe: Resposta recebida com sucesso');
      setRawResponse(data);
      
      const analysisResult = logRawInventoryData(data);
      setResult(analysisResult.inventoryArray);
      
      if (analysisResult.availableFields.length > 0) {
        setMessage(`✅ Campos de quantidade encontrados: ${analysisResult.availableFields.join(', ')}`);
      } else {
        setMessage('❌ NENHUM CAMPO DE ESTOQUE ENCONTRADO');
      }

    } catch (err: any) {
      const errorMsg = `Erro inesperado: ${err.message}`;
      setMessage(errorMsg);
      console.error('❌ InventoryProbe erro inesperado:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Auto-executa ao montar
    runProbe();
  }, []);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" /> InventoryProbe - Dados Brutos do Loyverse
        </CardTitle>
        <CardDescription>
          Teste direto do endpoint /inventory para validação de campos de estoque
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Button onClick={runProbe} disabled={loading} variant="outline" className="flex items-center gap-2">
            {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Database className="h-4 w-4" />}
            Executar Probe
          </Button>
          {message && (
            <Badge variant={message.includes('✅') ? 'default' : 'destructive'}>{message}</Badge>
          )}
        </div>

        {rawResponse && (
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">📋 Resposta Bruta (JSON):</h4>
              <pre className="bg-muted rounded p-3 border text-xs overflow-x-auto">
                {JSON.stringify(rawResponse, null, 2)}
              </pre>
            </div>
            
            {result.length > 0 && (
              <div>
                <h4 className="font-semibold mb-2">🔍 Primeiros 10 Registros de Inventory:</h4>
                <div className="grid gap-2 max-h-96 overflow-y-auto">
                  {result.slice(0, 10).map((record, i) => (
                    <div key={i} className="bg-muted rounded p-3 border">
                      <div className="font-semibold text-xs mb-2">Registro {i + 1}:</div>
                      <div className="text-xs space-y-1">
                        <div><strong>item_id:</strong> {record.item_id || 'N/A'}</div>
                        <div><strong>variant_id:</strong> {record.variant_id || 'null'}</div>
                        <div><strong>store_id:</strong> {record.store_id || 'N/A'}</div>
                        <div><strong>quantity:</strong> {record.quantity ?? 'N/A'}</div>
                        <div><strong>quantity_on_hand:</strong> {record.quantity_on_hand ?? 'N/A'}</div>
                        <div><strong>available_quantity:</strong> {record.available_quantity ?? 'N/A'}</div>
                        <div><strong>stock:</strong> {record.stock ?? 'N/A'}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default InventoryProbe;