import { useProducts } from '@/contexts/ProductContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RefreshCw, AlertTriangle, CheckCircle } from 'lucide-react';

export const ProductDebug = () => {
  const { 
    products, 
    loading, 
    error, 
    isConnected, 
    connectionStatus,
    refreshProducts,
    lastSyncTimestamp 
  } = useProducts();

  const handleForceRefresh = async () => {
    console.log('🔄 Forçando refresh dos produtos...');
    await refreshProducts();
  };

  const productsWithInvalidPrice = products.filter(p => !p.price || p.price <= 0);
  const productsWithValidPrice = products.filter(p => p.price && p.price > 0);

  return (
    <Card className="m-4">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <RefreshCw className="h-5 w-5" />
          Debug do Sistema de Produtos
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <strong>Status de Conexão:</strong>
            <div className="flex items-center gap-2 mt-1">
              {isConnected ? (
                <CheckCircle className="h-4 w-4 text-green-500" />
              ) : (
                <AlertTriangle className="h-4 w-4 text-red-500" />
              )}
              <span>{connectionStatus}</span>
            </div>
          </div>
          
          <div>
            <strong>Total de Produtos:</strong>
            <div className="mt-1">{products.length}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <strong>Produtos com preço válido:</strong>
            <div className="mt-1 text-green-600">{productsWithValidPrice.length}</div>
          </div>
          
          <div>
            <strong>Produtos com preço inválido:</strong>
            <div className="mt-1 text-red-600">{productsWithInvalidPrice.length}</div>
          </div>
        </div>

        {lastSyncTimestamp && (
          <div>
            <strong>Última sincronização:</strong>
            <div className="mt-1">{lastSyncTimestamp.toLocaleString('pt-BR')}</div>
          </div>
        )}

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded">
            <strong>Erro:</strong> {error}
          </div>
        )}

        <div className="flex gap-2">
          <Button onClick={handleForceRefresh} disabled={loading}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Forçar Sincronização
          </Button>
        </div>

        {productsWithInvalidPrice.length > 0 && (
          <div className="mt-4">
            <strong className="text-red-600">⚠️ Produtos com preço inválido ainda visíveis:</strong>
            <div className="mt-2 space-y-1 text-sm">
              {productsWithInvalidPrice.slice(0, 5).map(product => (
                <div key={product.id} className="p-2 bg-gray-50 rounded">
                  {product.name} - Preço: R$ {product.price}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};