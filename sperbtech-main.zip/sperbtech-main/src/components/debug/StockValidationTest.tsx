import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { loyverseApi } from '@/services/loyverse';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertTriangle, RefreshCw, Package } from 'lucide-react';

interface ValidationResult {
  productName: string;
  productId: string;
  hasVariants: boolean;
  variantCount: number;
  inventoryEntries: number;
  finalStock: number;
  details: any;
}

export function StockValidationTest() {
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<ValidationResult[]>([]);
  const [summary, setSummary] = useState<any>(null);

  const runValidation = async () => {
    setTesting(true);
    console.log('🔍 VALIDAÇÃO: Testando novo algoritmo de merge...');

    try {
      // 1. Buscar items
      console.log('📄 Buscando items...');
      const items = await loyverseApi.getItems();
      console.log(`✅ ${items.length} items encontrados`);

      // 2. Buscar inventory
      console.log('📦 Buscando inventory...');
      const inventory = await loyverseApi.getInventory();
      console.log(`✅ ${inventory.length} registros de inventory`);

      // 3. Fazer merge com logs detalhados
      console.log('🔄 Executando merge...');
      const products = loyverseApi.mergeItemsWithInventory(items, inventory);

      // 4. Analisar resultados
      const validationResults: ValidationResult[] = products.slice(0, 10).map(product => {
        const originalItem = items.find(i => i.id === product.id);
        const inventoryForItem = inventory.filter(inv => inv.item_id === product.id);
        
        return {
          productName: product.name,
          productId: product.id,
          hasVariants: originalItem?.variants?.length > 0,
          variantCount: originalItem?.variants?.length || 0,
          inventoryEntries: inventoryForItem.length,
          finalStock: product.stock,
          details: {
            variants: originalItem?.variants?.map((v: any) => ({
              id: v.variant_id || v.id,
              sku: v.sku
            })) || [],
            inventoryEntries: inventoryForItem.map(inv => ({
              variant_id: inv.variant_id,
              store_id: inv.store_id,
              quantity: inv.quantity,
              quantity_on_hand: inv.quantity_on_hand,
              available_quantity: inv.available_quantity,
              stock: inv.stock
            }))
          }
        };
      });

      // 5. Criar resumo
      const withStock = validationResults.filter(r => r.finalStock > 0).length;
      const withoutStock = validationResults.filter(r => r.finalStock === 0).length;
      const withVariants = validationResults.filter(r => r.hasVariants).length;
      const withInventory = validationResults.filter(r => r.inventoryEntries > 0).length;

      setSummary({
        totalTested: validationResults.length,
        withStock,
        withoutStock,
        withVariants,
        withInventory,
        totalItems: items.length,
        totalInventory: inventory.length
      });

      setResults(validationResults);

      console.log('✅ VALIDAÇÃO CONCLUÍDA');
      console.log('📊 Resumo:', {
        testados: validationResults.length,
        comEstoque: withStock,
        semEstoque: withoutStock,
        comVariantes: withVariants,
        comInventory: withInventory
      });

    } catch (error) {
      console.error('❌ Erro na validação:', error);
      setSummary({ error: error instanceof Error ? error.message : 'Erro desconhecido' });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Validação do Algoritmo de Merge
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button 
          onClick={runValidation} 
          disabled={testing}
          className="flex items-center gap-2"
        >
          {testing ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
          {testing ? 'Validando...' : 'Executar Validação Completa'}
        </Button>

        {summary && (
          <>
            {summary.error ? (
              <Alert className="border-red-500 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                <AlertDescription>
                  <strong>Erro:</strong> {summary.error}
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="border-blue-500 bg-blue-50">
                <CheckCircle className="h-4 w-4 text-blue-500" />
                <AlertDescription>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <strong>Dados Coletados:</strong>
                      <br />Items: {summary.totalItems}
                      <br />Inventory: {summary.totalInventory}
                    </div>
                    <div>
                      <strong>Produtos Testados:</strong>
                      <br />Total: {summary.totalTested}
                      <br />Com estoque: <Badge variant="default">{summary.withStock}</Badge>
                      <br />Sem estoque: <Badge variant="secondary">{summary.withoutStock}</Badge>
                    </div>
                    <div>
                      <strong>Estrutura:</strong>
                      <br />Com variantes: {summary.withVariants}
                      <br />Com inventory: {summary.withInventory}
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </>
        )}

        {results.length > 0 && (
          <div className="space-y-3">
            <h3 className="font-semibold">Detalhes dos Produtos (Top 10)</h3>
            {results.map((result, index) => (
              <Card key={result.productId} className="border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium">{result.productName}</h4>
                      <div className="text-sm text-muted-foreground">
                        ID: {result.productId}
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge 
                        variant={result.finalStock > 0 ? "default" : "secondary"}
                      >
                        Estoque: {result.finalStock}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <strong>Variantes:</strong> {result.variantCount}
                      {result.hasVariants && (
                        <div className="text-muted-foreground">
                          {result.details.variants.map((v: any, i: number) => (
                            <div key={i}>ID: {v.id}</div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div>
                      <strong>Inventory:</strong> {result.inventoryEntries} registros
                    </div>
                    <div>
                      <strong>Status:</strong>
                      <br />
                      {result.finalStock > 0 ? (
                        <span className="text-green-600">✅ Merge OK</span>
                      ) : result.inventoryEntries > 0 ? (
                        <span className="text-orange-600">⚠️ Sem estoque</span>
                      ) : (
                        <span className="text-gray-600">📋 Sem inventory</span>
                      )}
                    </div>
                  </div>

                  {result.inventoryEntries > 0 && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-xs font-medium">
                        Ver detalhes do inventory
                      </summary>
                      <pre className="text-xs mt-1 p-2 bg-gray-50 border rounded overflow-x-auto">
                        {JSON.stringify(result.details.inventoryEntries, null, 2)}
                      </pre>
                    </details>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}