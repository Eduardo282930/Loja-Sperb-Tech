import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Play, 
  Square,
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Clock,
  RefreshCw,
  Eye,
  Target,
  Zap
} from 'lucide-react';
import { loyverseApi } from '@/services/loyverse';
import { RealTimeStatus } from '@/components/ui/real-time-status';
import { useProducts } from '@/contexts/ProductContext';
import { useToast } from '@/hooks/use-toast';

interface StockTestResult {
  productId: string;
  productName: string;
  loyverseStock: number;
  appStock: number;
  match: boolean;
  timestamp: Date;
}

export function RealTimeStockValidator() {
  const { products, refreshProducts, isConnected, isSyncing, lastSyncTimestamp } = useProducts();
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<StockTestResult[]>([]);
  const [totalTests, setTotalTests] = useState(0);
  const [successfulTests, setSuccessfulTests] = useState(0);
  const [lastTestTime, setLastTestTime] = useState<Date | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const performStockValidation = async () => {
    try {
      console.log('🎯 INICIANDO VALIDAÇÃO PROFISSIONAL DE ESTOQUE...');
      
      // 1. Buscar estoque direto do Loyverse
      const loyverseProducts = await loyverseApi.getProducts();
      console.log(`📊 Loyverse retornou ${loyverseProducts.length} produtos`);
      
      // 2. Forçar refresh dos produtos do app
      await refreshProducts();
      
      // 3. Comparar produto por produto
      const validationResults: StockTestResult[] = [];
      
      for (const loyverseProduct of loyverseProducts) {
        const appProduct = products.find(p => p.id === loyverseProduct.id);
        
        if (appProduct) {
          const match = appProduct.stock === loyverseProduct.stock;
          
          const result: StockTestResult = {
            productId: loyverseProduct.id,
            productName: loyverseProduct.name,
            loyverseStock: loyverseProduct.stock || 0,
            appStock: appProduct.stock || 0,
            match,
            timestamp: new Date()
          };
          
          validationResults.push(result);
          
          console.log(`${match ? '✅' : '❌'} ${loyverseProduct.name}:`, {
            Loyverse: loyverseProduct.stock,
            App: appProduct.stock,
            Match: match
          });
        } else {
          console.log(`⚠️ Produto ${loyverseProduct.name} não encontrado no app`);
        }
      }
      
      // 4. Atualizar estatísticas
      setTestResults(validationResults);
      setTotalTests(prev => prev + validationResults.length);
      setSuccessfulTests(prev => prev + validationResults.filter(r => r.match).length);
      setLastTestTime(new Date());
      
      // 5. Relatório do teste
      const matches = validationResults.filter(r => r.match).length;
      const total = validationResults.length;
      const accuracy = total > 0 ? (matches / total) * 100 : 0;
      
      console.log(`📋 RELATÓRIO DE VALIDAÇÃO:`, {
        Total: total,
        Corretos: matches,
        Incorretos: total - matches,
        Precisão: `${accuracy.toFixed(1)}%`
      });
      
      if (accuracy === 100) {
        toast({
          title: '✅ Validação 100% Precisa!',
          description: `Todos os ${total} produtos estão sincronizados perfeitamente`,
        });
      } else {
        toast({
          title: '⚠️ Divergências Encontradas',
          description: `${total - matches} de ${total} produtos com estoque incorreto`,
          variant: 'destructive',
        });
      }
      
    } catch (error) {
      console.error('❌ Erro na validação:', error);
      toast({
        title: 'Erro na Validação',
        description: error instanceof Error ? error.message : 'Erro desconhecido',
        variant: 'destructive',
      });
    }
  };

  const startContinuousValidation = () => {
    if (isRunning) return;
    
    setIsRunning(true);
    setTestResults([]);
    setTotalTests(0);
    setSuccessfulTests(0);
    
    console.log('🚀 INICIANDO VALIDAÇÃO CONTÍNUA EM TEMPO REAL...');
    
    // Teste inicial
    performStockValidation();
    
    // Testes a cada 8 segundos
    intervalRef.current = setInterval(() => {
      performStockValidation();
    }, 8000);
    
    toast({
      title: 'Validação Iniciada',
      description: 'Validando estoques a cada 8 segundos',
    });
  };

  const stopContinuousValidation = () => {
    if (!isRunning) return;
    
    setIsRunning(false);
    
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    
    console.log('⏹️ Validação contínua interrompida');
    
    toast({
      title: 'Validação Interrompida',
      description: 'Validação contínua foi parada',
    });
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const accuracy = totalTests > 0 ? (successfulTests / totalTests) * 100 : 0;
  const recentResults = testResults.slice(-10); // Últimos 10 resultados

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-green-500" />
            Validador de Estoque em Tempo Real
          </CardTitle>
          <CardDescription>
            Sistema profissional de validação que compara o estoque do app com o Loyverse a cada 8 segundos
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Status em Tempo Real */}
          <RealTimeStatus
            isConnected={isConnected}
            isSyncing={isSyncing}
            lastSync={lastSyncTimestamp}
            className="mb-4"
          />
          
          {/* Controles */}
          <div className="flex gap-3">
            <Button
              onClick={startContinuousValidation}
              disabled={isRunning}
              className="flex items-center gap-2"
            >
              <Play className="h-4 w-4" />
              Iniciar Validação Contínua
            </Button>
            
            <Button
              onClick={stopContinuousValidation}
              disabled={!isRunning}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Square className="h-4 w-4" />
              Parar Validação
            </Button>
            
            <Button
              onClick={performStockValidation}
              variant="secondary"
              className="flex items-center gap-2"
            >
              <Eye className="h-4 w-4" />
              Teste Manual
            </Button>
          </div>

          {/* Status */}
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-2">
              {isRunning ? (
                <>
                  <Zap className="h-5 w-5 text-green-500 animate-pulse" />
                  <span className="font-medium text-green-700">Validação Ativa</span>
                </>
              ) : (
                <>
                  <Clock className="h-5 w-5 text-gray-500" />
                  <span className="font-medium text-gray-600">Aguardando</span>
                </>
              )}
            </div>
            <Badge variant={isRunning ? 'default' : 'secondary'}>
              {isRunning ? 'Executando' : 'Parado'}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Estatísticas */}
      {totalTests > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-600">{totalTests}</div>
              <p className="text-sm text-muted-foreground">Total de Testes</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-600">{successfulTests}</div>
              <p className="text-sm text-muted-foreground">Testes Corretos</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-red-600">{totalTests - successfulTests}</div>
              <p className="text-sm text-muted-foreground">Divergências</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className={`text-2xl font-bold ${accuracy === 100 ? 'text-green-600' : 'text-orange-600'}`}>
                {accuracy.toFixed(1)}%
              </div>
              <p className="text-sm text-muted-foreground">Precisão</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Última Validação */}
      {lastTestTime && (
        <Alert className={accuracy === 100 ? 'border-green-500' : 'border-orange-500'}>
          {accuracy === 100 ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          )}
          <AlertDescription>
            <strong>Último teste:</strong> {lastTestTime.toLocaleTimeString('pt-BR')} - 
            {accuracy === 100 ? (
              <span className="text-green-700 font-medium"> Sincronização perfeita!</span>
            ) : (
              <span className="text-orange-700 font-medium"> {totalTests - successfulTests} divergências encontradas</span>
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Resultados Recentes */}
      {recentResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Últimas Validações</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {recentResults.map((result, index) => (
                <div
                  key={`${result.productId}-${result.timestamp.getTime()}`}
                  className={`flex items-center justify-between p-3 rounded border ${
                    result.match 
                      ? 'bg-green-50 border-green-200' 
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div>
                    <div className="font-medium text-sm">{result.productName}</div>
                    <div className="text-xs text-muted-foreground">
                      {result.timestamp.toLocaleTimeString('pt-BR')}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="text-right text-sm">
                      <div>Loyverse: <strong>{result.loyverseStock}</strong></div>
                      <div>App: <strong>{result.appStock}</strong></div>
                    </div>
                    
                    {result.match ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instruções */}
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Como usar o validador profissional:</strong>
          <br />
          1. Clique em "Iniciar Validação Contínua" para começar os testes automáticos
          <br />
          2. Vá ao Loyverse e altere o estoque de um produto
          <br />
          3. Aguarde até 8 segundos e veja se o app detecta a mudança
          <br />
          4. Precisão deve ser 100% - qualquer divergência será destacada
        </AlertDescription>
      </Alert>
    </div>
  );
}