import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { RefreshCw, Package, AlertTriangle, CheckCircle, Bug, Eye, Database } from 'lucide-react';
import { loyverseApi } from '@/services/loyverse';
import { useProducts } from '@/contexts/ProductContext';
import { toast } from '@/hooks/use-toast';

interface InventoryItem {
  item_id: string;
  variant_id?: string;
  in_stock: number;
  store_id?: string;
}

interface ProductComparison {
  id: string;
  name: string;
  loyverseStock: number | 'N/A';
  appStock: number | undefined;
  status: 'match' | 'mismatch' | 'missing_loyverse' | 'missing_app';
}

export function EstoqueDebugPanel() {
  const { products, refreshProducts } = useProducts();
  const [loading, setLoading] = useState(false);
  const [inventoryData, setInventoryData] = useState<InventoryItem[]>([]);
  const [comparisons, setComparisons] = useState<ProductComparison[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] ${message}`, ...prev.slice(0, 19)]);
  };

  const compareStocks = async () => {
    setLoading(true);
    addLog('🔄 Iniciando comparação de estoque...');
    
    try {
      // 1. Buscar inventory do Loyverse
      addLog('📡 Buscando dados do inventory do Loyverse...');
      const inventory = await loyverseApi.getInventory();
      setInventoryData(inventory);
      addLog(`📦 Recebidos ${inventory.length} registros de inventory`);

      // 2. Consolidar estoque por item_id do Loyverse
      const loyverseStockMap = new Map<string, number>();
      inventory.forEach((item: InventoryItem) => {
        if (item.item_id) {
          const current = loyverseStockMap.get(item.item_id) || 0;
          loyverseStockMap.set(item.item_id, current + (item.in_stock || 0));
        }
      });
      addLog(`📊 Consolidados ${loyverseStockMap.size} itens únicos do Loyverse`);

      // 3. Atualizar produtos do app
      addLog('🔄 Atualizando produtos do app...');
      await refreshProducts();
      
      // 4. Comparar estoques
      const productIds = new Set([
        ...Array.from(loyverseStockMap.keys()),
        ...products.map(p => p.id)
      ]);

      const comparisonsResult: ProductComparison[] = Array.from(productIds).map(id => {
        const appProduct = products.find(p => p.id === id);
        const loyverseStock = loyverseStockMap.get(id);

        let status: ProductComparison['status'] = 'match';
        
        if (loyverseStock === undefined && !appProduct) {
          status = 'missing_loyverse';
        } else if (loyverseStock !== undefined && !appProduct) {
          status = 'missing_app';
        } else if (loyverseStock !== undefined && appProduct && loyverseStock !== appProduct.stock) {
          status = 'mismatch';
        }

        return {
          id,
          name: appProduct?.name || `Item ${id}`,
          loyverseStock: loyverseStock !== undefined ? loyverseStock : 'N/A',
          appStock: appProduct?.stock,
          status
        };
      });

      setComparisons(comparisonsResult);
      setLastUpdate(new Date());

      // 5. Log de resultados
      const matches = comparisonsResult.filter(c => c.status === 'match').length;
      const mismatches = comparisonsResult.filter(c => c.status === 'mismatch').length;
      const missing = comparisonsResult.filter(c => c.status === 'missing_app' || c.status === 'missing_loyverse').length;

      addLog(`✅ Comparação concluída: ${matches} iguais, ${mismatches} diferentes, ${missing} faltando`);

      if (mismatches > 0) {
        toast({
          title: "Divergências encontradas!",
          description: `${mismatches} produtos com estoque diferente entre Loyverse e App`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Estoques sincronizados!",
          description: "Todos os produtos estão com estoque correto",
        });
      }
      
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
      addLog(`❌ Erro na comparação: ${errorMsg}`);
      toast({
        title: "Erro na comparação",
        description: errorMsg,
        variant: "destructive",
      });
      console.error('Erro na comparação de estoque:', error);
    } finally {
      setLoading(false);
    }
  };

  // Auto refresh
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (autoRefresh) {
      interval = setInterval(() => {
        addLog('🔄 Refresh automático...');
        compareStocks();
      }, 10000); // 10 segundos
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh, products]);

  // Comparação inicial
  useEffect(() => {
    compareStocks();
  }, []);

  const getStatusColor = (status: ProductComparison['status']) => {
    switch (status) {
      case 'match': return 'default';
      case 'mismatch': return 'destructive';
      case 'missing_app': return 'secondary';
      case 'missing_loyverse': return 'outline';
      default: return 'default';
    }
  };

  const getStatusIcon = (status: ProductComparison['status']) => {
    switch (status) {
      case 'match': return CheckCircle;
      case 'mismatch': return AlertTriangle;
      case 'missing_app': return Package;
      case 'missing_loyverse': return Database;
      default: return Bug;
    }
  };

  const getStatusText = (status: ProductComparison['status']) => {
    switch (status) {
      case 'match': return 'IGUAL';
      case 'mismatch': return 'DIFERENTE';
      case 'missing_app': return 'SÓ NO LOYVERSE';
      case 'missing_loyverse': return 'SÓ NO APP';
      default: return 'DESCONHECIDO';
    }
  };

  const stats = {
    total: comparisons.length,
    matches: comparisons.filter(c => c.status === 'match').length,
    mismatches: comparisons.filter(c => c.status === 'mismatch').length,
    missing: comparisons.filter(c => c.status === 'missing_app' || c.status === 'missing_loyverse').length,
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            🔍 Painel de Debug de Estoque - Loyverse vs App
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <Button onClick={compareStocks} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Comparar Estoques
            </Button>
            
            <Button 
              variant={autoRefresh ? "destructive" : "outline"}
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              {autoRefresh ? 'Parar' : 'Iniciar'} Auto-Refresh (10s)
            </Button>
            
            {lastUpdate && (
              <span className="text-sm text-muted-foreground">
                Última comparação: {lastUpdate.toLocaleTimeString()}
              </span>
            )}
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
                <div className="text-xs text-muted-foreground">Total</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">{stats.matches}</div>
                <div className="text-xs text-muted-foreground">Iguais</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-600">{stats.mismatches}</div>
                <div className="text-xs text-muted-foreground">Diferentes</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-orange-600">{stats.missing}</div>
                <div className="text-xs text-muted-foreground">Faltando</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Comparação de Produtos */}
            <div>
              <h3 className="text-lg font-semibold mb-4">📋 Comparação Loyverse vs App</h3>
              <ScrollArea className="h-96 border rounded-lg p-4">
                <div className="space-y-3">
                  {comparisons.map((comp) => {
                    const Icon = getStatusIcon(comp.status);
                    return (
                      <div key={comp.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{comp.name}</h4>
                          <p className="text-xs text-muted-foreground">ID: {comp.id}</p>
                          <div className="flex gap-2 mt-1">
                            <span className="text-xs">
                              Loyverse: <strong>{comp.loyverseStock}</strong>
                            </span>
                            <span className="text-xs">
                              App: <strong>{comp.appStock ?? 'N/A'}</strong>
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={getStatusColor(comp.status) as any}>
                            <Icon className="h-3 w-3 mr-1" />
                            {getStatusText(comp.status)}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </div>

            {/* Logs em Tempo Real */}
            <div>
              <h3 className="text-lg font-semibold mb-4">📋 Logs de Debug</h3>
              <ScrollArea className="h-96 border rounded-lg p-4 bg-gray-50">
                <div className="space-y-1">
                  {logs.map((log, index) => (
                    <div key={index} className="text-xs font-mono">
                      {log}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>

          <Separator className="my-6" />

          {/* Instruções */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-medium text-blue-800 mb-2">📖 Como usar este painel:</h3>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• <strong>Verde (IGUAL)</strong>: Estoque do Loyverse = estoque do App ✅</li>
              <li>• <strong>Vermelho (DIFERENTE)</strong>: Estoque não bate - precisa sincronizar ⚠️</li>
              <li>• <strong>Laranja (FALTANDO)</strong>: Produto existe só em um dos sistemas</li>
              <li>• O painel atualiza automaticamente a cada 10 segundos quando habilitado</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}