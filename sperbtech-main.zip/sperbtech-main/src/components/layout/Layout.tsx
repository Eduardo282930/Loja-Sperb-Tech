import { ReactNode, useState } from 'react';
import Header from './Header';
import Navigation from './Navigation';
import SellerPanel from '@/components/seller/SellerPanel';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lock } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
}

const SELLER_PASSWORD = 'edu33719443';

const Layout = ({ children }: LayoutProps) => {
  const [showSellerAuth, setShowSellerAuth] = useState(false);
  const [showSellerPanel, setShowSellerPanel] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // Escutar evento de abertura do painel do vendedor
  if (typeof window !== 'undefined') {
    (window as any).openSellerPanel = () => {
      setShowSellerAuth(true);
    };
  }

  const handleSellerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === SELLER_PASSWORD) {
      setShowSellerAuth(false);
      setShowSellerPanel(true);
      setPassword('');
      setError('');
    } else {
      setError('Senha incorreta');
    }
  };

  const handleSellerLogout = () => {
    setShowSellerPanel(false);
  };

  if (showSellerPanel) {
    return <SellerPanel onLogout={handleSellerLogout} />;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <main className="flex-1 pb-20">{children}</main>
      
      <div className="fixed bottom-0 left-0 right-0 z-40">
        <Navigation />
      </div>

      {showSellerAuth && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5" />
                Painel do Vendedor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSellerLogin} className="space-y-4">
                <div>
                  <Input
                    type="password"
                    placeholder="Senha"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full"
                  />
                  {error && <p className="text-sm text-destructive mt-2">{error}</p>}
                </div>
                <div className="flex gap-2">
                  <Button type="submit" className="flex-1">
                    Entrar
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowSellerAuth(false);
                      setPassword('');
                      setError('');
                    }}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Layout;
