import { Search, ShoppingCart, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart } from '@/contexts/CartContext';
import { Badge } from '@/components/ui/badge';
import { useState, useEffect, useRef } from 'react';
import { useProducts } from '@/contexts/ProductContext';
import { useCategories } from '@/contexts/CategoryContext';
import whatsappLogo from '@/assets/whatsapp-logo.png';

const Header = () => {
  const { getItemCount } = useCart();
  const navigate = useNavigate();
  const { products } = useProducts();
  const { categories } = useCategories();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<Array<{id: string, name: string, highlight?: string}>>([]);
  const [isFocused, setIsFocused] = useState(false);
  
  const searchRef = useRef<HTMLDivElement>(null);

  // Função para normalizar texto (remover acentos)
  const normalizeText = (text: string) => {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  };

  useEffect(() => {
    if (searchQuery.trim().length >= 1) {
      const normalizedQuery = normalizeText(searchQuery);
      
      // Filtrar categoria "Vendas por encomenda"
      const excludeCategory = categories.find(cat => cat.name === 'Vendas por encomenda');
      
      // Palavras relacionadas para busca inteligente
      const relatedWords: Record<string, string[]> = {
        'luz': ['lampada', 'lampâda', 'iluminacao', 'iluminação', 'led', 'foco'],
        'lampada': ['luz', 'iluminacao', 'iluminação', 'led', 'foco'],
        'tomada': ['benjamin', 'plugue', 'tomadas', 'extensao', 'extensão'],
        'benjamin': ['tomada', 'adaptador', 'plugue'],
        'cabo': ['fio', 'extensao', 'extensão'],
        'fio': ['cabo', 'extensao', 'extensão'],
      };
      
      const filtered = products
        .filter(product => {
          // Excluir produtos de "Vendas por encomenda"
          if (excludeCategory && product.category_id === excludeCategory.id) {
            return false;
          }
          
          const normalizedName = normalizeText(product.name);
          const normalizedDesc = normalizeText(product.description || '');
          
          // Busca direta
          if (normalizedName.includes(normalizedQuery) || normalizedDesc.includes(normalizedQuery)) {
            return true;
          }
          
          // Busca por palavras relacionadas
          const queryWords = normalizedQuery.split(' ');
          for (const word of queryWords) {
            if (relatedWords[word]) {
              for (const relatedWord of relatedWords[word]) {
                if (normalizedName.includes(relatedWord) || normalizedDesc.includes(relatedWord)) {
                  return true;
                }
              }
            }
          }
          
          return false;
        })
        .map(product => {
          const normalizedName = normalizeText(product.name);
          
          // Calcular relevância
          let score = 0;
          if (normalizedName.startsWith(normalizedQuery)) score = 3;
          else if (normalizedName.includes(` ${normalizedQuery}`)) score = 2;
          else if (normalizedName.includes(normalizedQuery)) score = 1;
          
          return { 
            id: product.id, 
            name: product.name,
            score,
            highlight: searchQuery
          };
        })
        .sort((a, b) => b.score - a.score)
        .slice(0, 10)
        .map(({ id, name, highlight }) => ({ id, name, highlight }));
      
      setSuggestions(filtered);
      setShowSuggestions(filtered.length > 0 && isFocused);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchQuery, products, categories, isFocused]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/catalog?search=${encodeURIComponent(searchQuery)}`);
      setShowSuggestions(false);
      setSearchQuery('');
    }
  };

  const selectSuggestion = (suggestion: {id: string, name: string}) => {
    navigate(`/catalog?search=${encodeURIComponent(suggestion.name)}`);
    setShowSuggestions(false);
    setSearchQuery('');
  };

  const clearSearch = () => {
    setSearchQuery('');
    setShowSuggestions(false);
    setIsFocused(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
  };

  const handleInputFocus = () => {
    setIsFocused(true);
    if (searchQuery.trim().length >= 1) {
      setShowSuggestions(true);
    }
  };

  const handleInputBlur = () => {
    // Delay to allow click on suggestions
    setTimeout(() => {
      setIsFocused(false);
      setShowSuggestions(false);
    }, 200);
  };

  const itemCount = getItemCount();

  const handleWhatsAppClick = () => {
    const whatsappNumber = localStorage.getItem('whatsapp_number') || '51996109657';
    const message = encodeURIComponent('Olá! Vim do site da Sperb Tech e gostaria de mais informações.');
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
  };

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border shadow-sm transition-all duration-300">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-3 py-2">
          <Button 
            variant="ghost" 
            size="sm"
            className="text-xs px-2"
            onClick={() => {
              if (typeof window !== 'undefined' && (window as any).openSellerPanel) {
                (window as any).openSellerPanel();
              }
            }}
          >
            Admin
          </Button>

          <div ref={searchRef} className="flex-1 max-w-4xl relative">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Buscar produtos na Sperb Tech..."
                  value={searchQuery}
                  onChange={handleInputChange}
                  onFocus={handleInputFocus}
                  onBlur={handleInputBlur}
                  className="pl-10 pr-10 py-3 w-full rounded-full text-sm bg-muted/50 border border-border focus:bg-background focus:border-primary transition-all"
                  autoComplete="off"
                />
                {searchQuery && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={clearSearch}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 h-7 w-7 p-0 hover:bg-muted rounded-full"
                  >
                    <X className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                  </Button>
                )}
              </div>
            </form>
            
            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-background border border-border rounded-lg shadow-xl z-50 max-h-[400px] overflow-y-auto">
                <div className="py-1">
                  {suggestions.map((suggestion) => {
                    const highlightText = (text: string, highlight?: string) => {
                      if (!highlight) return text;
                      
                      const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
                      return (
                        <>
                          {parts.map((part, i) => 
                            part.toLowerCase() === highlight.toLowerCase() ? (
                              <span key={i} className="font-semibold text-primary">{part}</span>
                            ) : (
                              <span key={i}>{part}</span>
                            )
                          )}
                        </>
                      );
                    };
                    
                    return (
                      <button
                        key={suggestion.id}
                        type="button"
                        onClick={() => selectSuggestion(suggestion)}
                        className="w-full text-left px-4 py-3 hover:bg-muted/80 transition-colors flex items-center gap-3 group"
                      >
                        <Search className="h-4 w-4 text-muted-foreground group-hover:text-primary flex-shrink-0 transition-colors" />
                        <span className="text-sm text-foreground">
                          {highlightText(suggestion.name, suggestion.highlight)}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3 ml-4">
            <Link to="/cart">
              <Button 
                variant="ghost" 
                size="sm" 
                className="relative rounded-full"
                data-cart-icon
              >
                <ShoppingCart className="h-5 w-5" />
                {itemCount > 0 && (
                  <Badge 
                    variant="secondary" 
                    className="absolute -top-1 -right-1 bg-primary text-white min-w-[18px] h-[18px] rounded-full flex items-center justify-center text-xs p-0"
                  >
                    {itemCount}
                  </Badge>
                )}
              </Button>
            </Link>

            <Button 
              variant="ghost" 
              size="sm" 
              className="relative rounded-full p-0 h-10 w-10 hover:bg-transparent"
              onClick={handleWhatsAppClick}
              aria-label="Contato WhatsApp"
            >
              <img 
                src={whatsappLogo} 
                alt="WhatsApp" 
                className="h-9 w-9 object-contain"
              />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
