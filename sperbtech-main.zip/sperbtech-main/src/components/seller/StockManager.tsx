import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Package, Edit, Save, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { manualStockSystem } from '@/services/manualStockSystem';
import { loyverseApi } from '@/services/loyverse';
import { useProducts } from '@/contexts/ProductContext';

interface Product {
  id: string;
  name: string;
  price: number;
  stock: number;
  image_url?: string;
}

const StockManager = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [loading, setLoading] = useState(true);
  const [syncingPrices, setSyncingPrices] = useState(false);
  const { toast } = useToast();
  const { updateProductStock } = useProducts();

  useEffect(() => {
    fetchProducts();
  }, []);

  const syncPricesOnly = async () => {
    try {
      setSyncingPrices(true);
      
      // Buscar produtos atualizados do Loyverse (apenas preços)
      const loyverseProducts = await loyverseApi.getProducts();
      
      // Atualizar APENAS preços no banco local (não estoque)
      for (const loyverseProduct of loyverseProducts) {
        await supabase
          .from('products')
          .update({ 
            price: loyverseProduct.price
            // NÃO atualizar estoque aqui - ele é manual!
          })
          .eq('id', loyverseProduct.id);
      }
      
      // Recarregar produtos para mostrar preços atualizados
      await fetchProducts();
      
      toast({
        title: 'Preços Sincronizados',
        description: `Preços atualizados para ${loyverseProducts.length} produtos (estoque mantido)`,
      });
    } catch (error) {
      toast({
        title: 'Erro na Sincronização',
        description: 'Erro ao sincronizar preços',
        variant: 'destructive',
      });
    } finally {
      setSyncingPrices(false);
    }
  };

  const fetchProducts = async () => {
    try {
      // Usar o sistema manual de estoque
      const products = await manualStockSystem.getProducts();
      setProducts(products);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar produtos',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const startEditing = (product: Product) => {
    setEditingId(product.id);
    setEditValue(product.stock.toString());
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditValue('');
  };

  const saveStock = async (productId: string) => {
    const newStock = parseInt(editValue);
    
    if (isNaN(newStock) || newStock < 0) {
      toast({
        title: 'Erro',
        description: 'Quantidade deve ser um número válido',
        variant: 'destructive',
      });
      return;
    }

    try {
      const product = products.find(p => p.id === productId);
      if (!product) return;

      const success = await manualStockSystem.updateStock(productId, newStock, product.name);

      if (success) {
        setProducts(prev => prev.map(p => 
          p.id === productId ? { ...p, stock: newStock } : p
        ));

        // Atualizar o estoque imediatamente no catálogo para os compradores
        updateProductStock(productId, newStock);
        
        setEditingId(null);
        setEditValue('');
        
        toast({
          title: 'Sucesso',
          description: 'Estoque atualizado com sucesso',
        });
      } else {
        throw new Error('Falha ao atualizar estoque');
      }
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao atualizar estoque',
        variant: 'destructive',
      });
    }
  };

  const getStockBadge = (stock: number) => {
    if (stock === 0) {
      return <Badge variant="destructive">Esgotado</Badge>;
    }
    if (stock < 5) {
      return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">Baixo</Badge>;
    }
    return <Badge variant="default">{stock} unidades</Badge>;
  };

  if (loading) {
    return (
      <div className="text-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
        <p>Carregando produtos...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Package className="w-6 h-6" />
          Gerenciar Estoque
        </h2>
        <div className="flex gap-2">
          <Button onClick={fetchProducts} variant="outline">
            Atualizar Estoque
          </Button>
          <Button 
            onClick={syncPricesOnly} 
            variant="outline"
            disabled={syncingPrices}
          >
            {syncingPrices ? 'Sincronizando...' : 'Atualizar Preços'}
          </Button>
        </div>
      </div>

      <div className="grid gap-4">
        {products.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <Package className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">
                Nenhum produto encontrado
              </p>
            </CardContent>
          </Card>
        ) : (
          products.map((product) => (
            <Card key={product.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    {product.image_url && (
                      <img 
                        src={product.image_url} 
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded"
                      />
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold">{product.name}</h3>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-green-600">
                          R$ {product.price.toFixed(2)}
                        </p>
                        {syncingPrices && (
                          <div className="w-3 h-3 border border-primary border-t-transparent rounded-full animate-spin"></div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    {editingId === product.id ? (
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          min="0"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="w-20"
                          placeholder="Qtd"
                        />
                        <Button
                          size="sm"
                          onClick={() => saveStock(product.id)}
                        >
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={cancelEditing}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        {getStockBadge(product.stock)}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => startEditing(product)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default StockManager;