import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Package, Edit, Save, X, RefreshCw, DollarSign, Search } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { manualStockSystem } from '@/services/manualStockSystem';
import { loyverseApi } from '@/services/loyverse';
import { useProducts } from '@/contexts/ProductContext';

interface Product {
  id: string;
  name: string;
  price: number;
  stock: number;
  image_url?: string;
}

const ImprovedStockManager = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [loading, setLoading] = useState(true);
  const [syncingPrices, setSyncingPrices] = useState(false);
  const { toast } = useToast();
  const { updateProductStock } = useProducts();

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredProducts(products);
    } else {
      const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProducts(filtered);
    }
  }, [searchTerm, products]);

  const syncPricesOnly = async () => {
    try {
      setSyncingPrices(true);
      const loyverseProducts = await loyverseApi.getProducts();
      
      for (const loyverseProduct of loyverseProducts) {
        await supabase
          .from('products')
          .update({ price: loyverseProduct.price })
          .eq('id', loyverseProduct.id);
      }
      
      await fetchProducts();
      
      toast({
        title: 'Preços Sincronizados',
        description: `${loyverseProducts.length} preços atualizados com sucesso`,
      });
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Falha ao sincronizar preços',
        variant: 'destructive',
      });
    } finally {
      setSyncingPrices(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const products = await manualStockSystem.getProducts();
      setProducts(products);
      setFilteredProducts(products);
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Erro ao carregar produtos',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const startEditing = (product: Product) => {
    setEditingId(product.id);
    setEditValue(product.stock.toString());
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditValue('');
  };

  const saveStock = async (productId: string) => {
    const newStock = parseInt(editValue);
    
    if (isNaN(newStock) || newStock < 0) {
      toast({
        title: 'Erro',
        description: 'Digite uma quantidade válida',
        variant: 'destructive',
      });
      return;
    }

    try {
      const product = products.find(p => p.id === productId);
      if (!product) return;

      // Atualizar imediatamente na UI para feedback instantâneo
      setProducts(prev => prev.map(p => 
        p.id === productId ? { ...p, stock: newStock } : p
      ));
      updateProductStock(productId, newStock);
      setEditingId(null);
      setEditValue('');

      // Salvar no backend
      const success = await manualStockSystem.updateStock(productId, newStock, product.name);

      if (success) {
        toast({
          title: '✅ Estoque Atualizado',
          description: `${product.name}: ${newStock} unidades`,
        });
      } else {
        // Reverter em caso de erro
        await fetchProducts();
        toast({
          title: 'Erro ao Salvar',
          description: 'Revertendo alterações',
          variant: 'destructive',
        });
      }
    } catch (error) {
      await fetchProducts();
      toast({
        title: 'Erro',
        description: 'Falha ao atualizar estoque',
        variant: 'destructive',
      });
    }
  };

  const getStockStatus = (stock: number) => {
    if (stock === 0) return { variant: 'destructive' as const, label: 'Esgotado', color: 'text-red-600' };
    if (stock < 5) return { variant: 'secondary' as const, label: `${stock} unid.`, color: 'text-yellow-600' };
    return { variant: 'default' as const, label: `${stock} unid.`, color: 'text-green-600' };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-center space-y-3">
          <div className="animate-spin rounded-full h-12 w-12 border-b-3 border-primary mx-auto"></div>
          <p className="text-muted-foreground">Carregando produtos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header com ações */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between bg-gradient-to-r from-primary/5 to-primary/10 p-4 rounded-lg border border-primary/20">
        <div className="flex items-center gap-2">
          <Package className="w-5 h-5 text-primary" />
          <div>
            <h2 className="text-xl font-bold text-foreground">Gestão de Estoque</h2>
            <p className="text-xs text-muted-foreground">{products.length} produtos cadastrados</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={fetchProducts} variant="outline" size="sm" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Recarregar
          </Button>
          <Button onClick={syncPricesOnly} variant="outline" size="sm" disabled={syncingPrices} className="gap-2">
            <DollarSign className="w-4 h-4" />
            {syncingPrices ? 'Sincronizando...' : 'Atualizar Preços'}
          </Button>
        </div>
      </div>

      {/* Busca */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          type="text"
          placeholder="Buscar produto..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Lista de produtos */}
      <div className="grid gap-2">
        {filteredProducts.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <Package className="w-12 h-12 mx-auto mb-3 text-muted-foreground opacity-50" />
              <p className="text-muted-foreground">
                {searchTerm ? 'Nenhum produto encontrado' : 'Nenhum produto cadastrado'}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredProducts.map((product) => {
            const stockStatus = getStockStatus(product.stock);
            return (
              <Card key={product.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    {/* Imagem do produto */}
                    {product.image_url && (
                      <img 
                        src={product.image_url} 
                        alt={product.name}
                        className="w-16 h-16 object-cover rounded-md flex-shrink-0"
                      />
                    )}
                    
                    {/* Info do produto */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm truncate">{product.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm font-bold text-green-600">
                          R$ {product.price.toFixed(2)}
                        </span>
                        <Badge variant={stockStatus.variant} className="text-xs">
                          {stockStatus.label}
                        </Badge>
                      </div>
                    </div>
                    
                    {/* Controles de estoque */}
                    {editingId === product.id ? (
                      <div className="flex items-center gap-1">
                        <Input
                          type="number"
                          min="0"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              saveStock(product.id);
                            } else if (e.key === 'Escape') {
                              cancelEditing();
                            }
                          }}
                          className="w-20 h-9 text-sm font-semibold"
                          placeholder="Qtd"
                          autoFocus
                        />
                        <Button 
                          size="sm" 
                          onClick={() => saveStock(product.id)} 
                          className="h-9 w-9 p-0 bg-green-600 hover:bg-green-700"
                        >
                          <Save className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={cancelEditing} 
                          className="h-9 w-9 p-0"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => startEditing(product)}
                        className="gap-1.5 h-9 px-3"
                      >
                        <Edit className="w-4 h-4" />
                        <span className="text-xs font-medium">Editar</span>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
};

export default ImprovedStockManager;
