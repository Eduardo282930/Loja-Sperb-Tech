import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { LogOut, Package, Settings, MessageCircle, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import StockManager from './ImprovedStockManager';
import ProductToggleManager from './ProductToggleManager';

interface SellerPanelProps {
  onLogout: () => void;
}

export default function SellerPanel({ onLogout }: SellerPanelProps) {
  const { toast } = useToast();
  const [whatsappNumber, setWhatsappNumber] = useState('51996109657');

  useEffect(() => {
    const saved = localStorage.getItem('whatsapp_number');
    if (saved) setWhatsappNumber(saved);
  }, []);

  const handleSaveWhatsApp = () => {
    localStorage.setItem('whatsapp_number', whatsappNumber);
    toast({
      title: 'WhatsApp Atualizado',
      description: 'Número do WhatsApp salvo com sucesso',
    });
  };

  return (
    <div className="fixed inset-0 bg-background z-50 overflow-y-auto">
      <div className="container mx-auto p-3 max-w-2xl">
        <div className="flex justify-between items-center mb-4 gap-2">
          <div className="flex items-center gap-2">
            <div className="bg-primary/10 p-1.5 rounded-lg">
              <img 
                src="/lovable-uploads/e796fd03-f794-405f-8495-ced20c4f8f09.png" 
                alt="Sperb Tech" 
                className="h-6 w-6 object-contain"
              />
            </div>
            <div>
              <h1 className="text-lg font-bold text-primary">Admin</h1>
              <p className="text-[10px] text-muted-foreground hidden sm:block">Gestão da loja</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={onLogout} className="gap-1 text-xs px-2">
            <LogOut className="w-3 h-3" />
            <span className="hidden sm:inline">Sair</span>
          </Button>
        </div>

        <Tabs defaultValue="stock" className="space-y-3">
          <TabsList className="grid w-full grid-cols-3 h-auto p-1">
            <TabsTrigger value="stock" className="gap-1 text-xs px-2 py-1.5">
              <Package className="w-3 h-3" />
              <span className="hidden sm:inline">Estoque</span>
            </TabsTrigger>
            <TabsTrigger value="products" className="gap-1 text-xs px-2 py-1.5">
              <Settings className="w-3 h-3" />
              <span className="hidden sm:inline">Produtos</span>
            </TabsTrigger>
            <TabsTrigger value="whatsapp" className="gap-1 text-xs px-2 py-1.5">
              <MessageCircle className="w-3 h-3" />
              <span className="hidden sm:inline">WhatsApp</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stock">
            <StockManager />
          </TabsContent>

          <TabsContent value="products">
            <ProductToggleManager />
          </TabsContent>

          <TabsContent value="whatsapp">
            <Card className="border">
              <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 p-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <MessageCircle className="w-4 h-4 text-green-600" />
                  WhatsApp
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 p-3">
                <div className="space-y-2">
                  <Label htmlFor="whatsapp" className="text-xs font-semibold">Número do WhatsApp</Label>
                  <Input
                    id="whatsapp"
                    type="text"
                    placeholder="51996109657"
                    value={whatsappNumber}
                    onChange={(e) => setWhatsappNumber(e.target.value)}
                    className="text-sm h-9"
                  />
                  <p className="text-[10px] text-muted-foreground">
                    ℹ️ Com código do país (ex: 51996109657)
                  </p>
                </div>
                <Button onClick={handleSaveWhatsApp} size="sm" className="w-full gap-1 text-xs">
                  <Save className="w-3 h-3" />
                  Salvar
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
