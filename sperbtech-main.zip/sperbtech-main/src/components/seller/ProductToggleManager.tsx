import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Package, 
  Search, 
  Eye, 
  EyeOff, 
  RefreshCw,
  AlertTriangle,
  DollarSign,
  Archive
} from 'lucide-react';
import { useProducts } from '@/contexts/ProductContext';
import { useToast } from '@/hooks/use-toast';
import { loyverseApi } from '@/services/loyverse';

const ProductToggleManager: React.FC = () => {
  const { 
    products, 
    loading, 
    error, 
    refreshProducts, 
    toggleProductEnabled, 
    sellerSettings,
    isConnected 
  } = useProducts();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [allLoyverseProducts, setAllLoyverseProducts] = useState<any[]>([]);
  const [loadingAll, setLoadingAll] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isConnected) {
      loadAllProducts();
    }
  }, [isConnected]);

  // Carregar todos os produtos do Loyverse (incluindo desabilitados)
  const loadAllProducts = async () => {
    setLoadingAll(true);
    try {
      const allProducts = await loyverseApi.getProducts();
      setAllLoyverseProducts(allProducts);
    } catch (error) {
      toast({
        title: 'Erro ao carregar produtos',
        description: error instanceof Error ? error.message : 'Erro desconhecido',
        variant: 'destructive',
      });
    } finally {
      setLoadingAll(false);
    }
  };

  // Filtrar produtos por termo de busca
  const filteredProducts = allLoyverseProducts.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.sku?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Verificar se produto está habilitado pelo vendedor
  const isProductEnabled = (productId: string): boolean => {
    const setting = sellerSettings.find(s => s.loyverse_product_id === productId);
    return setting ? setting.is_enabled : true; // Padrão é habilitado
  };

  // Toggle produto
  const handleToggleProduct = async (productId: string, currentEnabled: boolean) => {
    const newEnabled = !currentEnabled;
    const success = await toggleProductEnabled(productId, newEnabled);
    
    if (success) {
      toast({
        title: newEnabled ? 'Produto habilitado' : 'Produto desabilitado',
        description: `O produto ${newEnabled ? 'aparecerá' : 'não aparecerá'} no catálogo`,
      });
      
      // Recarregar lista
      await loadAllProducts();
    } else {
      toast({
        title: 'Erro ao alterar produto',
        description: 'Não foi possível alterar a configuração do produto',
        variant: 'destructive',
      });
    }
  };

  if (!isConnected && !error) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Sem conexão com Loyverse</strong>
          <br />
          Não é possível gerenciar produtos sem conexão com o Loyverse.
          Verifique a configuração do token da API.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Package className="w-6 h-6" />
          Gerenciar Produtos
        </h2>
        <Button 
          onClick={loadAllProducts} 
          variant="outline" 
          disabled={loadingAll || !isConnected}
        >
          {loadingAll ? (
            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Carregar Produtos
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Buscar Produtos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              placeholder="Buscar por nome ou SKU..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <div className="flex items-center gap-2">
              <Badge variant="outline">
                {filteredProducts.length} produtos
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Products List */}
      {allLoyverseProducts.length > 0 ? (
        <div className="grid gap-4">
          {filteredProducts.map((product) => {
            const enabled = isProductEnabled(product.id);
            
            return (
              <Card key={product.id} className={enabled ? '' : 'opacity-75'}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {product.image_url && (
                        <img 
                          src={product.image_url} 
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded"
                        />
                      )}
                      <div>
                        <h3 className="font-medium">{product.name}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            R$ {product.price.toFixed(2)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Archive className="w-3 h-3" />
                            Estoque: {product.stock}
                          </span>
                          {product.sku && (
                            <span className="text-xs">SKU: {product.sku}</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        {enabled ? (
                          <Eye className="w-4 h-4 text-green-600" />
                        ) : (
                          <EyeOff className="w-4 h-4 text-red-600" />
                        )}
                        <span className="text-sm">
                          {enabled ? 'Visível' : 'Oculto'}
                        </span>
                      </div>
                      
                      <Switch
                        checked={enabled}
                        onCheckedChange={() => handleToggleProduct(product.id, enabled)}
                        disabled={!isConnected}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="p-8 text-center">
            <Package className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-medium mb-2">Nenhum produto carregado</h3>
            <p className="text-muted-foreground mb-4">
              Clique em "Carregar Produtos" para ver todos os produtos do Loyverse.
            </p>
            <Button onClick={loadAllProducts} disabled={!isConnected}>
              Carregar Produtos
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ProductToggleManager;