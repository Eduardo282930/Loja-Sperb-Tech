import { Product } from '@/types/product';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StockIndicator } from '@/components/ui/stock-indicator';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { Link } from 'react-router-dom';
import { toast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addItem } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    
    if (isOutOfStock) {
      toast({
        title: "Produto indisponível",
        description: "Este produto está esgotado.",
        variant: "destructive",
      });
      return;
    }
    
    addItem(product);
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado ao carrinho.`,
    });
  };

  // 🔴 VALIDAÇÃO RIGOROSA DE ESTOQUE
  // Produto deve ter estoque definido e >= 0
  const hasValidStock = product.stock !== undefined && 
                        product.stock !== null && 
                        typeof product.stock === 'number' && 
                        product.stock >= 0;
  
  const isOutOfStock = hasValidStock && product.stock === 0;
  const isLowStock = hasValidStock && product.stock > 0 && product.stock < 5;
  
  // 🔴 VALIDAÇÃO RIGOROSA DE PREÇO  
  // Produto deve ter preço válido > 0
  const hasValidPrice = product.price && 
                        typeof product.price === 'number' && 
                        product.price > 0;

  // 🔴 SE NÃO TEM PREÇO OU ESTOQUE VÁLIDO, NÃO RENDERIZAR
  if (!hasValidPrice || !hasValidStock) {
    console.error(`🔴 ProductCard: Produto inválido não renderizado:`, {
      name: product.name,
      precoValido: hasValidPrice,
      preco: product.price,
      estoqueValido: hasValidStock,
      estoque: product.stock
    });
    return null;
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  return (
    <Link to={`/product/${product.id}`}>
      <Card className="group hover:shadow-lg transition-all duration-300 border-gray-light hover:border-orange-medium">
        <CardContent className="p-0">
          <div className="relative overflow-hidden rounded-t-lg">
            <img
              src={product.image_url || '/api/placeholder/300/300'}
              alt={product.name}
              className="w-full h-36 object-cover group-hover:scale-105 transition-transform duration-300"
            />
            {/* 🔴 STATUS DE ESTOQUE EM TEMPO REAL */}
            {isOutOfStock ? (
              <Badge 
                variant="destructive" 
                className="absolute top-2 left-2 bg-red-500 text-white font-medium"
              >
                ESGOTADO
              </Badge>
            ) : isLowStock && (
              <Badge 
                variant="destructive" 
                className="absolute top-2 left-2 bg-yellow-500 text-black font-medium"
              >
                ÚLTIMAS {product.stock} UNIDADES
              </Badge>
            )}
          </div>
          
          <div className="p-3">
            <h3 className="font-medium text-sm text-foreground mb-1 line-clamp-2 group-hover:text-primary transition-colors">
              {product.name}
            </h3>
            
            {/* Avaliações removidas por solicitação - layout mais limpo */}
            
            <div className="flex items-center justify-between">
              <div className="flex flex-col">
                <span className={`text-base font-bold ${isOutOfStock ? 'text-muted-foreground line-through' : 'text-primary'}`}>
                  {formatPrice(product.price)}
                </span>
                {/* Estoque removido para layout mais limpo */}
              </div>
              
              <Button
                size="sm"
                onClick={handleAddToCart}
                disabled={isOutOfStock}
                className={`h-8 px-2 ${
                  isOutOfStock 
                    ? 'bg-muted text-muted-foreground cursor-not-allowed' 
                    : 'bg-primary hover:bg-primary-hover'
                }`}
              >
                <ShoppingCart className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default ProductCard;