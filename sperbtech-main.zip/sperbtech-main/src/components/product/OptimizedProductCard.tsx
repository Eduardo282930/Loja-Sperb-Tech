import React, { memo } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Product } from '@/types/product';
import { useCart } from '@/contexts/CartContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard = memo(({ product }: ProductCardProps) => {
  const { addItem } = useCart();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product);
    
    // Disparar evento para animação do carrinho
    const cartIcon = document.querySelector('[data-cart-icon]') as HTMLElement;
    if (cartIcon) {
      cartIcon.classList.remove('cart-bounce-animation');
      void cartIcon.offsetWidth; // Force reflow
      cartIcon.classList.add('cart-bounce-animation');
      setTimeout(() => {
        cartIcon.classList.remove('cart-bounce-animation');
      }, 500);
    }
  };

  const isOutOfStock = product.stock === 0;

  return (
    <Link to={`/product/${product.id}`}>
      <Card className="group hover:shadow-lg transition-all duration-300 h-full overflow-hidden">
        <div className="relative overflow-hidden">
          <div className="aspect-square relative bg-muted">
            <img
              src={product.image_url || '/api/placeholder/300/300'}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              loading="lazy"
            />
          </div>
        </div>
        
        <CardContent className="p-3 space-y-2">
          <h3 className="font-semibold text-sm text-foreground line-clamp-2 min-h-[2.5rem]">
            {product.name}
          </h3>
          
          <div className="flex items-end justify-between">
            <div>
              <p className="text-base font-bold text-primary">
                {formatPrice(product.price)}
              </p>
            </div>
            
            <Button
              size="sm"
              onClick={handleAddToCart}
              disabled={isOutOfStock}
              className="h-8 px-2 gap-1 transition-all"
            >
              <ShoppingCart className="h-3.5 w-3.5" />
              <span className="text-xs">{isOutOfStock ? 'Esgotado' : 'Adicionar'}</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}, (prevProps, nextProps) => {
  // Custom comparison para evitar re-renders desnecessários
  return (
    prevProps.product.id === nextProps.product.id &&
    prevProps.product.stock === nextProps.product.stock &&
    prevProps.product.price === nextProps.product.price
  );
});

ProductCard.displayName = 'ProductCard';

export default ProductCard;
