import { useEffect, useState } from 'react';

const SplashScreen = () => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 300); // ⚡ 300ms apenas

    return () => clearTimeout(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-gradient-to-br from-primary to-primary-hover animate-fade-in">
      <div className="text-center">
        <img 
          src="/lovable-uploads/e796fd03-f794-405f-8495-ced20c4f8f09.png" 
          alt="Sperb Tech" 
          className="w-32 h-32 mx-auto mb-4 animate-bounce"
        />
        <h1 className="text-4xl font-bold text-white mb-2">Sperb Tech</h1>
        <p className="text-white/90 text-lg">Carregando...</p>
      </div>
    </div>
  );
};

export default SplashScreen;
