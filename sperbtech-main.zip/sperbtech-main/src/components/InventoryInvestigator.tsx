import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';

export const InventoryInvestigator = () => {
  const [investigating, setInvestigating] = useState(false);
  const [results, setResults] = useState<any>(null);

  const investigateInventory = async () => {
    setInvestigating(true);
    console.log('🔍 INVESTIGANDO ESTRUTURA DA API /inventory...');

    try {
      // Chamar edge function para /inventory
      const { data, error } = await supabase.functions.invoke('loyverse-proxy', {
        body: {
          resource: 'inventory',
          method: 'GET',
          useStoredToken: true,
          params: { limit: 10 }
        }
      });

      if (error) {
        console.error('❌ Erro na chamada /inventory:', error);
        setResults({ error: error });
        return;
      }

      console.log('📦 RESPOSTA COMPLETA DA API /inventory:');
      console.log('Tipo:', typeof data);
      console.log('É array?', Array.isArray(data));
      console.log('Keys:', Object.keys(data || {}));
      console.log('Data completa:', JSON.stringify(data, null, 2));

      // Detectar estrutura dos dados
      let inventoryArray: any[] = [];
      let dataSource = 'unknown';
      
      if (Array.isArray(data?.inventory)) {
        inventoryArray = data.inventory;
        dataSource = 'data.inventory';
      } else if (Array.isArray(data?.inventory_levels)) {
        inventoryArray = data.inventory_levels;
        dataSource = 'data.inventory_levels';
      } else if (Array.isArray(data)) {
        inventoryArray = data;
        dataSource = 'data (array direto)';
      }

      console.log(`📦 Usando: ${dataSource}`);
      console.log(`📊 Total de registros: ${inventoryArray.length}`);

      let quantityFields: Record<string, any> = {};
      let firstRecord = null;
      
      if (inventoryArray.length > 0) {
        firstRecord = inventoryArray[0];
        console.log('📦 PRIMEIRO REGISTRO COMPLETO:');
        console.log(JSON.stringify(firstRecord, null, 2));
        
        // Verificar campos de quantidade possíveis
        const possibleQuantityFields = ['quantity', 'quantity_on_hand', 'available_quantity', 'stock', 'in_stock'];
        
        console.log('📦 CAMPOS DE QUANTIDADE ENCONTRADOS:');
        possibleQuantityFields.forEach(field => {
          if (firstRecord[field] !== undefined) {
            quantityFields[field] = {
              value: firstRecord[field],
              type: typeof firstRecord[field]
            };
            console.log(`  ${field}: ${firstRecord[field]} (tipo: ${typeof firstRecord[field]})`);
          }
        });

        // Mostrar primeiros 5 registros resumidos
        console.log('📦 PRIMEIROS 5 REGISTROS (RESUMO):');
        inventoryArray.slice(0, 5).forEach((record, i) => {
          console.log(`Registro ${i + 1}:`, {
            item_id: record.item_id,
            variant_id: record.variant_id,
            store_id: record.store_id,
            quantity: record.quantity,
            quantity_on_hand: record.quantity_on_hand,
            available_quantity: record.available_quantity,
            stock: record.stock,
            in_stock: record.in_stock
          });
        });
      }

      setResults({
        success: true,
        dataSource,
        totalRecords: inventoryArray.length,
        quantityFields,
        firstRecord,
        sampleRecords: inventoryArray.slice(0, 5)
      });

    } catch (error) {
      console.error('❌ Erro na investigação:', error);
      setResults({ error });
    } finally {
      setInvestigating(false);
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          🔍 Investigador da API /inventory
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button 
          onClick={investigateInventory} 
          disabled={investigating}
          className="w-full"
        >
          {investigating ? 'Investigando...' : 'Investigar Estrutura da API /inventory'}
        </Button>

        {results && (
          <div className="space-y-4">
            {results.error ? (
              <div className="p-4 bg-red-50 border border-red-200 rounded">
                <h3 className="font-semibold text-red-800">Erro na Investigação</h3>
                <pre className="text-sm mt-2 text-red-700">
                  {JSON.stringify(results.error, null, 2)}
                </pre>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-blue-50 rounded">
                    <div className="font-semibold">Fonte dos Dados</div>
                    <Badge variant="outline">{results.dataSource}</Badge>
                  </div>
                  <div className="p-3 bg-green-50 rounded">
                    <div className="font-semibold">Total de Registros</div>
                    <Badge>{results.totalRecords}</Badge>
                  </div>
                </div>

                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
                  <h3 className="font-semibold mb-2">Campos de Quantidade Encontrados</h3>
                  {Object.keys(results.quantityFields).length > 0 ? (
                    <div className="space-y-1">
                      {Object.entries(results.quantityFields).map(([field, info]: [string, any]) => (
                        <div key={field} className="flex items-center gap-2">
                          <Badge variant="secondary">{field}</Badge>
                          <span className="text-sm">
                            Valor: {info.value} (tipo: {info.type})
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-yellow-700">Nenhum campo de quantidade padrão encontrado</p>
                  )}
                </div>

                {results.firstRecord && (
                  <div className="p-4 bg-gray-50 border border-gray-200 rounded">
                    <h3 className="font-semibold mb-2">Primeiro Registro Completo</h3>
                    <pre className="text-xs overflow-x-auto bg-white p-2 rounded border">
                      {JSON.stringify(results.firstRecord, null, 2)}
                    </pre>
                  </div>
                )}

                {results.sampleRecords && results.sampleRecords.length > 0 && (
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded">
                    <h3 className="font-semibold mb-2">Amostra de Registros</h3>
                    <div className="space-y-2">
                      {results.sampleRecords.map((record: any, i: number) => (
                        <div key={i} className="text-xs bg-white p-2 rounded border">
                          <strong>Registro {i + 1}:</strong>
                          <br />
                          item_id: {record.item_id} | variant_id: {record.variant_id} | store_id: {record.store_id}
                          <br />
                          quantity: {record.quantity} | quantity_on_hand: {record.quantity_on_hand} | available_quantity: {record.available_quantity} | stock: {record.stock}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        <div className="text-xs text-gray-500 mt-4">
          <p><strong>Instruções:</strong></p>
          <p>1. Clique no botão para investigar a estrutura da API</p>  
          <p>2. Abra o Console do navegador (F12) para ver logs detalhados</p>
          <p>3. Os resultados aparecerão aqui e nos logs do console</p>
        </div>
      </CardContent>
    </Card>
  );
};