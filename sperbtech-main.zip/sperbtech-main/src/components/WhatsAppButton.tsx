import { MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface WhatsAppButtonProps {
  position?: 'bottom-right' | 'top-right';
  phoneNumber?: string;
}

const WhatsAppButton = ({ 
  position = 'bottom-right',
  phoneNumber = '51996109657' // Número padrão, será editável no admin
}: WhatsAppButtonProps) => {
  const handleClick = () => {
    const message = encodeURIComponent('Olá! Vim do site da Sperb Tech e gostaria de mais informações.');
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
  };

  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'top-right': 'top-20 right-6'
  };

  return (
    <Button
      onClick={handleClick}
      size="lg"
      className={`fixed ${positionClasses[position]} z-50 rounded-full w-14 h-14 p-0 shadow-lg hover:shadow-xl transition-all hover:scale-110 bg-green-500 hover:bg-green-600 text-white`}
      aria-label="Contato WhatsApp"
    >
      <MessageCircle className="h-7 w-7" />
    </Button>
  );
};

export default WhatsAppButton;
