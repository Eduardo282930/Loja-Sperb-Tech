import { 
  Smartphone, 
  Laptop, 
  Headphones, 
  Watch, 
  Camera, 
  Gamepad2,
  Package,
  Zap,
  Lightbulb,
  Plug,
  Cable,
  Router,
  Speaker,
  Monitor,
  Battery,
  Usb,
  HardDrive,
  type LucideIcon
} from 'lucide-react';

interface CategoryIconProps {
  categoryName: string;
  className?: string;
}

const categoryIconMap: Record<string, LucideIcon> = {
  // Eletrônicos
  'smartphone': Smartphone,
  'celular': Smartphone,
  'telefone': Smartphone,
  'laptop': Laptop,
  'computador': Laptop,
  'notebook': Laptop,
  'headphone': Headphones,
  'fone': Headphones,
  'audio': Speaker,
  'relógio': Watch,
  'watch': Watch,
  'câmera': Camera,
  'camera': Camera,
  'foto': Camera,
  'game': Gamepad2,
  'jogo': Gamepad2,
  
  // Eletricidade
  'luz': Lightbulb,
  'lâmpada': Lightbulb,
  'lampada': Lightbulb,
  'iluminação': Lightbulb,
  'iluminacao': Lightbulb,
  'tomada': Plug,
  'plugue': Plug,
  'benjamin': Plug,
  'cabo': Cable,
  'fio': Cable,
  'extensão': Cable,
  'extensao': Cable,
  'energia': Zap,
  'elétrico': Zap,
  'eletrico': Zap,
  
  // Conectividade
  'router': Router,
  'roteador': Router,
  'wifi': Router,
  'rede': Router,
  'usb': Usb,
  'monitor': Monitor,
  'tela': Monitor,
  'display': Monitor,
  'bateria': Battery,
  'pilha': Battery,
  'armazenamento': HardDrive,
  'hd': HardDrive,
  'ssd': HardDrive,
};

const CategoryIcon = ({ categoryName, className = "h-5 w-5" }: CategoryIconProps) => {
  const normalizedName = categoryName.toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
  
  // Procura por palavras-chave no nome da categoria
  const IconComponent = Object.keys(categoryIconMap).find(key => 
    normalizedName.includes(key)
  );
  
  const Icon = IconComponent ? categoryIconMap[IconComponent] : Package;
  
  return <Icon className={className} />;
};

export default CategoryIcon;
