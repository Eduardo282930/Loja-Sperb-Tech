import React from 'react';
import { 
  Smartphone, 
  Laptop, 
  Headphones, 
  Watch, 
  Camera, 
  Gamepad2,
  Package,
  ShoppingBag,
  Zap,
  Cpu,
  Monitor,
  Tablet,
  Router,
  Music,
  Video,
  LucideIcon
} from 'lucide-react';

interface DynamicIconProps {
  iconName: string;
  className?: string;
}

const iconMap: Record<string, LucideIcon> = {
  Smartphone,
  Laptop,
  Headphones,
  Watch,
  Camera,
  Gamepad2,
  Package,
  ShoppingBag,
  Zap,
  Cpu,
  Monitor,
  Tablet,
  Router,
  Music,
  Video,
};

const DynamicIcon: React.FC<DynamicIconProps> = ({ iconName, className = "h-6 w-6" }) => {
  const IconComponent = iconMap[iconName] || Package;
  return <IconComponent className={className} />;
};

export default DynamicIcon;