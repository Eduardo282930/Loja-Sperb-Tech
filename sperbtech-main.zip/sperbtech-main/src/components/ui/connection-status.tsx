import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Wifi, 
  WifiOff, 
  RefreshCw,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';
import { useProducts } from '@/contexts/ProductContext';
import { cn } from '@/lib/utils';

interface ConnectionStatusProps {
  showDetails?: boolean;
  className?: string;
}

export function ConnectionStatus({ showDetails = false, className }: ConnectionStatusProps) {
  // 🔴 PROTEÇÃO: Tentar usar o hook com fallback seguro
  let hookData;
  try {
    hookData = useProducts();
  } catch (error) {
    // Se o hook falhar, retornar componente seguro de loading
    if (!showDetails) {
      return (
        <Badge 
          variant="secondary"
          className={cn('flex items-center gap-1 px-2 py-1', className)}
        >
          <RefreshCw className="h-3 w-3 animate-spin" />
          Carregando...
        </Badge>
      );
    }
    return (
      <div className={cn('flex items-center gap-3 p-3 rounded-lg border bg-blue-50 border-blue-200', className)}>
        <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
        <div className="font-medium text-sm text-blue-600">
          Inicializando sistema...
        </div>
      </div>
    );
  }
  
  const { 
    isConnected, 
    connectionStatus, 
    lastSyncTimestamp,
    isSyncing,
    refreshProducts,
    error
  } = hookData;

  const getStatusConfig = () => {
    switch (connectionStatus) {
      case 'connected':
        return {
          icon: CheckCircle2,
          text: 'Conectado',
          variant: 'default' as const,
          color: 'text-green-600',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-200'
        };
      case 'checking':
        return {
          icon: RefreshCw,
          text: 'Verificando...',
          variant: 'secondary' as const,
          color: 'text-blue-600',
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-200',
          animate: 'animate-spin'
        };
      case 'disconnected':
      default:
        return {
          icon: AlertTriangle,
          text: 'Desconectado',
          variant: 'destructive' as const,
          color: 'text-red-600',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-200'
        };
    }
  };

  const config = getStatusConfig();
  const Icon = config.icon;

  if (!showDetails) {
    return (
      <Badge 
        variant={config.variant}
        className={cn(
          'flex items-center gap-1 px-2 py-1',
          className
        )}
      >
        <Icon className={cn('h-3 w-3', config.animate)} />
        {config.text}
      </Badge>
    );
  }

  return (
    <div className={cn(
      'flex items-center gap-3 p-3 rounded-lg border',
      config.bgColor,
      config.borderColor,
      className
    )}>
      <div className="flex items-center gap-2">
        <Icon className={cn('h-4 w-4', config.color, config.animate)} />
        <div>
          <div className={cn('font-medium text-sm', config.color)}>
            {config.text}
          </div>
          {lastSyncTimestamp && isConnected && (
            <div className="text-xs text-muted-foreground">
              Última sincronização: {lastSyncTimestamp.toLocaleTimeString('pt-BR')}
            </div>
          )}
          {error && !isConnected && (
            <div className="text-xs text-red-600 max-w-xs truncate">
              {error}
            </div>
          )}
        </div>
      </div>

      {/* Indicador de sincronização removido - aparece apenas no painel admin */}

      {!isConnected && !isSyncing && (
        <Button 
          onClick={refreshProducts}
          variant="outline"
          size="sm"
          className="ml-auto"
        >
          <RefreshCw className="h-3 w-3 mr-1" />
          Reconectar
        </Button>
      )}
    </div>
  );
}

export function ConnectionIndicator({ className }: { className?: string }) {
  // 🔴 PROTEÇÃO: Verificar se o hook está disponível antes de usar
  let hookData;
  try {
    hookData = useProducts();
  } catch (error) {
    // Se o hook falhar, mostrar estado de carregamento
    return (
      <div className={cn('flex items-center gap-1 text-xs text-muted-foreground', className)}>
        <RefreshCw className="h-3 w-3 animate-spin" />
        Inicializando...
      </div>
    );
  }
  
  const { isConnected, isSyncing } = hookData;
  
  // Se ainda está inicializando, mostrar loading
  if (hookData.connectionStatus === 'checking') {
    return (
      <div className={cn('flex items-center gap-1 text-xs text-muted-foreground', className)}>
        <RefreshCw className="h-3 w-3 animate-spin" />
        Verificando...
      </div>
    );
  }
  
  // Não mostrar indicador de sincronização para o cliente

  return (
    <div className={cn('flex items-center gap-1 text-xs', className)}>
      {isConnected ? (
        <>
          <Wifi className="h-3 w-3 text-green-600" />
          <span className="text-green-600">Online</span>
        </>
      ) : (
        <>
          <WifiOff className="h-3 w-3 text-red-600" />
          <span className="text-red-600">Offline</span>
        </>
      )}
    </div>
  );
}