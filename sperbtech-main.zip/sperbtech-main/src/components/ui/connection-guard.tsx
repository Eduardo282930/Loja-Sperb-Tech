import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw, WifiOff } from 'lucide-react';
import { useProducts } from '@/contexts/ProductContext';

interface ConnectionGuardProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function ConnectionGuard({ children, fallback }: ConnectionGuardProps) {
  // 🔴 PROTEÇÃO: Verificar se o hook está disponível antes de usar
  let hookData;
  try {
    hookData = useProducts();
  } catch (error) {
    // Se o hook falhar, mostrar estado de carregamento seguro
    return (
      <div className="flex items-center justify-center p-8 animate-fade-in">
        <RefreshCw className="w-6 h-6 animate-spin mr-2" />
        <span>Inicializando sistema...</span>
      </div>
    );
  }
  
  const { isConnected, error, refreshProducts, loading, isSyncing, connectionStatus } = hookData;

  // Durante carregamento inicial (primeira vez)
  if (loading) {
    return (
      <div className="flex items-center justify-center p-8 animate-fade-in">
        <RefreshCw className="w-6 h-6 animate-spin mr-2" />
        <span>Conectando ao sistema...</span>
      </div>
    );
  }

  // Se não conectado, mostrar erro
  if (!isConnected && connectionStatus === 'disconnected') {
    if (fallback) {
      return <>{fallback}</>;
    }

    return (
      <Alert variant="destructive" className="m-4 animate-fade-in">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <div className="space-y-3">
            <div>
              <strong>Sem conexão com o sistema</strong>
              <br />
              {error || 'Verifique sua conexão e tente novamente.'}
            </div>
            <div className="flex gap-2">
              <Button onClick={refreshProducts} variant="outline" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                Tentar Novamente
              </Button>
            </div>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  // Se conectado, sempre mostrar conteúdo (sem indicador de sincronização para cliente)
  return (
    <div className="relative">
      {children}
    </div>
  );
}

export function OfflineMessage() {
  return (
    <Alert variant="destructive" className="animate-fade-in">
      <WifiOff className="h-4 w-4" />
      <AlertDescription>
        <strong>Sistema temporariamente indisponível</strong>
        <br />
        Não foi possível conectar ao sistema. Tente novamente em alguns momentos.
      </AlertDescription>
    </Alert>
  );
}