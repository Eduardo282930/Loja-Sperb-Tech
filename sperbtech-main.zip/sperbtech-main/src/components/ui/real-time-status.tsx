import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Zap, Wifi, WifiOff, RefreshCw } from 'lucide-react';

interface RealTimeStatusProps {
  isConnected: boolean;
  isSyncing: boolean;
  lastSync?: Date | null;
  className?: string;
}

export function RealTimeStatus({ 
  isConnected, 
  isSyncing, 
  lastSync, 
  className 
}: RealTimeStatusProps) {
  const [syncCount, setSyncCount] = useState(0);

  useEffect(() => {
    if (isSyncing) {
      setSyncCount(prev => prev + 1);
    }
  }, [isSyncing]);

  const getTimeSinceLastSync = () => {
    if (!lastSync) return 'Nunca';
    
    const now = new Date();
    const diff = now.getTime() - lastSync.getTime();
    const seconds = Math.floor(diff / 1000);
    
    if (seconds < 10) return 'Agora há pouco';
    if (seconds < 60) return `${seconds}s atrás`;
    
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}min atrás`;
    
    return lastSync.toLocaleTimeString('pt-BR');
  };

  return (
    <div className={cn('flex flex-col gap-2', className)}>
      {/* Status Principal */}
      <div className="flex items-center gap-2">
        {isConnected ? (
          <Badge variant="default" className="flex items-center gap-1">
            <Wifi className="h-3 w-3" />
            Conectado
          </Badge>
        ) : (
          <Badge variant="destructive" className="flex items-center gap-1">
            <WifiOff className="h-3 w-3" />
            Desconectado
          </Badge>
        )}
        
        {isSyncing && (
          <Badge variant="secondary" className="flex items-center gap-1 animate-pulse">
            <RefreshCw className="h-3 w-3 animate-spin" />
            Sincronizando...
          </Badge>
        )}
        
        {isConnected && !isSyncing && (
          <Badge variant="outline" className="flex items-center gap-1">
            <Zap className="h-3 w-3 text-green-500" />
            Tempo Real Ativo
          </Badge>
        )}
      </div>
      
      {/* Informações Adicionais */}
      <div className="text-xs text-muted-foreground">
        <div>Última sincronização: {getTimeSinceLastSync()}</div>
        <div>Sincronizações realizadas: {syncCount}</div>
      </div>
    </div>
  );
}