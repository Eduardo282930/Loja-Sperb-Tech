import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, Wifi, WifiOff } from 'lucide-react';
import { useRealTimeSync } from '@/hooks/useRealTimeSync';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface SyncIndicatorProps {
  showRefreshButton?: boolean;
}

export function SyncIndicator({ showRefreshButton = true }: SyncIndicatorProps) {
  const { isConnected, lastSync, forceSync, syncError } = useRealTimeSync();

  return (
    <div className="flex items-center gap-2">
      <Badge 
        variant={isConnected ? "secondary" : "destructive"} 
        className={isConnected ? "bg-green-100 text-green-800" : ""}
        title={syncError || undefined}
      >
        {isConnected ? (
          <>
            <Wifi className="w-3 h-3 mr-1" />
            Conectado
          </>
        ) : (
          <>
            <WifiOff className="w-3 h-3 mr-1" />
            {syncError ? 'Erro' : 'Offline'}
          </>
        )}
      </Badge>
      
      {lastSync && (
        <span className="text-xs text-muted-foreground">
          Atualizado {formatDistanceToNow(lastSync, { locale: ptBR, addSuffix: true })}
        </span>
      )}
      
      {showRefreshButton && isConnected && (
        <Button
          size="sm"
          variant="ghost"
          onClick={forceSync}
          className="h-6 w-6 p-0"
        >
          <RefreshCw className="w-3 h-3" />
        </Button>
      )}
    </div>
  );
}