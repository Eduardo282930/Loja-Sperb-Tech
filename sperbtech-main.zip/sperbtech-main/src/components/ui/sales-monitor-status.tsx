import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { loyverseReceiptMonitor } from '@/services/loyverseReceiptMonitor';
import { Eye, EyeOff } from 'lucide-react';

interface SalesMonitorStatusProps {
  className?: string;
}

export const SalesMonitorStatus = ({ className = "" }: SalesMonitorStatusProps) => {
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    // Verificar status inicial
    setIsActive(loyverseReceiptMonitor.isActive());

    // Verificar a cada 5 segundos
    const interval = setInterval(() => {
      setIsActive(loyverseReceiptMonitor.isActive());
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Badge 
      variant={isActive ? "default" : "secondary"} 
      className={`flex items-center gap-1 ${className}`}
    >
      {isActive ? (
        <>
          <Eye className="w-3 h-3" />
          <span className="text-xs">Monitorando Vendas</span>
        </>
      ) : (
        <>
          <EyeOff className="w-3 h-3" />
          <span className="text-xs">Monitor Pausado</span>
        </>
      )}
    </Badge>
  );
};