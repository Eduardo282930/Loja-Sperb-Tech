import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Package, AlertTriangle, CheckCircle } from 'lucide-react';

interface StockIndicatorProps {
  stock: number;
  className?: string;
  showAnimation?: boolean;
  previousStock?: number;
}

export function StockIndicator({ 
  stock, 
  className, 
  showAnimation = true,
  previousStock 
}: StockIndicatorProps) {
  const [isUpdated, setIsUpdated] = useState(false);
  const [showPulse, setShowPulse] = useState(false);

  useEffect(() => {
    if (previousStock !== undefined && previousStock !== stock && showAnimation) {
      setIsUpdated(true);
      setShowPulse(true);
      
      // Remove animation after 2 seconds
      const timer = setTimeout(() => {
        setIsUpdated(false);
        setShowPulse(false);
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [stock, previousStock, showAnimation]);

  const getStockStatus = () => {
    if (stock === 0) return 'out-of-stock';
    if (stock <= 5) return 'low-stock';
    return 'in-stock';
  };

  const getStockColor = () => {
    const status = getStockStatus();
    if (status === 'out-of-stock') return 'destructive';
    if (status === 'low-stock') return 'warning';
    return 'default';
  };

  const getStockIcon = () => {
    const status = getStockStatus();
    if (status === 'out-of-stock') return AlertTriangle;
    if (status === 'low-stock') return Package;
    return CheckCircle;
  };

  const getStockText = () => {
    if (stock === 0) return 'Esgotado';
    if (stock === 1) return '1 unidade';
    return `${stock} unidades`;
  };

  const Icon = getStockIcon();

  return (
    <div className="relative">
      <Badge
        variant={getStockColor() as any}
        className={cn(
          'flex items-center gap-1 transition-all duration-300',
          showPulse && 'animate-pulse ring-2 ring-blue-400 ring-opacity-75',
          isUpdated && 'bg-blue-500 text-white',
          className
        )}
      >
        <Icon className="h-3 w-3" />
        {getStockText()}
      </Badge>
      
      {isUpdated && showAnimation && (
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full animate-ping" />
      )}
    </div>
  );
}